Get the premium version for more benefits such as MySQL integration, additional extensions,
updates, support and commercial use permission.

t.me/decenhash
t.me/devsacramento
decenhash.netlify.app
3gp.neocities.org

decenhash@gmail.com

---------------------

All rights reserved