Project Overview
Core Principle: Store all files inside "files" directory using the file's SHA256 hash as its filename. All additional tools (metadata, search, etc.) are built on top of this simple foundation.

This approach makes it possible to check which servers are hosting the same file. If a file or server becomes unavailable, users have a consistent reference (the hash) to find it elsewhere. Using only HTTP everywhere.

Components
Rizoma: Use text files containing only links and URLs instead of traditional tables. Small, easy to use. Designed to prevent spam. Can run on PHP without database.
E2EPHEMERA: A prototype client for downloading and sharing files.
ServerCrawler: Used to check files and discover other servers on the network, and so on recursively.
JSONloose: Help organize JSON and metadata files downloaded in "files" directory moving to its directory.
Index: Serves files via PHP and enables search functionality without a database.
simple_upload: The most bare-bones implementation of the core idea.
