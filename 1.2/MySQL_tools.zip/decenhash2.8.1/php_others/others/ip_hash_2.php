<?php
// Get user IP address
$userIP = $_SERVER['REMOTE_ADDR'];

//Arbitrary Stuff
$salt = "star";

// Create SHA256 hash of the IP
$ipHash_tmp = hash('sha256', $userIP) . $salt;

// Add secure
$ipHash = hash('sha256', $ipHash_tmp );

// Define the directory path
$dirPath = 'ip_hash';

// Create directory if it doesn't exist
if (!file_exists($dirPath)) {
    mkdir($dirPath, 0755, true);
}

// Define the full file path
$filePath = $dirPath . '/' . $ipHash;

// Check if file with this hash already exists
if (file_exists($filePath)) {
    // File exists, abort and show message
    die("Timeout. Buy a premium account for more limit");
}

// File doesn't exist, create an empty file
file_put_contents($filePath, '');

// Continue with the rest of your program
echo "Access granted. Your IP hash: " . $ipHash;
?>