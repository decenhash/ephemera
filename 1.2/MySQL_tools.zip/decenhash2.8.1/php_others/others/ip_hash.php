<?php
// Define the storage directory
$storageDir = 'ip_hash';

// Create directory if it doesn't exist
if (!file_exists($storageDir)) {
    mkdir($storageDir, 0755, true);
}

// Get the user's IP address
$userIP = $_SERVER['REMOTE_ADDR'];

// Handle proxy cases (if user is behind a proxy)
if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
    $ipList = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
    $userIP = trim($ipList[0]);
}

// Arbitrary stuff
$salt = "star";

// Create SHA-256 hash of the IP
$ipHash_tmp = hash('sha256', $userIP) . $salt;

// Add secure
$ipHash = hash('sha256', $ipHash_tmp);

// Define the file path
$filePath = $storageDir . '/' . $ipHash;

// Check if file already exists
if (file_exists($filePath)) {
    die("Timeout. Buy a premium account for more limits.");
}

// Create empty file with the hash as filename
file_put_contents($filePath, '');

// Success message
echo "IP hash stored successfully: " . $ipHash;
?>