<!DOCTYPE html>
<html>
<head>
    <title>Text Extraction Tool</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
        }
        textarea {
            width: 100%;
            height: 200px;
            margin-bottom: 10px;
            padding: 8px;
        }
        .result {
            background-color: #f0f0f0;
            padding: 15px;
            border-radius: 5px;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <h1>Text Extraction Tool</h1>
    <p>Enter text with lines containing "-" characters. The program will extract unique values after the "-" in each line.</p>
    
    <form method="post" action="">
        <textarea name="inputText" placeholder="Enter your text here. Example:
item1 - description1
item2 - description2
item3 - description1"><?php echo isset($_POST['inputText']) ? htmlspecialchars($_POST['inputText']) : ''; ?></textarea>
        <br>
        <button type="submit">Process Text</button>
    </form>

    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST" && !empty($_POST['inputText'])) {
        // Get the input text and split it into lines
        $inputText = $_POST['inputText'];
        $lines = explode("\n", $inputText);
        $results = [];
        
        // Process each line
        foreach ($lines as $line) {
            // Check if the line contains "-"
            if (strpos($line, "-") !== false) {
                // Split the line at "-" and get the part after it
                $parts = explode("-", $line, 2);
                if (isset($parts[1])) {
                    // Trim whitespace and add to results array only if not already present
                    $extractedText = trim($parts[1]);
                    if (!in_array($extractedText, $results)) {
                        $results[] = $extractedText;
                    }
                }
            }
        }
        
        // Join the unique results with commas
        $output = implode(", ", $results);
        
        // Display the result
        echo '<div class="result">';
        echo '<h3>Extracted Unique Text:</h3>';
        echo '<p>' . htmlspecialchars($output) . '</p>';
        echo '</div>';
    }
    ?>
</body>
</html>