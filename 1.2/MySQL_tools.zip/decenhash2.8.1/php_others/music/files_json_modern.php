<?php
// Function to get all files from the 'files' folder
function getAllFiles() {
    $filesPath = 'files/';
    $files = [];
    
    // Check if directory exists
    if (!is_dir($filesPath)) {
        mkdir($filesPath, 0755, true);
        echo "Created 'files' directory as it didn't exist.<br>";
        return $files;
    }
    
    // Get all files except hidden files (starting with .)
    $allFiles = scandir($filesPath);
    foreach ($allFiles as $file) {
        if ($file !== '.' && $file !== '..' && $file[0] !== '.') {
            $files[] = $file;
        }
    }
    
    return $files;
}

// Function to get thumbnail for a file
function getThumbnail($filename) {
    $imageExtensions = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
    $extension = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
    
    // If the file is an image, use it as its own thumbnail
    if (in_array($extension, $imageExtensions)) {
        return 'files/' . $filename;
    }
    
    // For MP3 files, use [part-before-dash].jpg as thumbnail
    if ($extension === 'mp3') {
        $parts = explode('-', $filename);
        if (count($parts) > 0) {
            $artist = trim($parts[0]);
            $thumbnailPath = 'files/' . $artist . '.jpg';
            
            if (file_exists($thumbnailPath)) {
                return $thumbnailPath;
            }
        }
    }
    
    // Default thumbnail for all other cases
    $defaultThumb = 'files/no_thumbs.jpg';
    return file_exists($defaultThumb) ? $defaultThumb : 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/svgs/solid/music.svg';
}

// Function to get song title from filename
function getSongTitle($filename) {
    $parts = explode('-', $filename);
    if (count($parts) > 1) {
        return pathinfo($parts[1], PATHINFO_FILENAME);
    }
    return pathinfo($filename, PATHINFO_FILENAME);
}

// Function to get artist name from filename
function getArtistName($filename) {
    $parts = explode('-', $filename);
    if (count($parts) > 0) {
        return $parts[0];
    }
    return "Unknown Artist";
}

// Get all files
$allFiles = getAllFiles();

// Prepare the JSON array with original structure
$musicData = [];

foreach ($allFiles as $index => $file) {
    $musicData[] = [
        'id' => $index,
        'filename' => $file,
        'filePath' => 'files/' . $file,
        'title' => getSongTitle($file),
        'artist' => getArtistName($file),
        'thumbPath' => getThumbnail($file)
    ];
}

// Generate the JSON file
$jsonContent = json_encode($musicData, JSON_PRETTY_PRINT);
file_put_contents('data_json/data.json', $jsonContent);

echo "Music JSON file generated successfully!<br>";
echo "Found " . count($allFiles) . " files.<br>";

// Display the JSON content for debugging
echo "<h3>JSON Content:</h3>";
echo "<pre>" . htmlspecialchars($jsonContent) . "</pre>";
?>