<?php
// Function to get all files from the 'files' folder
function getAllFiles() {
    $filesPath = 'files/';
    $files = [];
    
    // Check if directory exists
    if (!is_dir($filesPath)) {
        if (!mkdir($filesPath, 0755, true)) {
            die("Failed to create 'files' directory");
        }
        echo "Created 'files' directory as it didn't exist.<br>";
        return $files;
    }
    
    // Get all files except hidden files (starting with .)
    $allFiles = scandir($filesPath);
    if ($allFiles === false) {
        die("Failed to scan directory: $filesPath");
    }
    
    foreach ($allFiles as $file) {
        if ($file !== '.' && $file !== '..' && $file[0] !== '.') {
            $files[] = $file;
        }
    }
    
    return $files;
}

// Function to get thumbnail for a file
function getThumbnail($filename) {
    $imageExtensions = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
    $extension = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
    
    // If the file is an image, use it as its own thumbnail
    if (in_array($extension, $imageExtensions)) {
        return 'files/' . $filename;
    }
    
    // For MP3 files, use [part-before-dash].jpg as thumbnail
    if ($extension === 'mp3') {
        $parts = explode('-', $filename);
        if (count($parts) > 0) {
            $artist = trim($parts[0]);
            $thumbnailPath = 'files/' . $artist . '.jpg';
            
            if (file_exists($thumbnailPath)) {
                return $thumbnailPath;
            }
        }
    }
    
    // Default thumbnail for all other cases
    $defaultThumb = 'files/no_thumbs.jpg';
    return file_exists($defaultThumb) ? $defaultThumb : 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/svgs/solid/music.svg';
}

// Function to get song title from filename
function getSongTitle($filename) {
    $parts = explode('-', $filename);
    if (count($parts) > 1) {
        return pathinfo($parts[1], PATHINFO_FILENAME);
    }
    return pathinfo($filename, PATHINFO_FILENAME);
}

// Function to get artist name from filename
function getArtistName($filename) {
    $parts = explode('-', $filename);
    if (count($parts) > 0) {
        return $parts[0];
    }
    return "Unknown Artist";
}

// Function to save data to JSON file with automatic splitting
function saveDataToJsonFiles($data) {
    $maxEntries = 20;
    $maxSizeKB = 20;
    $fileCounter = 1;
    $filesCreated = 0;
    
    // Create data_json directory if it doesn't exist
    if (!is_dir('data_json')) {
        if (!mkdir('data_json', 0755, true)) {
            die("Failed to create 'data_json' directory");
        }
    }
    
    $currentChunk = [];
    $currentSize = 0;
    
    foreach ($data as $entry) {
        $entrySize = strlen(json_encode($entry));
        
        // Check if adding this entry would exceed limits
        if (count($currentChunk) >= $maxEntries || 
            ($currentSize + $entrySize) > ($maxSizeKB * 1024)) {
            // Save current chunk
            $filename = ($fileCounter === 1) ? 'data_json/data.json' : "data_json/data_$fileCounter.json";
            if (file_put_contents($filename, json_encode($currentChunk, JSON_PRETTY_PRINT))) {
                $filesCreated++;
            } else {
                die("Failed to write to file: $filename");
            }
            
            // Start new chunk
            $currentChunk = [];
            $currentSize = 0;
            $fileCounter++;
        }
        
        $currentChunk[] = $entry;
        $currentSize += $entrySize;
    }
    
    // Save the last chunk if it's not empty
    if (!empty($currentChunk)) {
        $filename = ($fileCounter === 1) ? 'data_json/data.json' : "data_json/data_$fileCounter.json";
        if (file_put_contents($filename, json_encode($currentChunk, JSON_PRETTY_PRINT))) {
            $filesCreated++;
        } else {
            die("Failed to write to file: $filename");
        }
    }
    
    return $filesCreated; // Return number of files successfully created
}

// Get all files
$allFiles = getAllFiles();

// Prepare the data array with original structure
$musicData = [];

foreach ($allFiles as $index => $file) {
    $musicData[] = [
        'id' => $index,
        'filename' => $file,
        'filePath' => 'files/' . $file,
        'title' => getSongTitle($file),
        'artist' => getArtistName($file),
        'thumbPath' => getThumbnail($file)
    ];
}

// Save data to JSON files with automatic splitting
$numFiles = saveDataToJsonFiles($musicData);

echo "Music JSON files generated successfully!<br>";
echo "Found " . count($allFiles) . " files in $numFiles JSON file(s).<br>";

// Display the first file's content for debugging
if (file_exists('data_json/data.json')) {
    $firstFileContent = file_get_contents('data_json/data.json');
    echo "<h3>First JSON File Content:</h3>";
    echo "<pre>" . htmlspecialchars($firstFileContent) . "</pre>";
} else {
    echo "<h3>No JSON files were created.</h3>";
}
?>