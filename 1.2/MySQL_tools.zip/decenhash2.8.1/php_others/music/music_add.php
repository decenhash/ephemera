<?php
// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Directory configurations
    $mediaDir = 'music/';
    $jsonFile = 'data_json/data.json';
    
    // Ensure directories exist
    if (!file_exists($mediaDir)) {
        mkdir($mediaDir, 0777, true);
    }
    if (!file_exists('data_json')) {
        mkdir('data_json', 0777, true);
    }
    
    // Process uploaded files
    $artist = str_replace(' ', '_', $_POST['artist']);
    $title = str_replace(' ', '_', $_POST['title']);
    $filename = $artist . '-' . $title;
    
    // Handle media file upload (MP3 or MP4)
    $mediaPath = '';
    $mediaType = '';
    if (isset($_FILES['media']) && $_FILES['media']['error'] === UPLOAD_ERR_OK) {
        $mediaExt = strtolower(pathinfo($_FILES['media']['name'], PATHINFO_EXTENSION));
        
        // Validate file type
        $allowedTypes = ['mp3', 'mp4'];
        if (!in_array($mediaExt, $allowedTypes)) {
            $error = "Invalid file type. Only MP3 and MP4 files are allowed.";
        } else {
            $mediaFilename = $filename . '.' . $mediaExt;
            $mediaPath = $mediaDir . $mediaFilename;
            move_uploaded_file($_FILES['media']['tmp_name'], $mediaPath);
            $mediaType = ($mediaExt === 'mp3') ? 'audio' : 'video';
        }
    }
    
    // Handle cover art upload
    $thumbPath = '';
    if (empty($error) && isset($_FILES['cover']) && $_FILES['cover']['error'] === UPLOAD_ERR_OK) {
        $coverExt = strtolower(pathinfo($_FILES['cover']['name'], PATHINFO_EXTENSION));
        $allowedImageTypes = ['jpg', 'jpeg', 'png', 'gif'];
        if (!in_array($coverExt, $allowedImageTypes)) {
            $error = "Invalid image type. Only JPG, PNG, and GIF are allowed.";
        } else {
            $coverFilename = $artist . '.' . $coverExt;
            $thumbPath = $mediaDir . $coverFilename;
            move_uploaded_file($_FILES['cover']['tmp_name'], $thumbPath);
        }
    }
    
    // If no errors, update JSON
    if (empty($error)) {
        // Load existing JSON data or initialize if empty
        $jsonData = [];
        if (file_exists($jsonFile)) {
            $jsonData = json_decode(file_get_contents($jsonFile), true);
        }
        
        // Create new entry
        $newEntry = [
            'id' => count($jsonData),
            'filename' => basename($mediaPath),
            'filePath' => $mediaPath,
            'title' => $title,
            'artist' => str_replace('_', ' ', $artist),
            'thumbPath' => $thumbPath,
            'type' => $mediaType
        ];
        
        // Add to JSON array
        $jsonData[] = $newEntry;
        
        // Save back to JSON file
        file_put_contents($jsonFile, json_encode($jsonData, JSON_PRETTY_PRINT));
        
        // Success message
        $success = "Upload successful! " . strtoupper($mediaExt) . " file added to data.json.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Media Uploader</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            margin: 0;
            padding: 20px;
            background-color: #f5f5f5;
            color: #333;
        }
        
        .container {
            max-width: 800px;
            margin: 0 auto;
            background: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
        }
        
        h1 {
            color: #2c3e50;
            text-align: center;
            margin-bottom: 30px;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
        }
        
        input[type="text"],
        input[type="file"] {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 16px;
        }
        
        input[type="file"] {
            padding: 5px;
        }
        
        button {
            background-color: #3498db;
            color: white;
            border: none;
            padding: 12px 20px;
            font-size: 16px;
            border-radius: 4px;
            cursor: pointer;
            width: 100%;
            transition: background-color 0.3s;
        }
        
        button:hover {
            background-color: #2980b9;
        }
        
        .success {
            background-color: #2ecc71;
            color: white;
            padding: 15px;
            border-radius: 4px;
            margin-bottom: 20px;
            text-align: center;
        }
        
        .error {
            background-color: #e74c3c;
            color: white;
            padding: 15px;
            border-radius: 4px;
            margin-bottom: 20px;
            text-align: center;
        }
        
        .file-info {
            font-size: 14px;
            color: #7f8c8d;
            margin-top: 5px;
        }
        
        .type-selector {
            display: flex;
            margin-bottom: 15px;
        }
        
        .type-selector label {
            margin-right: 20px;
            cursor: pointer;
            display: flex;
            align-items: center;
        }
        
        .type-selector input {
            margin-right: 5px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Media Uploader</h1>
        
        <?php if (isset($success)): ?>
            <div class="success"><?php echo $success; ?></div>
        <?php endif; ?>
        
        <?php if (isset($error)): ?>
            <div class="error"><?php echo $error; ?></div>
        <?php endif; ?>
        
        <form action="" method="post" enctype="multipart/form-data">
            <div class="form-group">
                <label for="artist">Artist Name</label>
                <input type="text" id="artist" name="artist" required>
                <div class="file-info">Spaces will be replaced with underscores (_)</div>
            </div>
            
            <div class="form-group">
                <label for="title">Track/Video Title</label>
                <input type="text" id="title" name="title" required>
                <div class="file-info">Spaces will be replaced with underscores (_)</div>
            </div>
            
            <div class="form-group">
                <label for="media">Media File (MP3 or MP4)</label>
                <input type="file" id="media" name="media" accept=".mp3,.mp4" required>
                <div class="file-info">File will be renamed to: artist-title.mp3 or artist-title.mp4</div>
            </div>
            
            <div class="form-group">
                <label for="cover">Cover Art (Optional)</label>
                <input type="file" id="cover" name="cover" accept="image/*">
                <div class="file-info">File will be renamed to: artist.jpg/png</div>
            </div>
            
            <button type="submit">Upload Media</button>
        </form>
    </div>
</body>
</html>