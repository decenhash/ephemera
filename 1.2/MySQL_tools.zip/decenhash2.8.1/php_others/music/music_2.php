<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modern Music Playlist</title>
    <style>
        :root {
            --primary: #1db954;
            --dark: #121212;
            --light: #282828;
            --text: #ffffff;
            --text-secondary: #b3b3b3;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background-color: var(--dark);
            color: var(--text);
            min-height: 100vh;
            padding-bottom: 100px;
        }

        header {
            background-color: rgba(0, 0, 0, 0.8);
            padding: 20px;
            text-align: center;
            position: sticky;
            top: 0;
            z-index: 100;
            backdrop-filter: blur(10px);
        }

        h1 {
            font-size: 2.5rem;
            margin-bottom: 10px;
            background: linear-gradient(90deg, var(--primary), #1ed760);
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
        }

        .subtitle {
            color: var(--text-secondary);
            font-size: 1rem;
        }

        .playlist-container {
            max-width: 1200px;
            margin: 40px auto;
            padding: 0 20px;
        }

        .song-list {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 20px;
            margin-top: 30px;
        }

        .song-card {
            background-color: var(--light);
            border-radius: 8px;
            overflow: hidden;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            cursor: pointer;
            position: relative;
        }

        .song-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.3);
        }

        .song-card.active {
            border: 2px solid var(--primary);
        }

        .song-thumb {
            width: 100%;
            height: 200px;
            object-fit: cover;
            display: block;
        }

        .song-info {
            padding: 15px;
        }

        .song-title {
            font-size: 1.1rem;
            margin-bottom: 5px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        .song-artist {
            color: var(--text-secondary);
            font-size: 0.9rem;
        }

        .player-container {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            background: linear-gradient(180deg, rgba(18, 18, 18, 0.8) 0%, var(--dark) 100%);
            padding: 20px;
            display: flex;
            flex-direction: column;
            align-items: center;
            z-index: 100;
            backdrop-filter: blur(10px);
            border-top: 1px solid rgba(255, 255, 255, 0.1);
        }

        .player-info {
            display: flex;
            align-items: center;
            margin-bottom: 15px;
            width: 100%;
            max-width: 800px;
        }

        .player-thumb {
            width: 60px;
            height: 60px;
            object-fit: cover;
            border-radius: 4px;
            margin-right: 15px;
        }

        .player-text {
            flex-grow: 1;
        }

        .player-title {
            font-size: 1.1rem;
            margin-bottom: 5px;
        }

        .player-artist {
            color: var(--text-secondary);
            font-size: 0.9rem;
        }

        .player-controls {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 100%;
            max-width: 800px;
        }

        .control-button {
            background: none;
            border: none;
            color: var(--text);
            font-size: 1.5rem;
            margin: 0 15px;
            cursor: pointer;
            transition: color 0.2s;
        }

        .control-button:hover {
            color: var(--primary);
        }

        .play-button {
            font-size: 2.5rem;
        }

        .progress-container {
            width: 100%;
            max-width: 800px;
            margin-top: 15px;
        }

        .progress-bar {
            width: 100%;
            height: 4px;
            background-color: rgba(255, 255, 255, 0.1);
            border-radius: 2px;
            overflow: hidden;
            margin-bottom: 5px;
        }

        .progress {
            height: 100%;
            background-color: var(--primary);
            width: 0%;
            transition: width 0.1s linear;
        }

        .time-info {
            display: flex;
            justify-content: space-between;
            font-size: 0.8rem;
            color: var(--text-secondary);
        }

        audio {
            display: none;
        }

        @media (max-width: 768px) {
            .song-list {
                grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
            }
            
            .song-thumb {
                height: 150px;
            }
        }
    </style>
</head>
<body>
    <header>
        <h1>Modern Playlist</h1>
        <p class="subtitle">Enjoy your music collection</p>
    </header>

    <div class="playlist-container">
        <div class="song-list">
            <?php
            $musicDir = 'musics/';
            $allowedExtensions = ['mp3'];
            
            // Get all MP3 files from the musics directory
            $musicFiles = [];
            if (is_dir($musicDir)) {
                if ($dh = opendir($musicDir)) {
                    while (($file = readdir($dh)) !== false) {
                        $ext = pathinfo($file, PATHINFO_EXTENSION);
                        if (in_array(strtolower($ext), $allowedExtensions)) {
                            $musicFiles[] = $file;
                        }
                    }
                    closedir($dh);
                }
            }
            
            // Sort files alphabetically
            sort($musicFiles);
            
            // Display each song as a card
            foreach ($musicFiles as $index => $file) {
                $filePath = $musicDir . $file;
                $fileName = pathinfo($file, PATHINFO_FILENAME);
                
                // Extract artist/thumbnail name (text before '-')
                $thumbName = $fileName;
                if (strpos($fileName, '-') !== false) {
                    $parts = explode('-', $fileName, 2);
                    $thumbName = trim($parts[0]);
                }
                
                $thumbPath = $musicDir . $thumbName . '.jpg';
                
                // Default thumbnail if not found
                if (!file_exists($thumbPath)) {
                    $thumbPath = 'https://via.placeholder.com/300x300/282828/ffffff?text=' . urlencode($thumbName);
                }
                
                // Song title (text after '-')
                $songTitle = $fileName;
                if (strpos($fileName, '-') !== false) {
                    $parts = explode('-', $fileName, 2);
                    $songTitle = trim($parts[1]);
                }
                
                echo '<div class="song-card" data-index="' . $index . '" data-file="' . htmlspecialchars($filePath) . '" data-thumb="' . htmlspecialchars($thumbPath) . '">';
                echo '    <img src="' . htmlspecialchars($thumbPath) . '" alt="' . htmlspecialchars($thumbName) . '" class="song-thumb">';
                echo '    <div class="song-info">';
                echo '        <div class="song-title">' . htmlspecialchars($songTitle) . '</div>';
                echo '        <div class="song-artist">' . htmlspecialchars($thumbName) . '</div>';
                echo '    </div>';
                echo '</div>';
            }
            
            if (empty($musicFiles)) {
                echo '<p style="color: var(--text-secondary); grid-column: 1 / -1; text-align: center;">No music files found in the musics folder.</p>';
            }
            ?>
        </div>
    </div>

    <div class="player-container">
        <div class="player-info">
            <img id="player-thumb" src="https://via.placeholder.com/300x300/282828/ffffff?text=No+track" class="player-thumb">
            <div class="player-text">
                <div id="player-title" class="player-title">No track selected</div>
                <div id="player-artist" class="player-artist">Select a song to play</div>
            </div>
        </div>
        <div class="player-controls">
            <button class="control-button" id="prev-button">?</button>
            <button class="control-button" id="play-button">?</button>
            <button class="control-button" id="next-button">?</button>
        </div>
        <div class="progress-container">
            <div class="progress-bar">
                <div class="progress" id="progress-bar"></div>
            </div>
            <div class="time-info">
                <span id="current-time">0:00</span>
                <span id="duration">0:00</span>
            </div>
        </div>
    </div>

    <audio id="audio-player"></audio>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const audioPlayer = document.getElementById('audio-player');
            const playButton = document.getElementById('play-button');
            const prevButton = document.getElementById('prev-button');
            const nextButton = document.getElementById('next-button');
            const progressBar = document.getElementById('progress-bar');
            const currentTimeDisplay = document.getElementById('current-time');
            const durationDisplay = document.getElementById('duration');
            const playerTitle = document.getElementById('player-title');
            const playerArtist = document.getElementById('player-artist');
            const playerThumb = document.getElementById('player-thumb');
            
            const songCards = document.querySelectorAll('.song-card');
            let currentSongIndex = -1;
            let isPlaying = false;
            
            // Format time from seconds to MM:SS
            function formatTime(seconds) {
                const minutes = Math.floor(seconds / 60);
                const secs = Math.floor(seconds % 60);
                return `${minutes}:${secs < 10 ? '0' : ''}${secs}`;
            }
            
            // Update progress bar and time displays
            function updateProgress() {
                const { currentTime, duration } = audioPlayer;
                const progressPercent = (currentTime / duration) * 100;
                progressBar.style.width = `${progressPercent}%`;
                
                currentTimeDisplay.textContent = formatTime(currentTime);
                durationDisplay.textContent = formatTime(duration);
            }
            
            // Set progress bar when clicked
            function setProgress(e) {
                const width = this.clientWidth;
                const clickX = e.offsetX;
                const duration = audioPlayer.duration;
                audioPlayer.currentTime = (clickX / width) * duration;
            }
            
            // Play a song by index
            function playSong(index) {
                if (index < 0 || index >= songCards.length) return;
                
                const songCard = songCards[index];
                const filePath = songCard.dataset.file;
                const thumbPath = songCard.dataset.thumb;
                const songTitle = songCard.querySelector('.song-title').textContent;
                const songArtist = songCard.querySelector('.song-artist').textContent;
                
                // Update UI
                songCards.forEach(card => card.classList.remove('active'));
                songCard.classList.add('active');
                playerTitle.textContent = songTitle;
                playerArtist.textContent = songArtist;
                playerThumb.src = thumbPath;
                
                // Set audio source and play
                audioPlayer.src = filePath;
                audioPlayer.play()
                    .then(() => {
                        isPlaying = true;
                        playButton.textContent = '?';
                        currentSongIndex = index;
                    })
                    .catch(error => {
                        console.error('Playback failed:', error);
                    });
            }
            
            // Play next song
            function playNextSong() {
                const nextIndex = (currentSongIndex + 1) % songCards.length;
                playSong(nextIndex);
            }
            
            // Play previous song
            function playPrevSong() {
                const prevIndex = (currentSongIndex - 1 + songCards.length) % songCards.length;
                playSong(prevIndex);
            }
            
            // Toggle play/pause
            function togglePlay() {
                if (currentSongIndex === -1 && songCards.length > 0) {
                    // If no song is selected, play the first one
                    playSong(0);
                } else if (isPlaying) {
                    audioPlayer.pause();
                    isPlaying = false;
                    playButton.textContent = '?';
                } else {
                    audioPlayer.play()
                        .then(() => {
                            isPlaying = true;
                            playButton.textContent = '?';
                        });
                }
            }
            
            // Event listeners
            songCards.forEach((card, index) => {
                card.addEventListener('click', () => playSong(index));
            });
            
            playButton.addEventListener('click', togglePlay);
            prevButton.addEventListener('click', playPrevSong);
            nextButton.addEventListener('click', playNextSong);
            
            audioPlayer.addEventListener('timeupdate', updateProgress);
            audioPlayer.addEventListener('ended', playNextSong);
            audioPlayer.addEventListener('loadedmetadata', updateProgress);
            
            document.querySelector('.progress-bar').addEventListener('click', function(e) {
                const width = this.clientWidth;
                const clickX = e.offsetX;
                const duration = audioPlayer.duration;
                audioPlayer.currentTime = (clickX / width) * duration;
            });
            
            // Keyboard shortcuts
            document.addEventListener('keydown', function(e) {
                if (e.code === 'Space') {
                    e.preventDefault();
                    togglePlay();
                } else if (e.code === 'ArrowRight') {
                    audioPlayer.currentTime = Math.min(audioPlayer.currentTime + 5, audioPlayer.duration);
                } else if (e.code === 'ArrowLeft') {
                    audioPlayer.currentTime = Math.max(audioPlayer.currentTime - 5, 0);
                } else if (e.code === 'ArrowUp') {
                    playPrevSong();
                } else if (e.code === 'ArrowDown') {
                    playNextSong();
                }
            });
        });
    </script>
</body>
</html>