<?php
// Database connection
$host = 'localhost';
$dbname = 'decenhash';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Create users_decrease table if it doesn't exist
    $createTableSql = "CREATE TABLE IF NOT EXISTS users_decrease (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        username VARCHAR(255) NOT NULL,
        previous_credits DECIMAL(10,2) NOT NULL,
        new_credits DECIMAL(10,2) NOT NULL,
        decrease_amount DECIMAL(10,2) NOT NULL,
        decrease_percentage DECIMAL(5,2) NOT NULL,
        processed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id)
    )";
    $pdo->exec($createTableSql);
    
    // Get all users ordered by credits
    $usersSql = "SELECT id, username, credits FROM users_credit ORDER BY credits ASC";
    $stmt = $pdo->query($usersSql);
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $totalUsers = count($users);
    if ($totalUsers == 0) {
        die("No users found in the database.");
    }
    
    // Calculate bracket boundaries
    $bracket10 = floor($totalUsers * 0.1);
    $bracket30 = floor($totalUsers * 0.3);
    $bracket40 = floor($totalUsers * 0.4);
    $bracket50 = floor($totalUsers * 0.5);
    
    $totalDecrease = 0;
    $processedUsers = [];
    
    // Process each user
    foreach ($users as $index => $user) {
        $originalCredits = $user['credits'];
        $newCredits = $originalCredits;
        $decreasePercentage = 0;
        
        if ($index < $bracket10) {
            // Bottom 10% - lose all credits
            $newCredits = 0;
            $decreasePercentage = 100;
        } elseif ($index < $bracket30) {
            // Between 10% and 30% - lose 75%
            $newCredits = $originalCredits * 0.25;
            $decreasePercentage = 75;
        } elseif ($index < $bracket40) {
            // Between 30% and 40% - lose 50%
            $newCredits = $originalCredits * 0.5;
            $decreasePercentage = 50;
        } elseif ($index < $bracket50) {
            // Between 40% and 50% - lose 25%
            $newCredits = $originalCredits * 0.75;
            $decreasePercentage = 25;
        }
        
        $decreaseAmount = $originalCredits - $newCredits;
        $totalDecrease += $decreaseAmount;
        
        // Update user in database
        $updateSql = "UPDATE users_credit SET credits = :newCredits WHERE id = :userId";
        $updateStmt = $pdo->prepare($updateSql);
        $updateStmt->execute([':newCredits' => $newCredits, ':userId' => $user['id']]);
        
        // Record the change
        $recordSql = "INSERT INTO users_decrease 
                     (user_id, username, previous_credits, new_credits, decrease_amount, decrease_percentage) 
                     VALUES (:userId, :username, :prevCredits, :newCredits, :decreaseAmount, :decreasePercent)";
        $recordStmt = $pdo->prepare($recordSql);
        $recordStmt->execute([
            ':userId' => $user['id'],
            ':username' => $user['username'],
            ':prevCredits' => $originalCredits,
            ':newCredits' => $newCredits,
            ':decreaseAmount' => $decreaseAmount,
            ':decreasePercent' => $decreasePercentage
        ]);
        
        $processedUsers[] = [
            'username' => $user['username'],
            'previous' => $originalCredits,
            'new' => $newCredits,
            'decrease' => $decreaseAmount,
            'percentage' => $decreasePercentage
        ];
    }
    
    // Display results
    echo "<h2>Credit Adjustment Results</h2>";
    echo "<p>Total users processed: $totalUsers</p>";
    echo "<p>Total credits decreased: " . number_format($totalDecrease, 2) . "</p>";
    
    echo "<h3>Bracket Summary:</h3>";
    echo "<ul>";
    echo "<li>Bottom 10% ($bracket10 users): Lost 100% of credits</li>";
    echo "<li>10%-30% (" . ($bracket30 - $bracket10) . " users): Lost 75% of credits</li>";
    echo "<li>30%-40% (" . ($bracket40 - $bracket30) . " users): Lost 50% of credits</li>";
    echo "<li>40%-50% (" . ($bracket50 - $bracket40) . " users): Lost 25% of credits</li>";
    echo "<li>Top 50% (" . ($totalUsers - $bracket50) . " users): No credit reduction</li>";
    echo "</ul>";
    
    echo "<h3>Sample of Processed Users:</h3>";
    echo "<table border='1'>";
    echo "<tr><th>Username</th><th>Previous Credits</th><th>New Credits</th><th>Decrease</th><th>% Decrease</th></tr>";
    
    // Display first 10 and last 10 users for sample
    $sampleUsers = array_merge(
        array_slice($processedUsers, 0, 10),
        array_slice($processedUsers, -10)
    );
    
    foreach ($sampleUsers as $user) {
        echo "<tr>";
        echo "<td>" . htmlspecialchars($user['username']) . "</td>";
        echo "<td>" . number_format($user['previous'], 2) . "</td>";
        echo "<td>" . number_format($user['new'], 2) . "</td>";
        echo "<td>" . number_format($user['decrease'], 2) . "</td>";
        echo "<td>" . $user['percentage'] . "%</td>";
        echo "</tr>";
    }
    echo "</table>";
    
} catch (PDOException $e) {
    die("Database error: " . $e->getMessage());
}
?>