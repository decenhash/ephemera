﻿<?php
// Conexão com o banco de dados
$host = 'localhost';
$dbname = 'decenhash';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Conexão falhou: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ZeroSum Invest | Plataforma de Investimento Competitivo</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #121212;
            --secondary: #1e1e1e;
            --accent: #00b894;
            --light-gray: #2d3436;
            --medium-gray: #636e72;
            --dark-gray: #b2bec3;
            --text: #f5f6fa;
            --text-light: #ffffff;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Roboto', sans-serif;
            color: var(--text);
            background-color: var(--primary);
            line-height: 1.6;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
        }
        
        header {
            background-color: var(--secondary);
            color: var(--text-light);
            padding: 20px 0;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.3);
        }
        
        nav {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .logo {
            font-size: 24px;
            font-weight: 700;
            color: white;
        }
        
        .logo span {
            color: var(--accent);
        }
        
        .nav-links a {
            color: var(--text-light);
            text-decoration: none;
            margin-left: 30px;
            font-weight: 500;
            transition: color 0.3s;
        }
        
        .nav-links a:hover {
            color: var(--accent);
        }
        
        .hero {
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            color: white;
            padding: 80px 0;
            text-align: center;
        }
        
        .hero h1 {
            font-size: 48px;
            margin-bottom: 20px;
            font-weight: 700;
        }
        
        .hero p {
            font-size: 20px;
            max-width: 700px;
            margin: 0 auto 30px;
            opacity: 0.9;
        }
        
        .btn {
            display: inline-block;
            background-color: var(--accent);
            color: white;
            padding: 12px 30px;
            border-radius: 4px;
            text-decoration: none;
            font-weight: 500;
            transition: background-color 0.3s;
            border: none;
            cursor: pointer;
            font-size: 16px;
        }
        
        .btn:hover {
            background-color: #00997a;
        }
        
        .btn-outline {
            background-color: transparent;
            border: 2px solid white;
            margin-left: 15px;
        }
        
        .btn-outline:hover {
            background-color: rgba(255, 255, 255, 0.1);
        }
        
        section {
            padding: 80px 0;
        }
        
        .section-title {
            text-align: center;
            margin-bottom: 50px;
            font-size: 36px;
            font-weight: 700;
            color: var(--accent);
        }
        
        .features {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 30px;
        }
        
        .feature-card {
            background-color: var(--secondary);
            border-radius: 8px;
            padding: 30px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
            transition: transform 0.3s, box-shadow 0.3s;
            border: 1px solid var(--light-gray);
        }
        
        .feature-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.3);
        }
        
        .feature-icon {
            font-size: 40px;
            color: var(--accent);
            margin-bottom: 20px;
        }
        
        .feature-card h3 {
            font-size: 22px;
            margin-bottom: 15px;
            color: var(--text-light);
        }
        
        .how-it-works {
            background-color: var(--light-gray);
        }
        
        .steps {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 30px;
            counter-reset: step-counter;
        }
        
        .step {
            background-color: var(--secondary);
            border-radius: 8px;
            padding: 30px;
            position: relative;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
            border: 1px solid var(--medium-gray);
        }
        
        .step::before {
            counter-increment: step-counter;
            content: counter(step-counter);
            position: absolute;
            top: -20px;
            left: 20px;
            width: 40px;
            height: 40px;
            background-color: var(--accent);
            color: white;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            font-size: 20px;
        }
        
        .step h3 {
            margin-bottom: 15px;
            color: var(--text-light);
        }
        
        .dashboard-preview {
            background-color: var(--secondary);
            color: white;
            text-align: center;
            padding: 60px 0;
        }
        
        .dashboard-image {
            max-width: 100%;
            height: auto;
            border-radius: 8px;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.3);
            margin-top: 30px;
        }
        
        .stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 30px;
            margin-top: 50px;
        }
        
        .stat-item {
            background-color: rgba(0, 184, 148, 0.1);
            padding: 30px;
            border-radius: 8px;
            text-align: center;
            border: 1px solid var(--accent);
        }
        
        .stat-number {
            font-size: 42px;
            font-weight: 700;
            margin-bottom: 10px;
            color: var(--accent);
        }
        
        .stat-label {
            font-size: 16px;
            opacity: 0.8;
        }
        
        footer {
            background-color: var(--secondary);
            color: var(--text-light);
            padding: 50px 0 20px;
        }
        
        .footer-content {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 30px;
            margin-bottom: 40px;
        }
        
        .footer-column h3 {
            font-size: 18px;
            margin-bottom: 20px;
            color: var(--accent);
        }
        
        .footer-column ul {
            list-style: none;
        }
        
        .footer-column ul li {
            margin-bottom: 10px;
        }
        
        .footer-column ul li a {
            color: var(--text-light);
            text-decoration: none;
            opacity: 0.8;
            transition: opacity 0.3s;
        }
        
        .footer-column ul li a:hover {
            opacity: 1;
            color: var(--accent);
        }
        
        .copyright {
            text-align: center;
            padding-top: 20px;
            border-top: 1px solid var(--light-gray);
            opacity: 0.7;
            font-size: 14px;
        }
        
        /* Estilos da tabela de resultados */
        .results-container {
            background-color: var(--secondary);
            padding: 40px;
            border-radius: 8px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
            margin: 40px 0;
            border: 1px solid var(--light-gray);
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }
        
        th, td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid var(--light-gray);
        }
        
        th {
            background-color: var(--accent);
            color: var(--primary);
            font-weight: 500;
        }
        
        tr:nth-child(even) {
            background-color: rgba(255, 255, 255, 0.03);
        }
        
        tr:hover {
            background-color: rgba(0, 184, 148, 0.05);
        }
        
        .bracket-summary {
            background-color: var(--light-gray);
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 30px;
            border: 1px solid var(--medium-gray);
        }
        
        .bracket-summary h3 {
            margin-bottom: 15px;
            color: var(--accent);
        }
        
        .bracket-summary ul {
            list-style-position: inside;
        }
        
        .bracket-summary li {
            margin-bottom: 8px;
        }
    </style>
</head>
<body>
    <header>
        <div class="container">
            <nav>
                <div class="logo">Zero<span>Sum</span></div>
                <div class="nav-links">
                    <a href="#features">Vantagens</a>
                    <a href="#how-it-works">Como Funciona</a>
                    <a href="#results">Resultados</a>
                    <a href="#contact">Contato</a>
                    <a href="#" class="btn">Cadastre-se</a>
                </div>
            </nav>
        </div>
    </header>
    
    <section class="hero">
        <div class="container">
            <h1>Plataforma Revolucionária de Investimento Zero-Sum</h1>
            <p>Nosso algoritmo exclusivo redistribui capital com base no desempenho, criando um ambiente dinâmico e competitivo onde os melhores são recompensados.</p>
            <a href="#" class="btn">Comece Agora</a>
            <a href="#how-it-works" class="btn btn-outline">Saiba Mais</a>
        </div>
    </section>
    
    <section id="features">
        <div class="container">
            <h2 class="section-title">Vantagens do Sistema</h2>
            <div class="features">
                <div class="feature-card">
                    <div class="feature-icon">??</div>
                    <h3>Recompensas por Desempenho</h3>
                    <p>Apenas os 50% melhores investidores mantêm seu saldo integral, com os melhores recebendo créditos adicionais do pool de redistribuição.</p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon">??</div>
                    <h3>Algoritmo Transparente</h3>
                    <p>Nosso sistema usa faixas matemáticas claras para determinar ajustes de crédito, garantindo total transparência no processo.</p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon">??</div>
                    <h3>Rebalanceamento Dinâmico</h3>
                    <p>Ajustes regulares garantem que o sistema recompense continuamente o desempenho atual, não sucessos passados.</p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon">???</div>
                    <h3>Gestão de Risco</h3>
                    <p>O sistema de faixas graduadas protege contra perda total para todos, exceto os de menor desempenho, mantendo incentivos significativos.</p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon">??</div>
                    <h3>Análises Detalhadas</h3>
                    <p>Acompanhamento completo de todos os ajustes de crédito com histórico completo para total responsabilidade.</p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon">??</div>
                    <h3>Vantagem Competitiva</h3>
                    <p>A natureza zero-sum cria um ambiente altamente competitivo que incentiva os participantes a maximizar seu desempenho.</p>
                </div>
            </div>
        </div>
    </section>
    
    <section id="how-it-works" class="how-it-works">
        <div class="container">
            <h2 class="section-title">Como Nosso Sistema Funciona</h2>
            <div class="steps">
                <div class="step">
                    <h3>Classificação dos Usuários</h3>
                    <p>Todos os usuários são classificados com base em seu saldo atual, do menor para o maior.</p>
                </div>
                <div class="step">
                    <h3>Atribuição de Faixas</h3>
                    <p>Os usuários são divididos em faixas de desempenho que determinam sua porcentagem de ajuste.</p>
                </div>
                <div class="step">
                    <h3>Redistribuição de Créditos</h3>
                    <p>Créditos são retirados das faixas de menor desempenho e adicionados ao pool de redistribuição.</p>
                </div>
                <div class="step">
                    <h3>Distribuição de Recompensas</h3>
                    <p>Os 50% melhores recebem porções do pool de redistribuição proporcionais ao seu desempenho.</p>
                </div>
            </div>
        </div>
    </section>
    
    <section class="dashboard-preview">
        <div class="container">
            <h2>Acompanhamento de Desempenho em Tempo Real</h2>
            <p>Nosso painel fornece atualizações ao vivo sobre sua posição e recompensas potenciais.</p>
            <!-- Placeholder para imagem do dashboard -->
            <div class="dashboard-image" style="background-color: rgba(255,255,255,0.1); height: 300px; display: flex; align-items: center; justify-content: center;">
                [Visualização do Painel Interativo]
            </div>
            
            <div class="stats">
                <div class="stat-item">
                    <div class="stat-number">10%</div>
                    <div class="stat-label">Piores perdem 100%</div>
                </div>
                <div class="stat-item">
                    <div class="stat-number">20%</div>
                    <div class="stat-label">Próxima faixa perde 75%</div>
                </div>
                <div class="stat-item">
                    <div class="stat-number">10%</div>
                    <div class="stat-label">Faixa média perde 50%</div>
                </div>
                <div class="stat-item">
                    <div class="stat-number">10%</div>
                    <div class="stat-label">Faixa superior perde 25%</div>
                </div>
                <div class="stat-item">
                    <div class="stat-number">50%</div>
                    <div class="stat-label">Melhores mantêm 100%+</div>
                </div>
            </div>
        </div>
    </section>
    
    <section id="results" class="container">
        <h2 class="section-title">Resultados do Sistema</h2>
        <p style="text-align: center; max-width: 800px; margin: 0 auto 40px;">Abaixo estão os resultados reais do nosso ciclo mais recente de redistribuição, demonstrando a operação transparente do sistema.</p>
        
        <div class="results-container">
            <?php
            try {
                // Criar tabela users_decrease se não existir
                $createTableSql = "CREATE TABLE IF NOT EXISTS users_decrease (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    user_id INT NOT NULL,
                    username VARCHAR(255) NOT NULL,
                    previous_credits DECIMAL(10,2) NOT NULL,
                    new_credits DECIMAL(10,2) NOT NULL,
                    decrease_amount DECIMAL(10,2) NOT NULL,
                    decrease_percentage DECIMAL(5,2) NOT NULL,
                    processed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (user_id) REFERENCES users(id)
                )";
                $pdo->exec($createTableSql);
                
                // Obter todos os usuários ordenados por créditos
                $usersSql = "SELECT id, username, credits FROM users_credit ORDER BY credits ASC";
                $stmt = $pdo->query($usersSql);
                $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
                
                $totalUsers = count($users);
                if ($totalUsers > 0) {
                    // Calcular limites das faixas
                    $bracket10 = floor($totalUsers * 0.1);
                    $bracket30 = floor($totalUsers * 0.3);
                    $bracket40 = floor($totalUsers * 0.4);
                    $bracket50 = floor($totalUsers * 0.5);
                    
                    $totalDecrease = 0;
                    $processedUsers = [];
                    
                    // Processar cada usuário
                    foreach ($users as $index => $user) {
                        $originalCredits = $user['credits'];
                        $newCredits = $originalCredits;
                        $decreasePercentage = 0;
                        
                        if ($index < $bracket10) {
                            // 10% inferiores - perdem todos os créditos
                            $newCredits = 0;
                            $decreasePercentage = 100;
                        } elseif ($index < $bracket30) {
                            // Entre 10% e 30% - perdem 75%
                            $newCredits = $originalCredits * 0.25;
                            $decreasePercentage = 75;
                        } elseif ($index < $bracket40) {
                            // Entre 30% e 40% - perdem 50%
                            $newCredits = $originalCredits * 0.5;
                            $decreasePercentage = 50;
                        } elseif ($index < $bracket50) {
                            // Entre 40% e 50% - perdem 25%
                            $newCredits = $originalCredits * 0.75;
                            $decreasePercentage = 25;
                        }
                        
                        $decreaseAmount = $originalCredits - $newCredits;
                        $totalDecrease += $decreaseAmount;
                        
                        // Atualizar usuário no banco de dados
                        $updateSql = "UPDATE users_credit SET credits = :newCredits WHERE id = :userId";
                        $updateStmt = $pdo->prepare($updateSql);
                        $updateStmt->execute([':newCredits' => $newCredits, ':userId' => $user['id']]);
                        
                        // Registrar a mudança
                        $recordSql = "INSERT INTO users_decrease 
                                     (user_id, username, previous_credits, new_credits, decrease_amount, decrease_percentage) 
                                     VALUES (:userId, :username, :prevCredits, :newCredits, :decreaseAmount, :decreasePercent)";
                        $recordStmt = $pdo->prepare($recordSql);
                        $recordStmt->execute([
                            ':userId' => $user['id'],
                            ':username' => $user['username'],
                            ':prevCredits' => $originalCredits,
                            ':newCredits' => $newCredits,
                            ':decreaseAmount' => $decreaseAmount,
                            ':decreasePercent' => $decreasePercentage
                        ]);
                        
                        $processedUsers[] = [
                            'username' => $user['username'],
                            'previous' => $originalCredits,
                            'new' => $newCredits,
                            'decrease' => $decreaseAmount,
                            'percentage' => $decreasePercentage
                        ];
                    }
                    
                    echo "<div class='bracket-summary'>";
                    echo "<h3>Resumo da Redistribuição</h3>";
                    echo "<p>Total de usuários processados: <strong>$totalUsers</strong></p>";
                    echo "<p>Total de créditos redistribuídos: <strong>" . number_format($totalDecrease, 2) . "</strong></p>";
                    
                    echo "<h4>Detalhamento por Faixa:</h4>";
                    echo "<ul>";
                    echo "<li>10% inferiores ($bracket10 usuários): Perderam 100% dos créditos</li>";
                    echo "<li>10%-30% (" . ($bracket30 - $bracket10) . " usuários): Perderam 75% dos créditos</li>";
                    echo "<li>30%-40% (" . ($bracket40 - $bracket30) . " usuários): Perderam 50% dos créditos</li>";
                    echo "<li>40%-50% (" . ($bracket50 - $bracket40) . " usuários): Perderam 25% dos créditos</li>";
                    echo "<li>50% melhores (" . ($totalUsers - $bracket50) . " usuários): Sem redução + recompensas</li>";
                    echo "</ul>";
                    echo "</div>";
                    
                    echo "<div style='overflow-x: auto;'>";
                    echo "<table>";
                    echo "<thead>";
                    echo "<tr>";
                    echo "<th>Posição</th>";
                    echo "<th>Usuário</th>";
                    echo "<th>Créditos Anteriores</th>";
                    echo "<th>Novos Créditos</th>";
                    echo "<th>Redução</th>";
                    echo "<th>% Redução</th>";
                    echo "<th>Faixa</th>";
                    echo "</tr>";
                    echo "</thead>";
                    echo "<tbody>";
                    
                    foreach ($processedUsers as $index => $user) {
                        // Determinar faixa para exibição
                        $bracket = "";
                        if ($index < $bracket10) {
                            $bracket = "10% inferiores (100% perda)";
                        } elseif ($index < $bracket30) {
                            $bracket = "10-30% (75% perda)";
                        } elseif ($index < $bracket40) {
                            $bracket = "30-40% (50% perda)";
                        } elseif ($index < $bracket50) {
                            $bracket = "40-50% (25% perda)";
                        } else {
                            $bracket = "50% melhores (sem perda + recompensas)";
                        }
                        
                        echo "<tr>";
                        echo "<td>" . ($index + 1) . "</td>";
                        echo "<td>" . htmlspecialchars($user['username']) . "</td>";
                        echo "<td>" . number_format($user['previous'], 2) . "</td>";
                        echo "<td>" . number_format($user['new'], 2) . "</td>";
                        echo "<td>" . number_format($user['decrease'], 2) . "</td>";
                        echo "<td>" . $user['percentage'] . "%</td>";
                        echo "<td>" . $bracket . "</td>";
                        echo "</tr>";
                    }
                    
                    echo "</tbody>";
                    echo "</table>";
                    echo "</div>";
                    
                    echo "<p style='margin-top: 20px; font-style: italic;'>Redistribuição de créditos concluída com sucesso. O sistema garante motivação contínua para todos os participantes melhorarem seu desempenho.</p>";
                } else {
                    echo "<p>Nenhum usuário encontrado no banco de dados. O sistema processará os créditos assim que houver participantes registrados.</p>";
                }
            } catch (PDOException $e) {
                echo "<p>Erro ao exibir resultados: " . $e->getMessage() . "</p>";
            }
            ?>
        </div>
    </section>
    
    <section id="contact" style="background-color: var(--light-gray);">
        <div class="container" style="text-align: center;">
            <h2 class="section-title">Pronto para Entrar na Competição?</h2>
            <p style="max-width: 600px; margin: 0 auto 30px;">Nossa plataforma de investimento zero-sum recompensa habilidade e estratégia. Cadastre-se hoje para começar a competir.</p>
            <a href="#" class="btn" style="font-size: 18px; padding: 15px 40px;">Comece Agora</a>
        </div>
    </section>
    
    <footer>
        <div class="container">
            <div class="footer-content">
                <div class="footer-column">
                    <h3>ZeroSum Invest</h3>
                    <p style="opacity: 0.8; margin-top: 15px;">Uma plataforma de investimento revolucionária que cria competição real e recompensa os melhores.</p>
                </div>
                <div class="footer-column">
                    <h3>Links Rápidos</h3>
                    <ul>
                        <li><a href="#features">Vantagens</a></li>
                        <li><a href="#how-it-works">Como Funciona</a></li>
                        <li><a href="#results">Resultados Recentes</a></li>
                        <li><a href="#">FAQ</a></li>
                    </ul>
                </div>
                <div class="footer-column">
                    <h3>Legal</h3>
                    <ul>
                        <li><a href="#">Termos de Serviço</a></li>
                        <li><a href="#">Política de Privacidade</a></li>
                        <li><a href="#">Aviso de Risco</a></li>
                    </ul>
                </div>
                <div class="footer-column">
                    <h3>Contato</h3>
                    <ul>
                        <li><a href="mailto:info@zerosuminvest.com.br">info@zerosuminvest.com.br</a></li>
                        <li><a href="tel:+5511999999999">+55 (11) 99999-9999</a></li>
                    </ul>
                </div>
            </div>
            <div class="copyright">
                &copy; <?php echo date("Y"); ?> ZeroSum Invest. Todos os direitos reservados.
            </div>
        </div>
    </footer>
</body>
</html>