<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Link and Title Processor</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;700&display=swap" rel="stylesheet">
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        body {
            font-family: 'Inter', sans-serif;
        }
    </style>
</head>
<body class="bg-gray-100 text-gray-800">

    <div class="container mx-auto p-4 sm:p-6 lg:p-8 max-w-2xl">
        <div class="bg-white shadow-lg rounded-xl p-6 sm:p-8">
            <h1 class="text-2xl sm:text-3xl font-bold text-center text-gray-900 mb-6">Link and Title Indexer</h1>

            <?php
            // --- PHP PROCESSING LOGIC ---

            // Directory paths
            $json_search_dir = 'json_search';
            $json_hash_dir = 'json_search_hash';

            // Create directories if they don't exist
            if (!is_dir($json_search_dir)) {
                mkdir($json_search_dir, 0777, true);
            }
            if (!is_dir($json_hash_dir)) {
                mkdir($json_hash_dir, 0777, true);
            }

            // --- Function to generate substrings ---
            /**
             * Generates all substrings of a given word that are 3 or more characters long.
             * @param string $word The input word.
             * @return array An array of unique substrings.
             */
            function generate_substrings($word) {
                $substrings = [];
                $len = strlen($word);
                if ($len < 3) {
                    return [];
                }
                for ($i = 0; $i < $len; $i++) {
                    for ($j = $i + 2; $j < $len; $j++) {
                        $substrings[] = substr($word, $i, $j - $i + 1);
                    }
                }
                // Using array_unique to avoid duplicate entries if a word has repeating patterns
                return array_unique($substrings);
            }

            // --- Handle form submission ---
            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                $link = isset($_POST['link']) ? trim($_POST['link']) : '';
                $title = isset($_POST['title']) ? trim($_POST['title']) : '';

                // Basic validation
                if (empty($link) || empty($title)) {
                    echo '<div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 rounded-md mb-6" role="alert"><p><strong>Error:</strong> Both link and title are required.</p></div>';
                } elseif (!filter_var($link, FILTER_VALIDATE_URL)) {
                    echo '<div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 rounded-md mb-6" role="alert"><p><strong>Error:</strong> Please enter a valid URL.</p></div>';
                } else {
                    // --- Main Logic ---

                    // 1. Calculate SHA-256 hash of the link
                    $link_hash = hash('sha256', $link);
                    $hash_file_path = $json_hash_dir . '/' . $link_hash;

                    // 2. Check if the hash file exists
                    if (file_exists($hash_file_path)) {
                        // Show error message if link is already indexed
                        echo '<div class="bg-yellow-100 border-l-4 border-yellow-500 text-yellow-700 p-4 rounded-md mb-6" role="alert"><p><strong>Info:</strong> This link has already been processed.</p></div>';
                    } else {
                        // 3. Sanitize the title
                        // Replace non-alphanumeric characters (except underscore) with an underscore
                        $sanitized_title = preg_replace('/[^\p{L}\p{N}_]+/u', '_', $title);
                        // Replace multiple underscores with a single one
                        $sanitized_title = preg_replace('/__+/', '_', $sanitized_title);

                        // 4. Explode the title into words
                        $words = explode('_', $sanitized_title);

                        $all_substrings = [];
                        foreach ($words as $word){

                            // Avoid filename with only numbers
                            if (is_numeric($word)) {
                                continue;
                            }

                            // Avoid filename with numbers 
                            if (preg_match('/[0-9]/', $word)) {
                                continue;
                            }
         
                            // Convert to lowercase for consistent indexing
                            $word_lower = strtolower($word);
                            if (strlen($word_lower) >= 3) {
                                $substrings = generate_substrings($word_lower);
                                $all_substrings = array_merge($all_substrings, $substrings);
                            }
                        }
                        // Ensure all substrings are unique across the entire title
                        $all_substrings = array_unique($all_substrings);

                        // 5. Create JSON files for each subword
                        $data_to_store = ['link' => $link, 'title' => $title];
                        $files_created_count = 0;

                        foreach ($all_substrings as $subword) {
                            $json_file_path = $json_search_dir . '/' . $subword . '.json';

                            $entries = [];
                            // If file exists, read its content
                            if (file_exists($json_file_path)) {
                                $current_data = file_get_contents($json_file_path);
                                $entries = json_decode($current_data, true);
                                // Ensure it's an array
                                if (!is_array($entries)) {
                                    $entries = [];
                                }
                            }

                            // Add new data to the array
                            $entries[] = $data_to_store;

                            // Write the updated array back to the JSON file
                            $file_handle = fopen($json_file_path, 'w');
                            if ($file_handle) {
                                fwrite($file_handle, json_encode($entries, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
                                fclose($file_handle);
                                $files_created_count++;
                            }
                        }

                        // 6. Create the hash file to mark this link as processed
                        touch($hash_file_path);

                        // Show success message
                        echo '<div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 rounded-md mb-6" role="alert">';
                        echo '<p class="font-bold">Success!</p>';
                        echo "<p>The link has been indexed. We generated <strong>" . count($all_substrings) . "</strong> unique search keys.</p>";
                        echo '</div>';
                    }
                }
            }
            ?>

            <!-- HTML FORM -->
            <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">
                <div class="mb-6">
                    <label for="link" class="block mb-2 text-sm font-medium text-gray-700">Enter URL</label>
                    <input type="url" id="link" name="link" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5" placeholder="https://example.com" required>
                </div>
                <div class="mb-6">
                    <label for="title" class="block mb-2 text-sm font-medium text-gray-700">Enter Title</label>
                    <input type="text" id="title" name="title" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5" placeholder="e.g., An Example Title for Computing" required>
                </div>
                <button type="submit" class="text-white bg-blue-600 hover:bg-blue-700 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm w-full sm:w-auto px-5 py-2.5 text-center transition-colors duration-200">
                    Process and Index
                </button>
            </form>
        </div>
        <footer class="text-center text-gray-500 text-xs mt-6">
            <p>All rights reserved.</p>
        </footer>
    </div>

</body>
</html>
