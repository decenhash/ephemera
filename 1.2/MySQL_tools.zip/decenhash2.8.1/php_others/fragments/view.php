﻿<?php

$folder = "fragments";

// Check if the 'key' parameter is present in the GET request
if(isset($_GET['key'])){
    $file = $_GET['key'];

    // Read chunks from the key file
    $chunks = file_get_contents("keys/$file");

    // Explode the chunks into an array
    $chunk = explode(",", $chunks);

    $chunk_data = "";

    // Iterate over the chunks
    foreach ($chunk as $chunk_id) {
        // Check if the chunk exists
        if(file_exists("$folder/$chunk_id")){
            // Append chunk data to the result
            $chunk_data .= file_get_contents("$folder/$chunk_id");
        }
    }

    // Depending on the file type, you must change the header
    $header = 'data:image/jpg;base64;,';
    
    // Output the image
    echo "<img src='$header$chunk_data'>";
} else {
    // If 'key' parameter is not present
    echo "Error: 'key' parameter is missing";
}

?>
