﻿<?php
// Set default language to Portuguese
$lang = isset($_GET['lang']) && $_GET['lang'] === 'en' ? 'en' : 'pt';

// Translations
$translations = [
    'pt' => [
        'page_title' => 'Adicionar Freelancer/Produto',
        'form_title' => 'Adicionar Novo Item',
        'main_category' => 'Categoria Principal',
        'sub_category' => 'Subcategoria',
        'title' => 'Título',
        'description' => 'Descrição',
        'price' => 'Preço',
        'image_url' => 'URL da Imagem',
        'freelancer_name' => 'Nome do Freelancer',
        'project_url' => 'URL do Projeto/Portfólio',
        'whatsapp' => 'WhatsApp (apenas números)',
        'email' => 'Email',
        'highlight' => 'Destacar este item?',
        'submit' => 'Enviar',
        'success' => 'Item adicionado com sucesso!',
        'error' => 'Erro ao adicionar item.',
        'categories' => [
            'products' => 'Produtos Prontos',
            'freelancers' => 'Freelancers'
        ],
        'subcategories' => [
            'code' => 'Código',
            'image' => 'Imagem',
            'video' => 'Vídeo',
            'text' => 'Texto',
            'speech' => 'Fala',
            'agents' => 'Agentes',
            'data' => 'Dados',
            'packs' => 'Pacotes',
            'full-websites' => 'Sites Completos',
            'music' => 'Música',            
            'integrations' => 'Integrações',
            'others' => 'Outros',
        ]
    ],
    'en' => [
        'page_title' => 'Add Freelancer/Product',
        'form_title' => 'Add New Item',
        'main_category' => 'Main Category',
        'sub_category' => 'Subcategory',
        'title' => 'Title',
        'description' => 'Description',
        'price' => 'Price',
        'image_url' => 'Image URL',
        'freelancer_name' => 'Freelancer Name',
        'project_url' => 'Project/Portfolio URL',
        'whatsapp' => 'WhatsApp (numbers only)',
        'email' => 'Email',
        'highlight' => 'Highlight this item?',
        'submit' => 'Submit',
        'success' => 'Item added successfully!',
        'error' => 'Error adding item.',
        'categories' => [
            'products' => 'AI Products',
            'freelancers' => 'Freelancers'
        ],
        'subcategories' => [
            'code' => 'Code',
            'image' => 'Image',
            'video' => 'Video',
            'text' => 'Text',
            'speech' => 'Speech',
            'agents' => 'Agents',
            'data' => 'Data',
            'packs' => 'Packs',
            'full-websites' => 'Full Websites',
            'music' => 'Music',            
            'integrations' => 'Integrations',
            'others' => 'Others',
        ]
    ]
];

// Handle form submission
$message = '';
$message_type = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate required fields
    $required_fields = ['main_category', 'sub_category', 'title', 'description', 'price'];
    $valid = true;
    
    foreach ($required_fields as $field) {
        if (empty($_POST[$field])) {
            $valid = false;
            break;
        }
    }
    
    if ($valid) {
        // Prepare data
        $new_item = [
            'title' => $_POST['title'],
            'description' => $_POST['description'],
            'price' => $_POST['price'],
            'image' => $_POST['image_url'] ?? '',
            'highlighted' => isset($_POST['highlight']) ? true : false,
            'date' => date('Y-m-d'), // Automatically add current date
            'url' => $_POST['project_url'] ?? '',
            'mail' => $_POST['email'] ?? ''
        ];
        
        // Add freelancer name if provided
        if (!empty($_POST['freelancer_name'])) {
            $new_item['freelancer_name'] = $_POST['freelancer_name'];
        }
        
        // Add WhatsApp if provided
        if (!empty($_POST['whatsapp'])) {
            $new_item['whatsapp'] = preg_replace('/[^0-9]/', '', $_POST['whatsapp']);
        }
        
        // Determine filename based on categories
        $main_category = $_POST['main_category'];
        $sub_category = $_POST['sub_category'];
        
        if ($main_category === 'products') {
            $filename = "json_freelancer/product_{$sub_category}.json";
        } else {
            $filename = "json_freelancer/freelance_{$sub_category}.json";
        }
        
        // Load existing data or create new array
        $data = [];
        if (file_exists($filename)) {
            $json_content = file_get_contents($filename);
            $data = json_decode($json_content, true);
            if (!is_array($data)) {
                $data = [];
            }
        }
        
        // Add new item
        array_unshift($data, $new_item);
        
        // Save back to file
        if (file_put_contents($filename, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES))) {
            $message = $translations[$lang]['success'];
            $message_type = 'success';
            
            // Clear form (except categories)
            $_POST = [
                'main_category' => $_POST['main_category'],
                'sub_category' => $_POST['sub_category']
            ];
        } else {
            $message = $translations[$lang]['error'];
            $message_type = 'error';
        }
    } else {
        $message = $translations[$lang]['error'];
        $message_type = 'error';
    }
}
?>

<!DOCTYPE html>
<html lang="<?php echo $lang; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $translations[$lang]['page_title']; ?></title>
    <style>
        :root {
            --primary-color: #4a6bff;
            --secondary-color: #f8f9fa;
            --dark-color: #343a40;
            --light-color: #ffffff;
            --success-color: #28a745;
            --error-color: #dc3545;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
            background-color: var(--secondary-color);
            color: var(--dark-color);
            line-height: 1.6;
        }
        
        .container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
        }
        
        header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            padding-bottom: 15px;
            border-bottom: 1px solid #ddd;
        }
        
        h1 {
            color: var(--primary-color);
            margin: 0;
        }
        
        .language-switcher {
            display: flex;
            gap: 10px;
        }
        
        .language-btn {
            padding: 5px 10px;
            background: none;
            border: 1px solid #ddd;
            border-radius: 4px;
            cursor: pointer;
            text-decoration: none;
            color: var(--dark-color);
        }
        
        .language-btn.active {
            background-color: var(--primary-color);
            color: white;
            border-color: var(--primary-color);
        }
        
        .language-btn:hover:not(.active) {
            background-color: #eee;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        label {
            display: block;
            margin-bottom: 5px;
            font-weight: 600;
        }
        
        input[type="text"],
        input[type="number"],
        input[type="url"],
        input[type="email"],
        textarea,
        select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 16px;
            box-sizing: border-box;
        }
        
        textarea {
            min-height: 100px;
            resize: vertical;
        }
        
        .checkbox-group {
            display: flex;
            align-items: center;
        }
        
        .checkbox-group input {
            margin-right: 10px;
        }
        
        button[type="submit"] {
            background-color: var(--primary-color);
            color: white;
            border: none;
            padding: 12px 20px;
            border-radius: 4px;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        
        button[type="submit"]:hover {
            background-color: #3a5bd9;
        }
        
        .message {
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 4px;
        }
        
        .success {
            background-color: #d4edda;
            color: var(--success-color);
            border: 1px solid #c3e6cb;
        }
        
        .error {
            background-color: #f8d7da;
            color: var(--error-color);
            border: 1px solid #f5c6cb;
        }
        
        .two-columns {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }
        
        @media (max-width: 600px) {
            .two-columns {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <header>
            <h1><?php echo $translations[$lang]['form_title']; ?></h1>
            <div class="language-switcher">
                <a href="?lang=pt" class="language-btn <?php echo $lang === 'pt' ? 'active' : ''; ?>">Português</a>
                <a href="?lang=en" class="language-btn <?php echo $lang === 'en' ? 'active' : ''; ?>">English</a>
            </div>
        </header>
        
        <?php if ($message): ?>
            <div class="message <?php echo $message_type; ?>">
                <?php echo $message; ?>
            </div>
        <?php endif; ?>
        
        <form method="POST" action="">
            <div class="two-columns">
                <div class="form-group">
                    <label for="main_category"><?php echo $translations[$lang]['main_category']; ?></label>
                    <select id="main_category" name="main_category" required>
                        <?php foreach ($translations[$lang]['categories'] as $key => $category): ?>
                            <option value="<?php echo $key; ?>" <?php echo (isset($_POST['main_category']) && $_POST['main_category'] === $key) ? 'selected' : ''; ?>>
                                <?php echo $category; ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="sub_category"><?php echo $translations[$lang]['sub_category']; ?></label>
                    <select id="sub_category" name="sub_category" required>
                        <?php foreach ($translations[$lang]['subcategories'] as $key => $subcategory): ?>
                            <option value="<?php echo $key; ?>" <?php echo (isset($_POST['sub_category']) && $_POST['sub_category'] === $key) ? 'selected' : ''; ?>>
                                <?php echo $subcategory; ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>
            
            <div class="form-group">
                <label for="title"><?php echo $translations[$lang]['title']; ?></label>
                <input type="text" id="title" name="title" value="<?php echo htmlspecialchars($_POST['title'] ?? ''); ?>" required>
            </div>
            
            <div class="form-group">
                <label for="description"><?php echo $translations[$lang]['description']; ?></label>
                <textarea id="description" name="description" required><?php echo htmlspecialchars($_POST['description'] ?? ''); ?></textarea>
            </div>
            
            <div class="form-group">
                <label for="price"><?php echo $translations[$lang]['price']; ?></label>
                <input type="number" id="price" name="price" step="0.01" min="0" value="<?php echo htmlspecialchars($_POST['price'] ?? ''); ?>" required>
            </div>
            
            <div class="form-group">
                <label for="image_url"><?php echo $translations[$lang]['image_url']; ?></label>
                <input type="url" id="image_url" name="image_url" value="<?php echo htmlspecialchars($_POST['image_url'] ?? ''); ?>">
            </div>
            
            <div class="form-group">
                <label for="freelancer_name"><?php echo $translations[$lang]['freelancer_name']; ?></label>
                <input type="text" id="freelancer_name" name="freelancer_name" value="<?php echo htmlspecialchars($_POST['freelancer_name'] ?? ''); ?>">
            </div>
            
            <div class="form-group">
                <label for="project_url"><?php echo $translations[$lang]['project_url']; ?></label>
                <input type="url" id="project_url" name="project_url" value="<?php echo htmlspecialchars($_POST['project_url'] ?? ''); ?>">
            </div>
            
            <div class="two-columns">
                <div class="form-group">
                    <label for="whatsapp"><?php echo $translations[$lang]['whatsapp']; ?></label>
                    <input type="text" id="whatsapp" name="whatsapp" value="<?php echo htmlspecialchars($_POST['whatsapp'] ?? ''); ?>">
                </div>
                
                <div class="form-group">
                    <label for="email"><?php echo $translations[$lang]['email']; ?></label>
                    <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>">
                </div>
            </div>
            
            <button type="submit"><?php echo $translations[$lang]['submit']; ?></button>
        </form>
    </div>
</body>
</html>