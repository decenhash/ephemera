<?php
// index.php
$imagesDirectory = 'images/';
$likesDirectory = 'likes/';

// Create likes directory if it doesn't exist
if (!file_exists($likesDirectory)) {
    mkdir($likesDirectory, 0755, true);
}

// Get all image files from the images directory
$allowedExtensions = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
$images = [];

if (file_exists($imagesDirectory) && is_dir($imagesDirectory)) {
    $files = scandir($imagesDirectory);
    
    foreach ($files as $file) {
        $extension = strtolower(pathinfo($file, PATHINFO_EXTENSION));
        if ($file !== '.' && $file !== '..' && in_array($extension, $allowedExtensions)) {
            $images[] = $file;
        }
    }
}

// Get client IP address
function getClientIP() {
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        return $_SERVER['HTTP_CLIENT_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        return $_SERVER['HTTP_X_FORWARDED_FOR'];
    } else {
        return $_SERVER['REMOTE_ADDR'];
    }
}

// Handle image like/dislike
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && isset($_POST['image'])) {
    $image = $_POST['image'];
    $action = $_POST['action'];
    
    if ($action === 'like') {
        $userIP = getClientIP();
        $salt = "start";
        $hash = hash('sha256', $userIP . $salt);
        
        // Create a file in the likes directory
        file_put_contents($likesDirectory . $hash . '_' . $image, '');
        echo json_encode(['status' => 'success']);
        exit;
    }
    
    echo json_encode(['status' => 'success']);
    exit;
}

// Select default image (first one) or use the one from the query parameter
$selectedImage = isset($_GET['image']) && in_array($_GET['image'], $images) ? $_GET['image'] : (count($images) > 0 ? $images[0] : '');

// Get URL for selected image
$selectedImageUrl = $selectedImage ? $imagesDirectory . $selectedImage : '';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Image Viewer</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f0f2f5;
            color: #333;
        }
        
        .container {
            display: flex;
            height: 100vh;
        }
        
        .sidebar {
            width: 250px;
            background-color: #fff;
            border-right: 1px solid #e0e0e0;
            overflow-y: auto;
            transition: transform 0.3s ease;
        }
        
        .sidebar-header {
            padding: 20px;
            background-color: #4a6fa5;
            color: white;
            font-weight: bold;
            text-align: center;
        }
        
        .image-list {
            list-style: none;
        }
        
        .image-item {
            padding: 12px 20px;
            cursor: pointer;
            border-bottom: 1px solid #f0f0f0;
            transition: background-color 0.2s;
            display: flex;
            align-items: center;
        }
        
        .image-item:hover {
            background-color: #f8f9fa;
        }
        
        .image-item.active {
            background-color: #e6f0ff;
            border-left: 4px solid #4a6fa5;
        }
        
        .image-item-thumbnail {
            width: 40px;
            height: 40px;
            margin-right: 10px;
            object-fit: cover;
            border-radius: 4px;
        }
        
        .image-item-name {
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        
        .viewer {
            flex-grow: 1;
            position: relative;
            display: flex;
            align-items: center;
            justify-content: center;
            background-color: #1a1a1a;
            overflow: hidden;
        }
        
        .fullscreen-image {
            max-width: 100%;
            max-height: 100%;
            object-fit: contain;
        }
        
        .no-image {
            color: #777;
            font-size: 1.2em;
        }
        
        .rating-controls {
            position: absolute;
            bottom: 20px;
            right: 20px;
            background-color: rgba(0, 0, 0, 0.6);
            padding: 10px;
            border-radius: 50px;
            display: flex;
            gap: 15px;
        }
        
        .rating-btn {
            background: none;
            border: none;
            color: white;
            font-size: 24px;
            cursor: pointer;
            transition: transform 0.2s, color 0.2s;
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .rating-btn:hover {
            transform: scale(1.2);
        }
        
        .like-btn:hover {
            color: #4CAF50;
        }
        
        .dislike-btn:hover {
            color: #F44336;
        }
        
        .toggle-sidebar {
            position: absolute;
            top: 10px;
            left: 10px;
            background-color: rgba(0, 0, 0, 0.6);
            color: white;
            border: none;
            border-radius: 50%;
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            z-index: 100;
        }
        
        .toast {
            position: fixed;
            top: 20px;
            left: 50%;
            transform: translateX(-50%);
            background-color: rgba(0, 0, 0, 0.8);
            color: white;
            padding: 10px 20px;
            border-radius: 4px;
            opacity: 0;
            transition: opacity 0.3s;
            z-index: 1000;
        }
        
        .toast.show {
            opacity: 1;
        }
        
        @media (max-width: 768px) {
            .container {
                flex-direction: column;
            }
            
            .sidebar {
                width: 100%;
                height: 200px;
                border-right: none;
                border-bottom: 1px solid #e0e0e0;
            }
            
            .sidebar.hidden {
                transform: translateY(-100%);
            }
            
            .toggle-sidebar {
                top: auto;
                bottom: 10px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="sidebar" id="sidebar">
            <div class="sidebar-header">Image Gallery</div>
            <ul class="image-list">
                <?php if (count($images) > 0): ?>
                    <?php foreach ($images as $image): ?>
                        <li class="image-item <?php echo $image === $selectedImage ? 'active' : ''; ?>" 
                            data-image="<?php echo htmlspecialchars($image); ?>">
                            <img class="image-item-thumbnail" 
                                 src="<?php echo htmlspecialchars($imagesDirectory . $image); ?>" 
                                 alt="<?php echo htmlspecialchars($image); ?>">
                            <span class="image-item-name"><?php echo htmlspecialchars($image); ?></span>
                        </li>
                    <?php endforeach; ?>
                <?php else: ?>
                    <li class="image-item">No images found</li>
                <?php endif; ?>
            </ul>
        </div>
        
        <div class="viewer">
            <button class="toggle-sidebar" id="toggleSidebar">
                <i class="fas fa-bars"></i>
            </button>
            
            <?php if ($selectedImage): ?>
                <img class="fullscreen-image" 
                     src="<?php echo htmlspecialchars($selectedImageUrl); ?>" 
                     alt="<?php echo htmlspecialchars($selectedImage); ?>" 
                     id="fullscreenImage">
                     
                <div class="rating-controls">
                    <button class="rating-btn like-btn" title="Like" id="likeBtn">
                        <i class="fas fa-thumbs-up"></i>
                    </button>
                    <button class="rating-btn dislike-btn" title="Dislike" id="dislikeBtn">
                        <i class="fas fa-thumbs-down"></i>
                    </button>
                </div>
            <?php else: ?>
                <div class="no-image">No images available</div>
            <?php endif; ?>
        </div>
    </div>
    
    <div class="toast" id="toast"></div>
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const sidebar = document.getElementById('sidebar');
            const toggleSidebar = document.getElementById('toggleSidebar');
            const imageItems = document.querySelectorAll('.image-item');
            const likeBtn = document.getElementById('likeBtn');
            const dislikeBtn = document.getElementById('dislikeBtn');
            const toast = document.getElementById('toast');
            
            // Toggle sidebar
            toggleSidebar.addEventListener('click', function() {
                sidebar.classList.toggle('hidden');
            });
            
            // Image selection
            imageItems.forEach(item => {
                item.addEventListener('click', function() {
                    const image = this.getAttribute('data-image');
                    window.location.href = `?image=${encodeURIComponent(image)}`;
                });
            });
            
            // Show toast notification
            function showToast(message, duration = 2000) {
                toast.textContent = message;
                toast.classList.add('show');
                
                setTimeout(() => {
                    toast.classList.remove('show');
                }, duration);
            }
            
            // Handle like/dislike actions
            if (likeBtn && dislikeBtn) {
                likeBtn.addEventListener('click', function() {
                    rateImage('like');
                });
                
                dislikeBtn.addEventListener('click', function() {
                    rateImage('dislike');
                });
                
                function rateImage(action) {
                    const urlParams = new URLSearchParams(window.location.search);
                    const selectedImage = urlParams.get('image');
                    
                    if (!selectedImage) return;
                    
                    fetch('', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/x-www-form-urlencoded',
                        },
                        body: `action=${action}&image=${encodeURIComponent(selectedImage)}`
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.status === 'success') {
                            showToast(`Image ${action === 'like' ? 'liked' : 'disliked'} successfully`);
                            
                            // Visual feedback
                            if (action === 'like') {
                                likeBtn.style.color = '#4CAF50';
                                setTimeout(() => { likeBtn.style.color = ''; }, 1000);
                            } else {
                                dislikeBtn.style.color = '#F44336';
                                setTimeout(() => { dislikeBtn.style.color = ''; }, 1000);
                            }
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        showToast('An error occurred');
                    });
                }
            }
        });
    </script>
</body>
</html>