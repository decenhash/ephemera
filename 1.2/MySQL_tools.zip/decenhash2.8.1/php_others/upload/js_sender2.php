<?php
// Ensure the GET directory exists
$baseDir = __DIR__ . '/GET';
if (!file_exists($baseDir)) {
    mkdir($baseDir, 0755, true);
}

// Get the data and type from the request
$data = $_GET['data'] ?? '';
$type = $_GET['type'] ?? 'unknown';

// Validate the type to prevent directory traversal
$allowedTypes = ['text', 'base64', 'sha256', 'link'];
if (!in_array($type, $allowedTypes)) {
    $type = 'unknown';
}

// Create type-specific subdirectory if it doesn't exist
$typeDir = $baseDir . '/' . $type;
if (!file_exists($typeDir)) {
    mkdir($typeDir, 0755, true);
}

// Generate filename from SHA256 hash of the content
$filename = hash('sha256', $data);
$filePath = $typeDir . '/' . $filename;

// Save the content to file
file_put_contents($filePath, $data);

// Also save metadata in a separate file
$metadata = [
    'received_at' => date('Y-m-d H:i:s'),
    'type' => $type,
    'size' => strlen($data),
    'remote_addr' => $_SERVER['REMOTE_ADDR'] ?? 'unknown',
    'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? 'unknown'
];
file_put_contents($filePath . '.meta', json_encode($metadata, JSON_PRETTY_PRINT));

// Send response
header('Content-Type: application/json');
echo json_encode([
    'status' => 'success',
    'message' => 'Data received and saved',
    'filename' => $filename,
    'type' => $type,
    'size' => strlen($data)
]);