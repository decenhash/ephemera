<?php

// Database configuration for SQL payment mode
include 'db_config.php';

// Database configuration
define('DB_HOST', $db_config['host']);
define('DB_USER', $db_config['username']);
define('DB_PASS', $db_config['password']);
define('DB_NAME', $db_config['database']);

// Create connection
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get statistics
$stats = array();

// 1. Files with most deposits (top 5)
$query = "SELECT filehash, extension, SUM(deposit) as total_deposit 
          FROM blocks 
          GROUP BY filehash, extension 
          ORDER BY total_deposit DESC 
          LIMIT 5";
$result = $conn->query($query);
$stats['top_files'] = $result->fetch_all(MYSQLI_ASSOC);

// 2. Last 5 files added
$query = "SELECT filehash, extension, user, deposit, timestamp 
          FROM blocks 
          ORDER BY timestamp DESC 
          LIMIT 5";
$result = $conn->query($query);
$stats['recent_files'] = $result->fetch_all(MYSQLI_ASSOC);

// 3. Percentage of top file vs all others
$query = "SELECT 
            (SELECT SUM(deposit) FROM blocks WHERE filehash = ?) as top_file_deposit,
            (SELECT SUM(deposit) FROM blocks WHERE filehash != ?) as other_files_deposit";
$stmt = $conn->prepare($query);
$top_file_hash = $stats['top_files'][0]['filehash'] ?? '';
$stmt->bind_param("ss", $top_file_hash, $top_file_hash);
$stmt->execute();
$result = $stmt->get_result();
$deposit_data = $result->fetch_assoc();

if ($deposit_data && $deposit_data['other_files_deposit'] > 0) {
    $percentage = ($deposit_data['top_file_deposit'] / $deposit_data['other_files_deposit']) * 100;
} else {
    $percentage = $deposit_data ? 100 : 0;
}
$stats['top_vs_others'] = round($percentage, 2);

// 4. Total deposits and count
$query = "SELECT SUM(deposit) as total_deposits, COUNT(*) as total_files FROM blocks";
$result = $conn->query($query);
$total_data = $result->fetch_assoc();
$stats['total_deposits'] = $total_data['total_deposits'] ?? 0;
$stats['total_files'] = $total_data['total_files'] ?? 0;

// 5. Payment method distribution
$query = "SELECT 
            SUM(CASE WHEN btc IS NOT NULL THEN 1 ELSE 0 END) as btc_count,
            SUM(CASE WHEN pix IS NOT NULL THEN 1 ELSE 0 END) as pix_count,
            COUNT(*) as total_count
          FROM blocks";
$result = $conn->query($query);
$payment_stats = $result->fetch_assoc();
$stats['btc_percentage'] = round(($payment_stats['btc_count'] / $payment_stats['total_count']) * 100, 2);
$stats['pix_percentage'] = round(($payment_stats['pix_count'] / $payment_stats['total_count']) * 100, 2);

// 6. Average deposit per file
$stats['avg_deposit'] = $stats['total_files'] > 0 ? round($stats['total_deposits'] / $stats['total_files'], 2) : 0;

// 7. Deposit trends (last 30 days)
$query = "SELECT 
            DATE(timestamp) as day,
            SUM(deposit) as daily_deposit,
            COUNT(*) as daily_files
          FROM blocks 
          WHERE timestamp >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
          GROUP BY DATE(timestamp)
          ORDER BY DATE(timestamp)";
$result = $conn->query($query);
$stats['deposit_trends'] = $result->fetch_all(MYSQLI_ASSOC);

// 8. Top users by total deposits
$query = "SELECT 
            user,
            SUM(deposit) as total_deposit,
            COUNT(*) as file_count
          FROM blocks
          GROUP BY user
          ORDER BY total_deposit DESC
          LIMIT 5";
$result = $conn->query($query);
$stats['top_users'] = $result->fetch_all(MYSQLI_ASSOC);

// 9. File extension distribution
$query = "SELECT 
            extension,
            COUNT(*) as count,
            SUM(deposit) as total_deposit
          FROM blocks
          GROUP BY extension
          ORDER BY count DESC";
$result = $conn->query($query);
$stats['extensions'] = $result->fetch_all(MYSQLI_ASSOC);

// 10. First vs subsequent deposits
$query = "SELECT 
            SUM(CASE WHEN is_first = 1 THEN deposit ELSE 0 END) as first_deposits,
            SUM(CASE WHEN is_first = 0 THEN deposit ELSE 0 END) as subsequent_deposits,
            SUM(deposit) as total_deposits
          FROM blocks";
$result = $conn->query($query);
$stats['deposit_types'] = $result->fetch_assoc();

// Close connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Advanced File Deposit Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        :root {
            --primary: #4e73df;
            --success: #1cc88a;
            --info: #36b9cc;
            --warning: #f6c23e;
            --danger: #e74a3b;
            --secondary: #858796;
            --dark: #5a5c69;
        }
        .card {
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s;
            margin-bottom: 20px;
            border: none;
        }
        .card:hover {
            transform: translateY(-5px);
        }
        .stat-card {
            text-align: center;
            padding: 20px;
        }
        .stat-value {
            font-size: 2rem;
            font-weight: bold;
        }
        .stat-label {
            color: #6c757d;
            font-size: 0.9rem;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        .bg-primary { background-color: var(--primary) !important; }
        .bg-success { background-color: var(--success) !important; }
        .bg-info { background-color: var(--info) !important; }
        .bg-warning { background-color: var(--warning) !important; }
        .bg-danger { background-color: var(--danger) !important; }
        .bg-secondary { background-color: var(--secondary) !important; }
        .bg-dark { background-color: var(--dark) !important; }
        
        .dashboard-header {
            padding: 20px 0;
            margin-bottom: 30px;
            border-bottom: 1px solid #e3e6f0;
        }
        .file-icon {
            font-size: 1.5rem;
            margin-right: 10px;
        }
        .chart-container {
            position: relative;
            height: 300px;
        }
        .progress {
            height: 1rem;
            border-radius: 0.35rem;
        }
        .progress-bar {
            background-color: var(--primary);
        }
        .table th {
            border-top: none;
            font-weight: 600;
            color: var(--dark);
        }
        .badge {
            font-weight: 500;
            padding: 0.35em 0.65em;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="dashboard-header">
            <h1><i class="bi bi-graph-up"></i> Advanced File Deposit Analytics</h1>
            <p class="text-muted">Comprehensive statistics and metrics for your file deposits</p>
        </div>

        <!-- Summary Row -->
        <div class="row">
            <!-- Total Deposits -->
            <div class="col-xl-2 col-md-4 col-6">
                <div class="card bg-primary text-white">
                    <div class="stat-card">
                        <div class="stat-value">$<?= number_format($stats['total_deposits'], 2) ?></div>
                        <div class="stat-label">Total Deposits</div>
                        <i class="bi bi-cash-stack file-icon"></i>
                    </div>
                </div>
            </div>

            <!-- Total Files -->
            <div class="col-xl-2 col-md-4 col-6">
                <div class="card bg-success text-white">
                    <div class="stat-card">
                        <div class="stat-value"><?= number_format($stats['total_files']) ?></div>
                        <div class="stat-label">Total Files</div>
                        <i class="bi bi-file-earmark file-icon"></i>
                    </div>
                </div>
            </div>

            <!-- Average Deposit -->
            <div class="col-xl-2 col-md-4 col-6">
                <div class="card bg-info text-white">
                    <div class="stat-card">
                        <div class="stat-value">$<?= number_format($stats['avg_deposit'], 2) ?></div>
                        <div class="stat-label">Avg. Deposit</div>
                        <i class="bi bi-calculator file-icon"></i>
                    </div>
                </div>
            </div>

            <!-- Top File Dominance -->
            <div class="col-xl-2 col-md-4 col-6">
                <div class="card bg-warning text-white">
                    <div class="stat-card">
                        <div class="stat-value"><?= $stats['top_vs_others'] ?>%</div>
                        <div class="stat-label">Top File Dominance</div>
                        <i class="bi bi-trophy file-icon"></i>
                    </div>
                </div>
            </div>

            <!-- First Deposits -->
            <div class="col-xl-2 col-md-4 col-6">
                <div class="card bg-danger text-white">
                    <div class="stat-card">
                        <div class="stat-value"><?= $stats['total_files'] > 0 ? round(($stats['deposit_types']['first_deposits'] / $stats['total_deposits']) * 100, 2) : 0 ?>%</div>
                        <div class="stat-label">First Deposits</div>
                        <i class="bi bi-1-circle file-icon"></i>
                    </div>
                </div>
            </div>

            <!-- Subsequent Deposits -->
            <div class="col-xl-2 col-md-4 col-6">
                <div class="card bg-secondary text-white">
                    <div class="stat-card">
                        <div class="stat-value"><?= $stats['total_files'] > 0 ? round(($stats['deposit_types']['subsequent_deposits'] / $stats['total_deposits']) * 100, 2) : 0 ?>%</div>
                        <div class="stat-label">Subsequent Deposits</div>
                        <i class="bi bi-arrow-repeat file-icon"></i>
                    </div>
                </div>
            </div>
        </div>

        <div class="row mt-4">
            <!-- Deposit Trends Chart -->
            <div class="col-lg-8">
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5><i class="bi bi-bar-chart-line"></i> Deposit Trends (Last 30 Days)</h5>
                        <div class="dropdown">
                            <button class="btn btn-sm btn-outline-secondary dropdown-toggle" type="button" id="trendsDropdown" data-bs-toggle="dropdown">
                                <i class="bi bi-filter"></i> Filter
                            </button>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item" href="#" onclick="updateTrendsChart('daily_deposit')">By Deposit Amount</a></li>
                                <li><a class="dropdown-item" href="#" onclick="updateTrendsChart('daily_files')">By File Count</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="chart-container">
                            <canvas id="trendsChart"></canvas>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Payment Methods -->
            <div class="col-lg-4">
                <div class="card">
                    <div class="card-header">
                        <h5><i class="bi bi-credit-card"></i> Payment Methods</h5>
                    </div>
                    <div class="card-body">
                        <div class="mb-4">
                            <div class="d-flex justify-content-between mb-1">
                                <span>BTC Payments</span>
                                <span><?= $stats['btc_percentage'] ?>%</span>
                            </div>
                            <div class="progress">
                                <div class="progress-bar bg-warning" role="progressbar" style="width: <?= $stats['btc_percentage'] ?>%"></div>
                            </div>
                        </div>
                        <div class="mb-4">
                            <div class="d-flex justify-content-between mb-1">
                                <span>PIX Payments</span>
                                <span><?= $stats['pix_percentage'] ?>%</span>
                            </div>
                            <div class="progress">
                                <div class="progress-bar bg-info" role="progressbar" style="width: <?= $stats['pix_percentage'] ?>%"></div>
                            </div>
                        </div>
                        <div class="text-center mt-4">
                            <div class="h5">Total Transactions</div>
                            <div class="display-4"><?= number_format($stats['total_files']) ?></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row mt-4">
            <!-- Top Files by Deposit -->
            <div class="col-lg-6">
                <div class="card">
                    <div class="card-header">
                        <h5><i class="bi bi-trophy"></i> Top 5 Files by Deposit Amount</h5>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>Rank</th>
                                        <th>File</th>
                                        <th>Extension</th>
                                        <th>Total Deposit</th>
                                        <th>% of Total</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($stats['top_files'] as $index => $file): ?>
                                    <tr>
                                        <td><span class="badge bg-primary">#<?= $index + 1 ?></span></td>
                                        <td title="<?= htmlspecialchars($file['filehash']) ?>">
                                            <?= substr($file['filehash'], 0, 8) ?>...
                                        </td>
                                        <td><span class="badge bg-secondary"><?= strtoupper($file['extension']) ?></span></td>
                                        <td>$<?= number_format($file['total_deposit'], 2) ?></td>
                                        <td><?= $stats['total_deposits'] > 0 ? round(($file['total_deposit'] / $stats['total_deposits']) * 100, 2) : 0 ?>%</td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Top Users -->
            <div class="col-lg-6">
                <div class="card">
                    <div class="card-header">
                        <h5><i class="bi bi-people"></i> Top 5 Users by Total Deposit</h5>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>User</th>
                                        <th>Files</th>
                                        <th>Total Deposit</th>
                                        <th>Avg. per File</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($stats['top_users'] as $user): ?>
                                    <tr>
                                        <td><?= htmlspecialchars($user['user']) ?></td>
                                        <td><?= $user['file_count'] ?></td>
                                        <td>$<?= number_format($user['total_deposit'], 2) ?></td>
                                        <td>$<?= number_format($user['total_deposit'] / $user['file_count'], 2) ?></td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row mt-4">
            <!-- Recent Files -->
            <div class="col-lg-6">
                <div class="card">
                    <div class="card-header">
                        <h5><i class="bi bi-clock-history"></i> Recently Added Files</h5>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>Date</th>
                                        <th>File</th>
                                        <th>User</th>
                                        <th>Deposit</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($stats['recent_files'] as $file): ?>
                                    <tr>
                                        <td><?= date('M j, H:i', strtotime($file['timestamp'])) ?></td>
                                        <td title="<?= htmlspecialchars($file['filehash']) ?>">
                                            <?= substr($file['filehash'], 0, 8) ?>...
                                            <span class="badge bg-secondary"><?= strtoupper($file['extension']) ?></span>
                                        </td>
                                        <td><?= htmlspecialchars($file['user']) ?></td>
                                        <td>$<?= number_format($file['deposit'], 2) ?></td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            <!-- File Extensions -->
            <div class="col-lg-6">
                <div class="card">
                    <div class="card-header">
                        <h5><i class="bi bi-filetype-"></i> File Extension Distribution</h5>
                    </div>
                    <div class="card-body">
                        <div class="chart-container" style="height: 250px;">
                            <canvas id="extensionsChart"></canvas>
                        </div>
                        <div class="table-responsive mt-3">
                            <table class="table table-sm">
                                <thead>
                                    <tr>
                                        <th>Extension</th>
                                        <th>Count</th>
                                        <th>% of Total</th>
                                        <th>Total Deposit</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($stats['extensions'] as $ext): ?>
                                    <tr>
                                        <td><span class="badge bg-primary"><?= strtoupper($ext['extension']) ?></span></td>
                                        <td><?= $ext['count'] ?></td>
                                        <td><?= $stats['total_files'] > 0 ? round(($ext['count'] / $stats['total_files']) * 100, 2) : 0 ?>%</td>
                                        <td>$<?= number_format($ext['total_deposit'], 2) ?></td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/luxon@3.0.1"></script>
    <script src="https://cdn.jsdelivr.net/npm/chartjs-adapter-luxon@1.1.0"></script>
    <script src="https://cdn.jsdelivr.net/npm/chartjs-plugin-datalabels@2.0.0"></script>
    
    <script>
        // Prepare data for charts
        const trendsData = {
            labels: <?= json_encode(array_column($stats['deposit_trends'], 'day')) ?>,
            deposit: <?= json_encode(array_column($stats['deposit_trends'], 'daily_deposit')) ?>,
            files: <?= json_encode(array_column($stats['deposit_trends'], 'daily_files')) ?>
        };
        
        const extensionsData = {
            labels: <?= json_encode(array_column($stats['extensions'], 'extension')) ?>,
            counts: <?= json_encode(array_column($stats['extensions'], 'count')) ?>,
            deposits: <?= json_encode(array_column($stats['extensions'], 'total_deposit')) ?>
        };
        
        // Deposit Trends Chart
        const trendsCtx = document.getElementById('trendsChart').getContext('2d');
        let trendsChart = new Chart(trendsCtx, {
            type: 'line',
            data: {
                labels: trendsData.labels,
                datasets: [{
                    label: 'Deposit Amount ($)',
                    data: trendsData.deposit,
                    borderColor: 'rgba(78, 115, 223, 1)',
                    backgroundColor: 'rgba(78, 115, 223, 0.05)',
                    borderWidth: 2,
                    pointRadius: 3,
                    pointBackgroundColor: 'rgba(78, 115, 223, 1)',
                    pointBorderColor: '#fff',
                    pointHoverRadius: 5,
                    fill: true
                }]
            },
            options: {
                maintainAspectRatio: false,
                plugins: {
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                return '$' + context.raw.toFixed(2);
                            }
                        }
                    },
                    legend: {
                        display: true,
                        position: 'top'
                    }
                },
                scales: {
                    x: {
                        grid: {
                            display: false
                        }
                    },
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return '$' + value;
                            }
                        }
                    }
                }
            }
        });
        
        // Function to update trends chart
        function updateTrendsChart(type) {
            const newData = type === 'daily_files' ? trendsData.files : trendsData.deposit;
            const newLabel = type === 'daily_files' ? 'File Count' : 'Deposit Amount ($)';
            
            trendsChart.data.datasets[0].data = newData;
            trendsChart.data.datasets[0].label = newLabel;
            
            if (type === 'daily_files') {
                trendsChart.options.scales.y.ticks.callback = function(value) {
                    return value;
                };
            } else {
                trendsChart.options.scales.y.ticks.callback = function(value) {
                    return '$' + value;
                };
            }
            
            trendsChart.update();
        }
        
        // Extensions Distribution Chart
        const extensionsCtx = document.getElementById('extensionsChart').getContext('2d');
        const extensionsChart = new Chart(extensionsCtx, {
            type: 'doughnut',
            data: {
                labels: extensionsData.labels.map(ext => ext.toUpperCase()),
                datasets: [{
                    data: extensionsData.counts,
                    backgroundColor: [
                        'rgba(78, 115, 223, 0.8)',
                        'rgba(28, 200, 138, 0.8)',
                        'rgba(54, 185, 204, 0.8)',
                        'rgba(246, 194, 62, 0.8)',
                        'rgba(231, 74, 59, 0.8)',
                        'rgba(133, 135, 150, 0.8)'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'right',
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                const label = context.label || '';
                                const value = context.raw || 0;
                                const total = context.dataset.data.reduce((a, b) => a + b, 0);
                                const percentage = Math.round((value / total) * 100);
                                return `${label}: ${value} (${percentage}%)`;
                            }
                        }
                    },
                    datalabels: {
                        display: false
                    }
                },
                cutout: '70%'
            },
            plugins: [ChartDataLabels]
        });
    </script>
</body>
</html>