<?php
// Error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Function to get SHA-256 hash
function get_sha256($data) {
    return hash('sha256', $data);
}

// Function to save data to JSON file
function save_to_json($data, $hash) {
    // Create blocks_json directory if it doesn't exist
    $dir = 'blocks_json';
    if (!file_exists($dir)) {
        mkdir($dir, 0755, true);
    }
    
    $filename = $dir . '/' . $hash . '.json';
    
    // Check if file already exists
    if (file_exists($filename)) {
        return false; // File exists, don't overwrite
    }
    
    // Save the data to JSON file
    file_put_contents($filename, json_encode($data, JSON_PRETTY_PRINT));
    return true;
}

// Initialize variables
$message = '';
$hash = '';
$success = false;

// Process form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get current timestamp
    $timestamp = date('Y-m-d H:i:s');
    
    // Get form data
    $pix = isset($_POST['pix']) ? $_POST['pix'] : '';
    $btc = isset($_POST['btc']) ? $_POST['btc'] : '';
    $signature_password = isset($_POST['signature_password']) ? $_POST['signature_password'] : '';
    $other_info = isset($_POST['other_info']) ? $_POST['other_info'] : '';
    
    // Initialize data array
    $data = [
        'timestamp' => $timestamp,
        'pix' => $pix,
        'btc' => $btc,
        'signature' => get_sha256($signature_password),
        'other_info' => $other_info
    ];
    
    // Handle file upload or text input
    if (!empty($_FILES['file']['tmp_name'])) {
        // File upload
        $file_content = file_get_contents($_FILES['file']['tmp_name']);
        $hash = get_sha256($file_content);
        $file_extension = pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION);
        
        // Add file-specific data
        $data['file_name'] = $_FILES['file']['name'];
        $data['file_extension'] = $file_extension;
        $data['file_hash'] = $hash;
        $data['file_size'] = $_FILES['file']['size'];
    } elseif (!empty($_POST['text_input'])) {
        // Text input
        $text_content = $_POST['text_input'];
        $hash = get_sha256($text_content);
        
        // Add text-specific data
        $data['text_content'] = $text_content;
        $data['text_hash'] = $hash;
    } else {
        $message = "Please upload a file or enter text to hash.";
    }
    
    // Save data if hash is generated
    if (!empty($hash)) {
        if (save_to_json($data, $hash)) {
            $success = true;
            $message = "Data saved successfully with hash: " . $hash;
        } else {
            $message = "A file with this hash already exists. No new data was saved.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Blockchain Verification System</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            color: #333;
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            background-color: #f5f7fa;
        }
        
        h1 {
            color: #2c3e50;
            text-align: center;
            margin-bottom: 30px;
        }
        
        .container {
            background: white;
            border-radius: 8px;
            padding: 30px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
        }
        
        input[type="text"],
        input[type="password"],
        textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            box-sizing: border-box;
        }
        
        button {
            background: #3498db;
            color: white;
            border: none;
            padding: 12px 20px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            transition: background 0.3s;
        }
        
        button:hover {
            background: #2980b9;
        }
        
        .tabs {
            display: flex;
            margin-bottom: 20px;
        }
        
        .tab {
            padding: 10px 20px;
            cursor: pointer;
            background: #f1f1f1;
            border: 1px solid #ddd;
        }
        
        .tab.active {
            background: white;
            border-bottom: none;
        }
        
        .tab-content {
            display: none;
        }
        
        .tab-content.active {
            display: block;
        }
        
        .message {
            padding: 15px;
            margin: 20px 0;
            border-radius: 4px;
        }
        
        .success {
            background-color: #d4edda;
            color: #155724;
        }
        
        .error {
            background-color: #f8d7da;
            color: #721c24;
        }
        
        .info {
            background-color: #d1ecf1;
            border-radius: 4px;
            color: #0c5460;
            padding: 15px;
            margin-top: 30px;
        }
        
        .result {
            margin-top: 20px;
            word-break: break-all;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Blockchain Verification System</h1>
        
        <?php if (!empty($message)): ?>
            <div class="message <?php echo $success ? 'success' : 'error'; ?>">
                <?php echo $message; ?>
            </div>
        <?php endif; ?>
        
        <form method="post" enctype="multipart/form-data">
            <div class="form-group">
                <label for="pix">PIX:</label>
                <input type="text" id="pix" name="pix" required>
            </div>
            
            <div class="form-group">
                <label for="btc">BTC Address:</label>
                <input type="text" id="btc" name="btc" required>
            </div>
            
            <div class="form-group">
                <label for="signature_password">Signature Password:</label>
                <input type="password" id="signature_password" name="signature_password" required>
            </div>
            
            <div class="form-group">
                <label for="other_info">Other Information:</label>
                <textarea id="other_info" name="other_info" rows="3"></textarea>
            </div>
            
            <div class="tabs">
                <div class="tab active" onclick="switchTab('file')">Upload File</div>
                <div class="tab" onclick="switchTab('text')">Enter Text</div>
            </div>
            
            <div id="file-tab" class="tab-content active">
                <div class="form-group">
                    <label for="file">Upload File to Hash:</label>
                    <input type="file" id="file" name="file">
                </div>
            </div>
            
            <div id="text-tab" class="tab-content">
                <div class="form-group">
                    <label for="text_input">Text to Hash:</label>
                    <textarea id="text_input" name="text_input" rows="5"></textarea>
                </div>
            </div>
            
            <button type="submit">Process and Save</button>
        </form>
        
        <?php if (!empty($hash)): ?>
            <div class="result">
                <h3>Generated SHA-256 Hash:</h3>
                <p><?php echo $hash; ?></p>
            </div>
        <?php endif; ?>
        
        <div class="info">
            <p>This system generates a SHA-256 hash from your file or text input and stores the information in a JSON file. Each hash is unique, and the system prevents duplicate entries.</p>
        </div>
    </div>
    
    <script>
        function switchTab(tabName) {
            // Hide all tab contents
            document.querySelectorAll('.tab-content').forEach(content => {
                content.classList.remove('active');
            });
            
            // Remove active class from all tabs
            document.querySelectorAll('.tab').forEach(tab => {
                tab.classList.remove('active');
            });
            
            // Show the selected tab content
            document.getElementById(tabName + '-tab').classList.add('active');
            
            // Add active class to the clicked tab
            const tabs = document.querySelectorAll('.tab');
            tabs.forEach(tab => {
                if (tab.textContent.toLowerCase().includes(tabName)) {
                    tab.classList.add('active');
                }
            });
        }
    </script>
</body>
</html>