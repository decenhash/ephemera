﻿<?php
// Error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Session start for language preference
session_start();

// Set language (default to English if not set)
if (isset($_GET['lang'])) {
    $_SESSION['lang'] = $_GET['lang'];
} elseif (!isset($_SESSION['lang'])) {
    $_SESSION['lang'] = 'en';
}

$lang = $_SESSION['lang'];

// Language strings
$translations = [
    'en' => [
        'title' => 'Verification System',
        'pix' => 'PIX',
        'btc' => 'BTC Address',
        'signature' => 'Signature Password',
        'other_info' => 'Additional Information',
        'upload_file' => 'Upload File',
        'enter_text' => 'Enter Text',
        'file_label' => 'Upload File to Hash',
        'text_label' => 'Text to Hash',
        'submit' => 'Process and Save',
        'hash_result' => 'Generated SHA-256 Hash',
        'info_text' => 'This system generates a SHA-256 hash from your file or text input and stores the information in a JSON file. Each hash is unique, and the system prevents duplicate entries.',
        'upload_placeholder' => 'Choose a file or drag it here',
        'file_exists' => 'A file with this hash already exists. No new data was saved.',
        'success_message' => 'Data saved successfully with hash:',
        'error_input' => 'Please upload a file or enter text to hash.',
        'dashboard' => 'Dashboard',
        'verification' => 'Verification',
        'about' => 'About'
    ],
    'pt' => [
        'title' => 'Sistema de Verificação',
        'pix' => 'PIX',
        'btc' => 'Endereço BTC',
        'signature' => 'Senha de Assinatura',
        'other_info' => 'Informações Adicionais',
        'upload_file' => 'Enviar Arquivo',
        'enter_text' => 'Inserir Texto',
        'file_label' => 'Enviar Arquivo para Hash',
        'text_label' => 'Texto para Hash',
        'submit' => 'Processar e Salvar',
        'hash_result' => 'Hash SHA-256 Gerado',
        'info_text' => 'Este sistema gera um hash SHA-256 a partir do seu arquivo ou texto e armazena as informações em um arquivo JSON. Cada hash é único, e o sistema impede entradas duplicadas.',
        'upload_placeholder' => 'Escolha um arquivo ou arraste aqui',
        'file_exists' => 'Um arquivo com este hash já existe. Nenhum dado novo foi salvo.',
        'success_message' => 'Dados salvos com sucesso com hash:',
        'error_input' => 'Por favor, envie um arquivo ou insira um texto para gerar o hash.',
        'dashboard' => 'Painel',
        'verification' => 'Verificação',
        'about' => 'Sobre'
    ]
];

$t = $translations[$lang];

// Function to get SHA-256 hash
function get_sha256($data) {
    return hash('sha256', $data);
}

// Function to save data to JSON file
function save_to_json($data, $hash) {
    // Create blocks_json directory if it doesn't exist
    $dir = 'blocks_json';
    if (!file_exists($dir)) {
        mkdir($dir, 0755, true);
    }
    
    $filename = $dir . '/' . $hash . '.json';
    
    // Check if file already exists
    if (file_exists($filename)) {
        return false; // File exists, don't overwrite
    }
    
    // Save the data to JSON file
    include("ip_hash.php");
    file_put_contents($filename, json_encode($data, JSON_PRETTY_PRINT));
    return true;
}

// Initialize variables
$message = '';
$hash = '';
$success = false;

// Process form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get current timestamp
    $timestamp = date('Y-m-d H:i:s');
    
    // Get form data
    $pix = isset($_POST['pix']) ? $_POST['pix'] : '';
    $btc = isset($_POST['btc']) ? $_POST['btc'] : '';
    $signature_password = isset($_POST['signature_password']) ? $_POST['signature_password'] : '';
    $other_info = isset($_POST['other_info']) ? $_POST['other_info'] : '';
    
    // Initialize data array
    $data = [
        'timestamp' => $timestamp,
        'pix' => $pix,
        'btc' => $btc,
        'signature' => get_sha256($signature_password),
        'other_info' => $other_info
    ];
    
    // Handle file upload or text input
    if (!empty($_FILES['file']['tmp_name'])) {
        // File upload
        $file_content = file_get_contents($_FILES['file']['tmp_name']);
        $hash = get_sha256($file_content);
        $file_extension = pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION);
        
        // Add file-specific data
        $data['file_name'] = $_FILES['file']['name'];
        $data['file_extension'] = $file_extension;
        $data['file_hash'] = $hash;
        $data['file_size'] = $_FILES['file']['size'];
    } elseif (!empty($_POST['text_input'])) {
        // Text input
        $text_content = $_POST['text_input'];
        $hash = get_sha256($text_content);
        
        // Add text-specific data
        $data['text_content'] = $text_content;
        $data['text_hash'] = $hash;
    } else {
        $message = $t['error_input'];
    }
    
    // Save data if hash is generated
    if (!empty($hash)) {
        if (save_to_json($data, $hash)) {
            $success = true;
            $message = $t['success_message'] . " " . $hash;
        } else {
            $message = $t['file_exists'];
        }
    }
}
?>

<!DOCTYPE html>
<html lang="<?php echo $lang; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $t['title']; ?></title>
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        :root {
            --primary: #2563eb;
            --primary-hover: #1d4ed8;
            --secondary: #475569;
            --light: #f8fafc;
            --dark: #1e293b;
            --success: #10b981;
            --error: #ef4444;
            --gray-100: #f1f5f9;
            --gray-200: #e2e8f0;
            --border-radius: 0.5rem;
            --shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
            --transition: all 0.3s ease;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            color: var(--dark);
            background-color: var(--gray-100);
            min-height: 100vh;
        }
        
        .container {
            max-width: 1000px;
            margin: 0 auto;
            padding: 2rem 1rem;
        }
        
        .header {
            background-color: white;
            box-shadow: var(--shadow);
            position: sticky;
            top: 0;
            z-index: 100;
        }
        
        .navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 1rem 0;
        }
        
        .logo {
            display: flex;
            align-items: center;
            font-size: 1.5rem;
            font-weight: bold;
            color: var(--primary);
        }
        
        .logo i {
            margin-right: 0.5rem;
        }
        
        .nav-links {
            display: flex;
            gap: 1.5rem;
        }
        
        .nav-link {
            color: var(--secondary);
            text-decoration: none;
            font-weight: 500;
            transition: var(--transition);
            padding: 0.5rem 0;
        }
        
        .nav-link:hover,
        .nav-link.active {
            color: var(--primary);
            border-bottom: 2px solid var(--primary);
        }
        
        .language-switcher {
            display: flex;
            gap: 0.5rem;
            align-items: center;
        }
        
        .language-btn {
            background: none;
            border: none;
            cursor: pointer;
            font-size: 0.9rem;
            color: var(--secondary);
            transition: var(--transition);
            padding: 0.25rem;
        }
        
        .language-btn:hover,
        .language-btn.active {
            color: var(--primary);
            font-weight: 500;
        }
        
        .card {
            background: white;
            border-radius: var(--border-radius);
            box-shadow: var(--shadow);
            overflow: hidden;
            margin: 2rem 0;
        }
        
        .card-header {
            background-color: var(--primary);
            color: white;
            padding: 1.5rem;
            font-size: 1.25rem;
            font-weight: 500;
        }
        
        .card-body {
            padding: 2rem;
        }
        
        .form-group {
            margin-bottom: 1.5rem;
        }
        
        label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 500;
            color: var(--dark);
        }
        
        input[type="text"],
        input[type="password"],
        textarea {
            width: 100%;
            padding: 0.75rem 1rem;
            border: 1px solid var(--gray-200);
            border-radius: var(--border-radius);
            font-family: inherit;
            font-size: 1rem;
            transition: var(--transition);
        }
        
        input[type="text"]:focus,
        input[type="password"]:focus,
        textarea:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.1);
        }
        
        .file-upload {
            position: relative;
            display: block;
            width: 100%;
            min-height: 150px;
            border: 2px dashed var(--gray-200);
            border-radius: var(--border-radius);
            padding: 2rem;
            text-align: center;
            transition: var(--transition);
            cursor: pointer;
        }
        
        .file-upload:hover {
            border-color: var(--primary);
        }
        
        .file-upload input[type="file"] {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            opacity: 0;
            cursor: pointer;
        }
        
        .file-upload i {
            font-size: 2rem;
            color: var(--secondary);
            margin-bottom: 1rem;
        }
        
        .file-upload p {
            color: var(--secondary);
        }
        
        .tabs {
            display: flex;
            border-bottom: 1px solid var(--gray-200);
            margin-bottom: 2rem;
        }
        
        .tab {
            padding: 1rem 1.5rem;
            cursor: pointer;
            font-weight: 500;
            color: var(--secondary);
            border-bottom: 2px solid transparent;
            transition: var(--transition);
        }
        
        .tab:hover {
            color: var(--primary);
        }
        
        .tab.active {
            color: var(--primary);
            border-bottom-color: var(--primary);
        }
        
        .tab-content {
            display: none;
        }
        
        .tab-content.active {
            display: block;
        }
        
        .btn {
            display: inline-block;
            background-color: var(--primary);
            color: white;
            padding: 0.75rem 1.5rem;
            border: none;
            border-radius: var(--border-radius);
            font-size: 1rem;
            font-weight: 500;
            cursor: pointer;
            transition: var(--transition);
        }
        
        .btn:hover {
            background-color: var(--primary-hover);
        }
        
        .btn-block {
            display: block;
            width: 100%;
        }
        
        .message {
            padding: 1rem;
            border-radius: var(--border-radius);
            margin: 1rem 0;
            font-weight: 500;
        }
        
        .message.success {
            background-color: rgba(16, 185, 129, 0.1);
            color: var(--success);
            border: 1px solid rgba(16, 185, 129, 0.2);
        }
        
        .message.error {
            background-color: rgba(239, 68, 68, 0.1);
            color: var(--error);
            border: 1px solid rgba(239, 68, 68, 0.2);
        }
        
        .result {
            background-color: var(--gray-100);
            border-radius: var(--border-radius);
            padding: 1.5rem;
            margin-top: 2rem;
        }
        
        .result h3 {
            color: var(--primary);
            margin-bottom: 1rem;
        }
        
        .hash-value {
            font-family: monospace;
            font-size: 1rem;
            word-break: break-all;
            background-color: white;
            padding: 1rem;
            border-radius: var(--border-radius);
            border: 1px solid var(--gray-200);
        }
        
        .info-box {
            background-color: rgba(37, 99, 235, 0.05);
            border-left: 4px solid var(--primary);
            padding: 1rem;
            margin-top: 2rem;
            border-radius: 0 var(--border-radius) var(--border-radius) 0;
        }
        
        .info-box p {
            color: var(--secondary);
        }
        
        .tab i {
            margin-right: 0.5rem;
        }
        
        .footer {
            text-align: center;
            padding: 2rem 0;
            color: var(--secondary);
            font-size: 0.9rem;
        }
        
        /* Responsive adjustments */
        @media (max-width: 768px) {
            .navbar {
                flex-direction: column;
                gap: 1rem;
            }
            
            .nav-links {
                gap: 1rem;
                margin-top: 1rem;
            }
            
            .language-switcher {
                margin-top: 1rem;
            }
            
            .card-body {
                padding: 1.5rem;
            }
        }
    </style>
</head>
<body>
    <header class="header">
        <div class="container">
            <nav class="navbar">
                <div class="logo">
                    <i class="fas fa-link"></i> <?php echo $t['title']; ?>
                </div>
                <div class="nav-links">
                    <a href="file_signature.php" class="nav-link active"><?php echo $t['dashboard']; ?></a>
                    <a href="index.html" class="nav-link"><?php echo $t['verification']; ?></a>
                    <a href="about_blockchain.html" class="nav-link"><?php echo $t['about']; ?></a>
                </div>
                <div class="language-switcher">
                    <a href="?lang=en" class="language-btn <?php echo $lang === 'en' ? 'active' : ''; ?>">EN</a>
                    <span>|</span>
                    <a href="?lang=pt" class="language-btn <?php echo $lang === 'pt' ? 'active' : ''; ?>">PT</a>
                </div>
            </nav>
        </div>
    </header>
    
    <main class="container">
        <div class="card">
            <div class="card-header">
                <?php echo $t['verification']; ?>
            </div>
            <div class="card-body">
                <?php if (!empty($message)): ?>
                    <div class="message <?php echo $success ? 'success' : 'error'; ?>">
                        <?php echo $message; ?>
                    </div>
                <?php endif; ?>
                
                <form method="post" enctype="multipart/form-data">
                    <div class="form-group">
                        <label for="pix"><?php echo $t['pix']; ?>:</label>
                        <input type="text" id="pix" name="pix" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="btc"><?php echo $t['btc']; ?>:</label>
                        <input type="text" id="btc" name="btc" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="signature_password"><?php echo $t['signature']; ?>:</label>
                        <input type="password" id="signature_password" name="signature_password" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="other_info"><?php echo $t['other_info']; ?>:</label>
                        <textarea id="other_info" name="other_info" rows="3"></textarea>
                    </div>
                    
                    <div class="tabs">
                        <div class="tab active" onclick="switchTab('file')">
                            <i class="fas fa-file-upload"></i> <?php echo $t['upload_file']; ?>
                        </div>
                        <div class="tab" onclick="switchTab('text')">
                            <i class="fas fa-keyboard"></i> <?php echo $t['enter_text']; ?>
                        </div>
                    </div>
                    
                    <div id="file-tab" class="tab-content active">
                        <div class="form-group">
                            <label for="file"><?php echo $t['file_label']; ?>:</label>
                            <div class="file-upload">
                                <i class="fas fa-cloud-upload-alt"></i>
                                <p><?php echo $t['upload_placeholder']; ?></p>
                                <input type="file" id="file" name="file">
                            </div>
                            <div id="file-name" class="mt-2"></div>
                        </div>
                    </div>
                    
                    <div id="text-tab" class="tab-content">
                        <div class="form-group">
                            <label for="text_input"><?php echo $t['text_label']; ?>:</label>
                            <textarea id="text_input" name="text_input" rows="5"></textarea>
                        </div>
                    </div>
                    
                    <button type="submit" class="btn btn-block">
                        <i class="fas fa-save"></i> <?php echo $t['submit']; ?>
                    </button>
                </form>
                
                <?php if (!empty($hash)): ?>
                    <div class="result">
                        <h3><?php echo $t['hash_result']; ?>:</h3>
                        <div class="hash-value"><?php echo $hash; ?></div>
                    </div>
                <?php endif; ?>
                
                <div class="info-box">
                    <p><i class="fas fa-info-circle"></i> <?php echo $t['info_text']; ?></p>
                </div>
            </div>
        </div>
    </main>
    
    <footer class="footer">
        <div class="container">
            <p>© <?php echo date('Y'); ?> Verification System. All rights reserved.</p>
        </div>
    </footer>
    
    <script>
        function switchTab(tabName) {
            // Hide all tab contents
            document.querySelectorAll('.tab-content').forEach(content => {
                content.classList.remove('active');
            });
            
            // Remove active class from all tabs
            document.querySelectorAll('.tab').forEach(tab => {
                tab.classList.remove('active');
            });
            
            // Show the selected tab content
            document.getElementById(tabName + '-tab').classList.add('active');
            
            // Add active class to the clicked tab
            const tabs = document.querySelectorAll('.tab');
            tabs.forEach(tab => {
                if (tab.textContent.toLowerCase().includes(tabName)) {
                    tab.classList.add('active');
                }
            });
        }
        
        // Display selected filename
        document.getElementById('file').addEventListener('change', function(e) {
            const fileName = e.target.files[0] ? e.target.files[0].name : '';
            if (fileName) {
                document.querySelector('.file-upload p').textContent = fileName;
            } else {
                document.querySelector('.file-upload p').textContent = '<?php echo $t['upload_placeholder']; ?>';
            }
        });
        
        // Add drag and drop functionality
        const dropZone = document.querySelector('.file-upload');
        
        ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
            dropZone.addEventListener(eventName, preventDefaults, false);
        });
        
        function preventDefaults(e) {
            e.preventDefault();
            e.stopPropagation();
        }
        
        ['dragenter', 'dragover'].forEach(eventName => {
            dropZone.addEventListener(eventName, highlight, false);
        });
        
        ['dragleave', 'drop'].forEach(eventName => {
            dropZone.addEventListener(eventName, unhighlight, false);
        });
        
        function highlight() {
            dropZone.style.borderColor = '<?php echo 'var(--primary)'; ?>';
            dropZone.style.backgroundColor = 'rgba(37, 99, 235, 0.05)';
        }
        
        function unhighlight() {
            dropZone.style.borderColor = '<?php echo 'var(--gray-200)'; ?>';
            dropZone.style.backgroundColor = '';
        }
        
        dropZone.addEventListener('drop', handleDrop, false);
        
        function handleDrop(e) {
            const dt = e.dataTransfer;
            const files = dt.files;
            document.getElementById('file').files = files;
            
            if (files[0]) {
                document.querySelector('.file-upload p').textContent = files[0].name;
            }
        }
    </script>
</body>
</html>