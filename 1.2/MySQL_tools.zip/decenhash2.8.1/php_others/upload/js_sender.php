<?php
// Set error reporting for debugging (you may want to remove this in production)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Function to sanitize the type parameter
function sanitizeType($type) {
    // Allow only specific values
    $allowedTypes = ['text', 'base64', 'file256hash', 'link'];
    
    // Default to 'text' if the type is not valid
    if (!in_array($type, $allowedTypes)) {
        return 'text';
    }
    
    return $type;
}

// Function to generate a response
function generateResponse($success, $message, $filePath = null) {
    $response = [
        'success' => $success,
        'message' => $message
    ];
    
    if ($filePath !== null) {
        $response['file_path'] = $filePath;
    }
    
    header('Content-Type: application/json');
    echo json_encode($response);
    exit;
}

// Check if required parameters are provided
if (!isset($_GET['data']) || !isset($_GET['type'])) {
    generateResponse(false, 'Missing required parameters: data and type must be provided');
}

// Get and sanitize parameters
$data = $_GET['data'];
$type = sanitizeType($_GET['type']);

// Generate SHA256 hash of the data
$hash = hash('sha256', $data);

// Define the base directory for storing files
$baseDir = __DIR__ . '/GET';

// Create the base directory if it doesn't exist
if (!file_exists($baseDir)) {
    if (!mkdir($baseDir, 0755, true)) {
        generateResponse(false, 'Failed to create base directory');
    }
}

// Create the type directory if it doesn't exist
$typeDir = $baseDir . '/' . $type;
if (!file_exists($typeDir)) {
    if (!mkdir($typeDir, 0755, true)) {
        generateResponse(false, "Failed to create directory for type: $type");
    }
}

// Define the file path
$filePath = $typeDir . '/' . $hash;

// Write the data to the file
$result = file_put_contents($filePath, $data);

if ($result === false) {
    generateResponse(false, 'Failed to write data to file');
} else {
    // Return success response
    $relativePath = 'GET/' . $type . '/' . $hash;
    generateResponse(true, 'Data saved successfully', $relativePath);
}
?>