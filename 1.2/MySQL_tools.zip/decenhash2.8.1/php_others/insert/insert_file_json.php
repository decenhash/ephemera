<?php
// Configuration
$maxFileSizeKB = 20;
$directory = 'files';
$jsonDirectory = 'data_json';
$fileCategories = [
    'image' => ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'svg', 'webp'],
    'music' => ['mp3', 'wav', 'ogg', 'flac', 'aac'],
    'video' => ['mp4', 'mov', 'avi', 'mkv', 'flv', 'webm'],
    'pdf' => ['pdf'],
    'zip' => ['zip', 'rar', '7z', 'tar', 'gz'],
    'url' => ['url'], // Special category for URLs
    'other' => []
];

// Function to determine file category
function getFileCategory($filename, $categories) {
    $extension = pathinfo($filename, PATHINFO_EXTENSION);
    $extension = strtolower($extension);
    
    foreach ($categories as $category => $extensions) {
        if (in_array($extension, $extensions)) {
            return $category;
        }
    }
    return 'other';
}

function validateJsonFilename($input, $category = 'data') {
    // If no input is provided, use the category
    if (empty($input)) {
        return $category . '.json';
    }
    
    // Remove any directory paths and extension if provided
    $filename = basename($input);
    $filename = preg_replace('/\.json$/i', '', $filename);
    
    // Remove any potentially dangerous characters
    $filename = preg_replace('/[^a-zA-Z0-9_-]/', '', $filename);
    
    // If empty after sanitization, use the category
    //if (empty($filename)) {
        return $category . '.json';
    //}
    
    // Otherwise use the sanitized filename
    //return $filename . '.json';
}
// Function to add entry to JSON file
function addEntryToJson($targetFile, $newEntry, $jsonDirectory) {
    $data = [];
    $fullPath = $jsonDirectory . '/' . $targetFile;
    
    // Create directory if it doesn't exist
    if (!is_dir($jsonDirectory)) {
        mkdir($jsonDirectory, 0755, true);
    }
    
    // Load existing data if file exists
    if (file_exists($fullPath)) {
        $jsonContent = file_get_contents($fullPath);
        $data = json_decode($jsonContent, true);
    }
    
    // Initialize files array if it doesn't exist
    if (!isset($data['files'])) {
        $data['files'] = [];
    }
    
    // Add new entry
    $data['files'][] = $newEntry;
    
    // Update metadata
    $data['metadata'] = [
        'total_files' => count($data['files']),
        'last_updated' => date('Y-m-d H:i:s'),
        'file_size_kb' => round(strlen(json_encode($data)) / 1024, 2)
    ];
    
    // Save the file
    file_put_contents($fullPath, json_encode($data, JSON_PRETTY_PRINT));
    
    return $data['metadata'];
}

// Response data for AJAX requests
$response = [
    'success' => false,
    'message' => '',
    'data' => null
];

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $hasFile = !empty($_FILES['file']['name']);
        $hasUrl = !empty($_POST['url']);
        
        // Validate input - must have either file or URL
        if (!$hasFile && !$hasUrl) {
            throw new Exception('You must provide either a file or a URL');
        }
        
        $newEntry = [
            'user' => $_POST['user'] ?? 'anonymous',
            'date' => date('Y-m-d'),
            'description' => $_POST['description'] ?? ''
        ];
        
        $category = 'other';
        $targetFile = 'data.json';
        
        // Handle file upload
        if ($hasFile) {
            $uploadedFile = $_FILES['file'];
            $filename = basename($uploadedFile['name']);
            $extension = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
            
            // Block PHP files
            if (in_array($extension, ['php', 'phtml', 'php3', 'php4', 'php5', 'php7', 'phps'])) {
                throw new Exception('PHP files are not allowed for security reasons');
            }
            
            // Determine category
            $category = getFileCategory($filename, $fileCategories);
            
            // Create file entry
            $fileHash = md5_file($uploadedFile['tmp_name']);
            
            $newEntry['filename'] = $filename;
            $newEntry['hash'] = $fileHash;
            $newEntry['extension'] = $extension;
            $newEntry['link'] = "$directory/$filename";
            $newEntry['url'] = "";
            
            // Move uploaded file to destination directory
            if (!is_dir($directory)) {
                mkdir($directory, 0755, true);
            }
            move_uploaded_file($uploadedFile['tmp_name'], "$directory/$filename");
        }
        
        // Handle URL submission
        if ($hasUrl) {
            $url = filter_var($_POST['url'], FILTER_SANITIZE_URL);
            
            if (!filter_var($url, FILTER_VALIDATE_URL)) {
                throw new Exception('Invalid URL provided');
            }
            
            // Set URL specific fields
            $newEntry['url'] = $url;
            $newEntry['filename'] = '';
            $newEntry['hash'] = md5($url);
            $newEntry['extension'] = 'url';
            $newEntry['link'] = $url;
            
            // Override category for URLs
            $category = 'url';
        }
        
        // Get JSON filename from user input or use category-based name
        $jsonFilename = $_POST['json_filename'] ?? $category;
        $targetFile = validateJsonFilename($jsonFilename, $category);
        
        // Add entry to JSON file
        $metadata = addEntryToJson($targetFile, $newEntry, $jsonDirectory);
        
        $successMessage = "Entry added successfully to $targetFile (Size: {$metadata['file_size_kb']} KB)";
        
        // For AJAX requests
        if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && $_SERVER['HTTP_X_REQUESTED_WITH'] === 'XMLHttpRequest') {
            $response['success'] = true;
            $response['message'] = $successMessage;
            $response['data'] = [
                'category' => $category,
                'entry' => $newEntry,
                'metadata' => $metadata
            ];
            echo json_encode($response);
            exit;
        }
    } catch (Exception $e) {
        $errorMessage = "Error: " . $e->getMessage();
        
        // For AJAX requests
        if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && $_SERVER['HTTP_X_REQUESTED_WITH'] === 'XMLHttpRequest') {
            $response['message'] = $errorMessage;
            echo json_encode($response);
            exit;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>File and URL Management System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #3498db;
            --primary-dark: #2980b9;
            --success-color: #2ecc71;
            --error-color: #e74c3c;
            --text-color: #333;
            --light-bg: #f9f9f9;
            --border-color: #ddd;
            --card-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            --transition: all 0.3s ease;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            color: var(--text-color);
            background-color: var(--light-bg);
            padding: 0;
            margin: 0;
        }
        
        .container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
        }
        
        header {
            background-color: #fff;
            box-shadow: var(--card-shadow);
            padding: 20px;
            margin-bottom: 30px;
            border-radius: 5px;
            text-align: center;
        }
        
        header h1 {
            color: var(--primary-color);
            margin-bottom: 10px;
        }
        
        header p {
            color: #777;
        }
        
        .upload-card {
            background-color: #fff;
            border-radius: 5px;
            box-shadow: var(--card-shadow);
            padding: 30px;
            margin-bottom: 30px;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #555;
        }
        
        input[type="text"], 
        input[type="url"],
        textarea {
            width: 100%;
            padding: 12px 15px;
            border: 1px solid var(--border-color);
            border-radius: 4px;
            font-size: 16px;
            transition: var(--transition);
        }
        
        input[type="text"]:focus, 
        input[type="url"]:focus,
        textarea:focus {
            border-color: var(--primary-color);
            outline: none;
            box-shadow: 0 0 0 3px rgba(52, 152, 219, 0.2);
        }
        
        textarea {
            height: 120px;
            resize: vertical;
        }
        
        .file-upload {
            position: relative;
            display: block;
            background-color: var(--light-bg);
            border: 2px dashed var(--border-color);
            border-radius: 5px;
            padding: 25px;
            text-align: center;
            cursor: pointer;
            transition: var(--transition);
        }
        
        .file-upload:hover {
            border-color: var(--primary-color);
        }
        
        .file-upload i {
            font-size: 48px;
            color: var(--primary-color);
            margin-bottom: 15px;
        }
        
        .file-upload p {
            margin: 10px 0 0;
            color: #777;
        }
        
        .file-upload input[type="file"] {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            opacity: 0;
            cursor: pointer;
        }
        
        .selected-file {
            display: none;
            margin-top: 15px;
            padding: 10px;
            background-color: var(--light-bg);
            border-radius: 4px;
        }
        
        .selected-file span {
            display: inline-block;
            margin-left: 10px;
            font-weight: 600;
        }
        
        .selected-file i {
            font-size: 16px;
            margin-right: 5px;
        }
        
        .btn {
            display: inline-block;
            padding: 12px 24px;
            background-color: var(--primary-color);
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            font-weight: 600;
            transition: var(--transition);
            text-align: center;
        }
        
        .btn:hover {
            background-color: var(--primary-dark);
        }
        
        .btn i {
            margin-right: 8px;
        }
        
        .btn-block {
            display: block;
            width: 100%;
        }
        
        .alert {
            padding: 15px;
            border-radius: 4px;
            margin-bottom: 20px;
            font-weight: 500;
            display: flex;
            align-items: center;
        }
        
        .alert i {
            margin-right: 10px;
            font-size: 20px;
        }
        
        .alert-success {
            background-color: rgba(46, 204, 113, 0.2);
            color: var(--success-color);
            border: 1px solid var(--success-color);
        }
        
        .alert-error {
            background-color: rgba(231, 76, 60, 0.2);
            color: var(--error-color);
            border: 1px solid var(--error-color);
        }
        
        .progress-container {
            display: none;
            margin: 20px 0;
            background-color: var(--light-bg);
            border-radius: 5px;
            overflow: hidden;
        }
        
        .progress-bar {
            height: 10px;
            background-color: var(--primary-color);
            width: 0%;
            transition: width 0.3s;
        }
        
        .or-divider {
            display: flex;
            align-items: center;
            margin: 20px 0;
            color: #777;
        }
        
        .or-divider::before,
        .or-divider::after {
            content: "";
            flex: 1;
            border-bottom: 1px solid var(--border-color);
        }
        
        .or-divider::before {
            margin-right: 10px;
        }
        
        .or-divider::after {
            margin-left: 10px;
        }
        
        footer {
            text-align: center;
            margin-top: 30px;
            padding: 20px;
            color: #777;
            font-size: 14px;
        }
        
        @media (max-width: 768px) {
            .container {
                padding: 15px;
            }
            
            .upload-card {
                padding: 20px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <header>
            <h1><i class="fas fa-cloud-upload-alt"></i> File and URL Management System</h1>
            <p>Upload files or add URLs and organize them efficiently</p>
        </header>
        
        <div class="upload-card">
            <?php if (isset($successMessage)): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i>
                    <?= htmlspecialchars($successMessage) ?>
                </div>
            <?php endif; ?>
            
            <?php if (isset($errorMessage)): ?>
                <div class="alert alert-error">
                    <i class="fas fa-exclamation-circle"></i>
                    <?= htmlspecialchars($errorMessage) ?>
                </div>
            <?php endif; ?>
            
            <form id="uploadForm" method="post" enctype="multipart/form-data">
                <div class="form-group">
                    <label for="user"><i class="fas fa-user"></i> Username</label>
                    <input type="text" id="user" name="user" placeholder="Enter your username" required>
                </div>
                
                <div class="form-group">
                    <label for="file"><i class="fas fa-file-alt"></i> File Upload</label>
                    <div class="file-upload">
                        <i class="fas fa-cloud-upload-alt"></i>
                        <h3>Drag & Drop Files Here</h3>
                        <p>Or click to browse your files</p>
                        <input type="file" id="file" name="file">
                    </div>
                    <div class="selected-file" id="selectedFile">
                        <i class="fas fa-file"></i>
                        <span id="fileName">No file selected</span>
                    </div>
                </div>
                
                <div class="or-divider">
                    OR
                </div>
                
                <div class="form-group">
                    <label for="url"><i class="fas fa-link"></i> URL</label>
                    <input type="url" id="url" name="url" placeholder="Enter a URL (e.g., https://example.com)">
                </div>
                
                <div class="form-group">
                    <label for="json_filename"><i class="fas fa-file-code"></i> JSON File Name</label>
                    <input type="text" id="json_filename" name="json_filename" placeholder="Enter name for JSON file (without .json)">
                    <small class="form-text">Leave blank to use automatic naming based on file type or URL</small>
                </div>
                
                <div class="progress-container" id="progressContainer">
                    <div class="progress-bar" id="progressBar"></div>
                </div>
                
                <div class="form-group">
                    <label for="description"><i class="fas fa-info-circle"></i> Description</label>
                    <textarea id="description" name="description" placeholder="Add a description for your file or URL"></textarea>
                </div>
                
                <button type="submit" class="btn btn-block" id="submitBtn">
                    <i class="fas fa-save"></i> Save Entry
                </button>
            </form>
        </div>
    </div>
    
    <footer>
        &copy; <?= date('Y') ?> File and URL Management System - All rights reserved
    </footer>
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const fileInput = document.getElementById('file');
            const fileName = document.getElementById('fileName');
            const selectedFile = document.getElementById('selectedFile');
            const urlInput = document.getElementById('url');
            const uploadForm = document.getElementById('uploadForm');
            const progressBar = document.getElementById('progressBar');
            const progressContainer = document.getElementById('progressContainer');
            
            // File input change event
            fileInput.addEventListener('change', function() {
                if (this.files && this.files[0]) {
                    const file = this.files[0];
                    fileName.textContent = file.name;
                    selectedFile.style.display = 'block';
                    
                    // Set appropriate file icon based on type
                    const fileIcon = selectedFile.querySelector('i');
                    const fileType = file.type.split('/')[0];
                    
                    switch (fileType) {
                        case 'image':
                            fileIcon.className = 'fas fa-file-image';
                            break;
                        case 'audio':
                            fileIcon.className = 'fas fa-file-audio';
                            break;
                        case 'video':
                            fileIcon.className = 'fas fa-file-video';
                            break;
                        case 'application':
                            if (file.type === 'application/pdf') {
                                fileIcon.className = 'fas fa-file-pdf';
                            } else if (file.type.includes('zip') || file.type.includes('archive')) {
                                fileIcon.className = 'fas fa-file-archive';
                            } else {
                                fileIcon.className = 'fas fa-file-alt';
                            }
                            break;
                        default:
                            fileIcon.className = 'fas fa-file';
                    }
                    
                    // Clear URL input when file is selected
                    urlInput.value = '';
                } else {
                    fileName.textContent = 'No file selected';
                    selectedFile.style.display = 'none';
                }
            });
            
            // URL input change event
            urlInput.addEventListener('input', function() {
                if (this.value) {
                    // Clear file input when URL is entered
                    fileInput.value = '';
                    fileName.textContent = 'No file selected';
                    selectedFile.style.display = 'none';
                }
            });
            
            // Drag and drop functionality
            const dropArea = document.querySelector('.file-upload');
            
            ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
                dropArea.addEventListener(eventName, preventDefaults, false);
            });
            
            function preventDefaults(e) {
                e.preventDefault();
                e.stopPropagation();
            }
            
            ['dragenter', 'dragover'].forEach(eventName => {
                dropArea.addEventListener(eventName, highlight, false);
            });
            
            ['dragleave', 'drop'].forEach(eventName => {
                dropArea.addEventListener(eventName, unhighlight, false);
            });
            
            function highlight() {
                dropArea.style.borderColor = 'var(--primary-color)';
                dropArea.style.backgroundColor = 'rgba(52, 152, 219, 0.1)';
            }
            
            function unhighlight() {
                dropArea.style.borderColor = '';
                dropArea.style.backgroundColor = '';
            }
            
            dropArea.addEventListener('drop', handleDrop, false);
            
            function handleDrop(e) {
                const dt = e.dataTransfer;
                const files = dt.files;
                
                fileInput.files = files;
                
                // Trigger change event manually
                const event = new Event('change');
                fileInput.dispatchEvent(event);
                
                // Clear URL input
                urlInput.value = '';
            }
            
            // Form submission with AJAX
            uploadForm.addEventListener('submit', function(e) {
                // Check if we want to use AJAX uploads
                const useAjax = false;
                
                if (useAjax) {
                    e.preventDefault();
                    
                    // Validate form
                    const hasFile = fileInput.files && fileInput.files[0];
                    const hasUrl = urlInput.value.trim() !== '';
                    
                    if (!hasFile && !hasUrl) {
                        alert('Please provide either a file or a URL');
                        return;
                    }
                    
                    const formData = new FormData(this);
                    const xhr = new XMLHttpRequest();
                    
                    // Show progress bar
                    progressContainer.style.display = 'block';
                    
                    xhr.upload.addEventListener('progress', function(e) {
                        if (e.lengthComputable) {
                            const percentComplete = (e.loaded / e.total) * 100;
                            progressBar.style.width = percentComplete + '%';
                        }
                    });
                    
                    xhr.addEventListener('load', function() {
                        if (xhr.status === 200) {
                            try {
                                const response = JSON.parse(xhr.responseText);
                                
                                if (response.success) {
                                    // Create success message
                                    const alertDiv = document.createElement('div');
                                    alertDiv.className = 'alert alert-success';
                                    alertDiv.innerHTML = `<i class="fas fa-check-circle"></i> ${response.message}`;
                                    
                                    // Insert before form
                                    uploadForm.parentNode.insertBefore(alertDiv, uploadForm);
                                    
                                    // Reset form
                                    uploadForm.reset();
                                    selectedFile.style.display = 'none';
                                } else {
                                    // Create error message
                                    const alertDiv = document.createElement('div');
                                    alertDiv.className = 'alert alert-error';
                                    alertDiv.innerHTML = `<i class="fas fa-exclamation-circle"></i> ${response.message}`;
                                    
                                    // Insert before form
                                    uploadForm.parentNode.insertBefore(alertDiv, uploadForm);
                                }
                            } catch (e) {
                                console.error('Error parsing response:', e);
                            }
                        }
                        
                        // Hide progress after a delay
                        setTimeout(function() {
                            progressContainer.style.display = 'none';
                            progressBar.style.width = '0%';
                        }, 1000);
                    });
                    
                    xhr.addEventListener('error', function() {
                        // Create error message
                        const alertDiv = document.createElement('div');
                        alertDiv.className = 'alert alert-error';
                        alertDiv.innerHTML = '<i class="fas fa-exclamation-circle"></i> An error occurred during upload';
                        
                        // Insert before form
                        uploadForm.parentNode.insertBefore(alertDiv, uploadForm);
                        
                        // Hide progress
                        progressContainer.style.display = 'none';
                    });
                    
                    xhr.open('POST', window.location.href);
                    xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
                    xhr.send(formData);
                }
                // If not using AJAX, the form will submit normally
            });
            
            // Auto-remove alerts after 5 seconds
            const alerts = document.querySelectorAll('.alert');
            alerts.forEach(alert => {
                setTimeout(() => {
                    alert.style.opacity = '0';
                    setTimeout(() => {
                        alert.remove();
                    }, 500);
                }, 5000);
            });
        });
    </script>
</body>
</html>