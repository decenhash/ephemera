<?php
// Configuration Constants
define('MAX_FILE_SIZE_KB', 20);
define('UPLOAD_DIRECTORY', 'files');
define('FILE_CATEGORIES', [
    'image' => ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'svg', 'webp'],
    'audio' => ['mp3', 'wav', 'ogg', 'flac', 'aac'],
    'video' => ['mp4', 'mov', 'avi', 'mkv', 'flv', 'webm'],
    'document' => ['pdf', 'doc', 'docx', 'txt'],
    'archive' => ['zip', 'rar', '7z', 'tar', 'gz'],
    'other' => []
]);

/**
 * Determines the file category based on its extension
 */
function getFileCategory(string $filename, array $categories): string {
    $extension = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
    
    foreach ($categories as $category => $extensions) {
        if (in_array($extension, $extensions)) {
            return $category;
        }
    }
    return 'other';
}

/**
 * Finds the appropriate JSON file for storing the entry
 */
function findTargetJsonFile(string $category): string {
    $fileNumber = 1;
    
    while (true) {
        $filename = ($fileNumber === 1) ? "$category.json" : "{$category}_{$fileNumber}.json";
        
        if (!file_exists($filename)) {
            return $filename;
        }
        
        if (filesize($filename) < (MAX_FILE_SIZE_KB * 1024)) {
            return $filename;
        }
        
        $fileNumber++;
    }
}

/**
 * Adds a new entry to the JSON file
 */
function addEntryToJson(string $targetFile, array $newEntry): array {
    $data = ['files' => []];
    
    if (file_exists($targetFile)) {
        $jsonContent = file_get_contents($targetFile);
        $data = json_decode($jsonContent, true) ?? $data;
    }
    
    $data['files'][] = $newEntry;
    
    $data['metadata'] = [
        'total_files' => count($data['files']),
        'last_updated' => date('c'), // ISO 8601 format
        'file_size_kb' => round(strlen(json_encode($data)) / 1024, 2)
    ];
    
    file_put_contents($targetFile, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
    
    return $data['metadata'];
}

// Handle form submission
$response = ['status' => '', 'message' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        if (empty($_FILES['file']['name'])) {
            throw new RuntimeException('No file selected for upload');
        }
        
        $uploadedFile = $_FILES['file'];
        $filename = basename($uploadedFile['name']);
        $category = getFileCategory($filename, FILE_CATEGORIES);
        
        // Basic file validation
        if ($uploadedFile['error'] !== UPLOAD_ERR_OK) {
            throw new RuntimeException('File upload error: ' . $uploadedFile['error']);
        }
        
        if ($uploadedFile['size'] > (5 * 1024 * 1024)) { // 5MB max
            throw new RuntimeException('File size exceeds maximum limit of 5MB');
        }
        
        $fileHash = md5_file($uploadedFile['tmp_name']);
        
        $newEntry = [
            'filename' => $filename,
            'user' => filter_input(INPUT_POST, 'user', FILTER_SANITIZE_STRING) ?? 'anonymous',
            'date' => date('Y-m-d'),
            'hash' => $fileHash,
            'extension' => pathinfo($filename, PATHINFO_EXTENSION),
            'link' => UPLOAD_DIRECTORY . '/' . rawurlencode($filename),
            'description' => filter_input(INPUT_POST, 'description', FILTER_SANITIZE_STRING) ?? ''
        ];
        
        $targetFile = findTargetJsonFile($category);
        $metadata = addEntryToJson($targetFile, $newEntry);
        
        // Ensure upload directory exists
        if (!is_dir(UPLOAD_DIRECTORY)) {
            mkdir(UPLOAD_DIRECTORY, 0755, true);
        }
        
        $destination = UPLOAD_DIRECTORY . '/' . $filename;
        if (!move_uploaded_file($uploadedFile['tmp_name'], $destination)) {
            throw new RuntimeException('Failed to move uploaded file');
        }
        
        $response = [
            'status' => 'success',
            'message' => "File successfully uploaded to $targetFile",
            'metadata' => $metadata
        ];
    } catch (Exception $e) {
        $response = [
            'status' => 'error',
            'message' => $e->getMessage()
        ];
    }
    
    // For AJAX requests, return JSON response
    if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
        header('Content-Type: application/json');
        echo json_encode($response);
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>File Upload System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #4361ee;
            --success-color: #4cc9f0;
            --error-color: #f72585;
            --text-color: #2b2d42;
            --light-gray: #f8f9fa;
            --border-radius: 8px;
            --box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            --transition: all 0.3s ease;
        }
        
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            color: var(--text-color);
            background-color: #f5f7fa;
            padding: 2rem;
        }
        
        .container {
            max-width: 800px;
            margin: 0 auto;
            background: white;
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
            padding: 2rem;
        }
        
        h1 {
            color: var(--primary-color);
            margin-bottom: 1.5rem;
            text-align: center;
        }
        
        .alert {
            padding: 1rem;
            border-radius: var(--border-radius);
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
        }
        
        .alert-success {
            background-color: rgba(76, 201, 240, 0.1);
            border-left: 4px solid var(--success-color);
            color: var(--success-color);
        }
        
        .alert-error {
            background-color: rgba(247, 37, 133, 0.1);
            border-left: 4px solid var(--error-color);
            color: var(--error-color);
        }
        
        .alert i {
            margin-right: 0.75rem;
            font-size: 1.25rem;
        }
        
        .form-group {
            margin-bottom: 1.5rem;
        }
        
        label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 600;
        }
        
        input[type="text"],
        input[type="file"],
        textarea,
        select {
            width: 100%;
            padding: 0.75rem 1rem;
            border: 1px solid #ddd;
            border-radius: var(--border-radius);
            font-size: 1rem;
            transition: var(--transition);
        }
        
        input:focus,
        textarea:focus,
        select:focus {
            outline: none;
            border-color: var(--primary-color);
            box-shadow: 0 0 0 3px rgba(67, 97, 238, 0.2);
        }
        
        textarea {
            min-height: 120px;
            resize: vertical;
        }
        
        .file-input-wrapper {
            position: relative;
            overflow: hidden;
            display: inline-block;
            width: 100%;
        }
        
        .file-input-button {
            border: 2px dashed #ddd;
            border-radius: var(--border-radius);
            padding: 2rem;
            text-align: center;
            cursor: pointer;
            transition: var(--transition);
        }
        
        .file-input-button:hover {
            border-color: var(--primary-color);
            background-color: rgba(67, 97, 238, 0.05);
        }
        
        .file-input-button i {
            font-size: 2rem;
            color: var(--primary-color);
            margin-bottom: 0.5rem;
        }
        
        .file-input {
            position: absolute;
            left: 0;
            top: 0;
            opacity: 0;
            width: 100%;
            height: 100%;
            cursor: pointer;
        }
        
        .file-name {
            margin-top: 0.5rem;
            font-size: 0.9rem;
            color: #666;
        }
        
        button {
            background-color: var(--primary-color);
            color: white;
            border: none;
            padding: 0.75rem 1.5rem;
            border-radius: var(--border-radius);
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: var(--transition);
            width: 100%;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        button:hover {
            background-color: #3a56d4;
            transform: translateY(-2px);
        }
        
        button i {
            margin-right: 0.5rem;
        }
        
        .progress-container {
            margin-top: 1rem;
            display: none;
        }
        
        .progress-bar {
            height: 6px;
            background-color: #e9ecef;
            border-radius: 3px;
            overflow: hidden;
        }
        
        .progress {
            height: 100%;
            background-color: var(--primary-color);
            width: 0%;
            transition: width 0.3s ease;
        }
        
        @media (max-width: 768px) {
            .container {
                padding: 1.5rem;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <h1><i class="fas fa-cloud-upload-alt"></i> File Upload System</h1>
        
        <?php if ($response['status'] === 'success'): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i>
                <div>
                    <strong>Success!</strong> <?= htmlspecialchars($response['message']) ?>
                    <?php if (isset($response['metadata'])): ?>
                        <div class="file-meta">
                            File size: <?= htmlspecialchars($response['metadata']['file_size_kb']) ?> KB | 
                            Total files: <?= htmlspecialchars($response['metadata']['total_files']) ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        <?php elseif ($response['status'] === 'error'): ?>
            <div class="alert alert-error">
                <i class="fas fa-exclamation-circle"></i>
                <div>
                    <strong>Error:</strong> <?= htmlspecialchars($response['message']) ?>
                </div>
            </div>
        <?php endif; ?>
        
        <form id="uploadForm" method="post" enctype="multipart/form-data">
            <div class="form-group">
                <label for="user">Your Name</label>
                <input type="text" id="user" name="user" placeholder="Enter your name" required>
            </div>
            
            <div class="form-group">
                <label>File Upload</label>
                <div class="file-input-wrapper">
                    <div class="file-input-button">
                        <i class="fas fa-file-upload"></i>
                        <div>Click to browse or drag and drop files here</div>
                        <div class="file-name" id="fileName">No file selected</div>
                    </div>
                    <input type="file" class="file-input" id="file" name="file" required>
                </div>
                <div class="progress-container" id="progressContainer">
                    <div class="progress-bar">
                        <div class="progress" id="progressBar"></div>
                    </div>
                    <div class="progress-text" id="progressText">Uploading...</div>
                </div>
            </div>
            
            <div class="form-group">
                <label for="description">Description (Optional)</label>
                <textarea id="description" name="description" placeholder="Enter a description for the file"></textarea>
            </div>
            
            <button type="submit" id="submitButton">
                <i class="fas fa-upload"></i> Upload File
            </button>
        </form>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const fileInput = document.getElementById('file');
            const fileNameDisplay = document.getElementById('fileName');
            const uploadForm = document.getElementById('uploadForm');
            const progressContainer = document.getElementById('progressContainer');
            const progressBar = document.getElementById('progressBar');
            const progressText = document.getElementById('progressText');
            const submitButton = document.getElementById('submitButton');
            
            // Update file name display
            fileInput.addEventListener('change', function() {
                if (this.files.length > 0) {
                    fileNameDisplay.textContent = this.files[0].name;
                } else {
                    fileNameDisplay.textContent = 'No file selected';
                }
            });
            
            // Drag and drop functionality
            const dropArea = document.querySelector('.file-input-button');
            
            ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
                dropArea.addEventListener(eventName, preventDefaults, false);
            });
            
            function preventDefaults(e) {
                e.preventDefault();
                e.stopPropagation();
            }
            
            ['dragenter', 'dragover'].forEach(eventName => {
                dropArea.addEventListener(eventName, highlight, false);
            });
            
            ['dragleave', 'drop'].forEach(eventName => {
                dropArea.addEventListener(eventName, unhighlight, false);
            });
            
            function highlight() {
                dropArea.style.borderColor = '#4361ee';
                dropArea.style.backgroundColor = 'rgba(67, 97, 238, 0.1)';
            }
            
            function unhighlight() {
                dropArea.style.borderColor = '#ddd';
                dropArea.style.backgroundColor = '';
            }
            
            dropArea.addEventListener('drop', handleDrop, false);
            
            function handleDrop(e) {
                const dt = e.dataTransfer;
                const files = dt.files;
                fileInput.files = files;
                fileNameDisplay.textContent = files[0].name;
            }
            
            // AJAX form submission with progress
            uploadForm.addEventListener('submit', function(e) {
                e.preventDefault();
                
                const formData = new FormData(this);
                const xhr = new XMLHttpRequest();
                
                xhr.open('POST', '', true);
                
                // Show progress bar
                progressContainer.style.display = 'block';
                submitButton.disabled = true;
                submitButton.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Uploading...';
                
                xhr.upload.onprogress = function(e) {
                    if (e.lengthComputable) {
                        const percentComplete = Math.round((e.loaded / e.total) * 100);
                        progressBar.style.width = percentComplete + '%';
                        progressText.textContent = `Uploading: ${percentComplete}%`;
                    }
                };
                
                xhr.onload = function() {
                    if (xhr.status === 200) {
                        try {
                            const response = JSON.parse(xhr.responseText);
                            
                            if (response.status === 'success') {
                                // Show success message and reset form
                                window.location.href = window.location.href + '?success=1';
                            } else {
                                // Show error message
                                alert('Error: ' + response.message);
                                resetForm();
                            }
                        } catch (e) {
                            // If response isn't JSON, reload the page
                            window.location.reload();
                        }
                    } else {
                        alert('Error: ' + xhr.statusText);
                        resetForm();
                    }
                };
                
                xhr.onerror = function() {
                    alert('An error occurred during the upload');
                    resetForm();
                };
                
                xhr.send(formData);
            });
            
            function resetForm() {
                progressContainer.style.display = 'none';
                progressBar.style.width = '0%';
                submitButton.disabled = false;
                submitButton.innerHTML = '<i class="fas fa-upload"></i> Upload File';
            }
            
            // Check for success parameter in URL
            if (window.location.search.includes('success=1')) {
                window.history.replaceState({}, document.title, window.location.pathname);
            }
        });
    </script>
</body>
</html>