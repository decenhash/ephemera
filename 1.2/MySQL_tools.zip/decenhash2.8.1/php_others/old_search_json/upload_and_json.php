<?php
// Handle file upload if form was submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['fileToUpload'])) {
    // Create directories if they don't exist
    if (!file_exists('data_search_json')) {
        mkdir('data_search_json', 0755, true);
    }
    if (!file_exists('uploads')) {
        mkdir('uploads', 0755, true);
    }

    $uploadOk = true;
    $errorMsg = '';
    
    // Check if file is a PHP file
    $fileType = strtolower(pathinfo($_FILES['fileToUpload']['name'], PATHINFO_EXTENSION));
    if ($fileType === 'php') {
        $uploadOk = false;
        $errorMsg = "PHP files are not allowed.";
    }

    // Check file size (limit to 10MB for this example)
    if ($_FILES['fileToUpload']['size'] > 10000000) {
        $uploadOk = false;
        $errorMsg = "File is too large (max 10MB).";
    }

    // Check if upload was successful
    if ($uploadOk) {
        // Generate unique filename to prevent overwrites
        $uploadFileName = basename($_FILES['fileToUpload']['name']);
        $targetFilePath = 'uploads/' . $uploadFileName;

        if (file_exists("$targetFilePath")){
            echo "File already exists";
            die;
        }
        
        // Try to move the uploaded file
        if (move_uploaded_file($_FILES['fileToUpload']['tmp_name'], $targetFilePath)) {
            // Generate file hash
            $fileHash = hash_file('sha256', $targetFilePath);
            
            // Get file info
            $fileSize = filesize($targetFilePath);
            $fileSizeFormatted = formatBytes($fileSize);
            $currentDate = date('Y-m-d H:i:s');
            
            // Prepare metadata
            $metadata = [];
            if (!empty($_POST['file_url'])) $metadata['file_url'] = $_POST['file_url'];
            if (!empty($_POST['username'])) $metadata['username'] = $_POST['username'];
            if (!empty($_POST['PIX'])) $metadata['PIX'] = $_POST['PIX'];
            if (!empty($_POST['BTC'])) $metadata['BTC'] = $_POST['BTC'];
            if (!empty($_POST['other_url'])) $metadata['other_url'] = $_POST['other_url'];
            
            // Create entry
            $entry = [
                'filename' => $_FILES['fileToUpload']['name'],
                'stored_filename' => $uploadFileName,
                'file_hash' => $fileHash,
                'file_extension' => $fileType,
                'date' => $currentDate,
                'file_size' => $fileSizeFormatted,
                'file_path' => $targetFilePath
            ];
            
            if (!empty($metadata)) {
                $entry['_metadata'] = $metadata;
            }
            
            // Determine JSON filename
            $jsonFilename = 'data_search_json/';
            if (!empty($_POST['jsonFilename'])) {
                $jsonFilename .= preg_replace('/[^a-zA-Z0-9_\-]/', '', $_POST['jsonFilename']) . '.json';
            } else {
                $jsonFilename .= $fileType . '.json';
            }
            
            // Handle JSON file rotation
            $baseFilename = pathinfo($jsonFilename, PATHINFO_FILENAME);
            $extension = pathinfo($jsonFilename, PATHINFO_EXTENSION);
            $counter = 0;
            $finalJsonFilename = $jsonFilename;
            
            while (true) {
                if (!file_exists($finalJsonFilename)) {
                    break;
                }
                
                $currentData = json_decode(file_get_contents($finalJsonFilename), true) ?: [];
                
                // Check if current file has space
                if (count($currentData) < 20 && filesize($finalJsonFilename) < 20000) {
                    break;
                }
                
                // Move to next file
                $counter++;
                $finalJsonFilename = "data_search_json/{$baseFilename}_{$counter}.{$extension}";
            }
            
            // Add new entry to JSON
            $currentData = file_exists($finalJsonFilename) ? json_decode(file_get_contents($finalJsonFilename), true) : [];
            $currentData[] = $entry;
            file_put_contents($finalJsonFilename, json_encode($currentData, JSON_PRETTY_PRINT));
            
            $successMsg = "File successfully uploaded and information saved to " . basename($finalJsonFilename);
        } else {
            $errorMsg = "There was an error uploading your file.";
        }
    }
}

function formatBytes($bytes, $precision = 2) {
    $units = ['B', 'KB', 'MB', 'GB', 'TB'];
    $bytes = max($bytes, 0);
    $pow = floor(($bytes ? log($bytes) : 0) / log(1024));
    $pow = min($pow, count($units) - 1);
    $bytes /= pow(1024, $pow);
    return round($bytes, $precision) . ' ' . $units[$pow];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>File Upload to JSON</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            margin: 0;
            padding: 20px;
            background-color: #f5f5f5;
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        h1 {
            color: #333;
            text-align: center;
        }
        .upload-form {
            margin-top: 20px;
        }
        .form-group {
            margin-bottom: 15px;
        }
        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        input[type="file"], input[type="text"], input[type="url"] {
            width: 100%;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
            box-sizing: border-box;
        }
        fieldset {
            border: 1px solid #ddd;
            border-radius: 4px;
            padding: 10px;
            margin-bottom: 15px;
        }
        legend {
            padding: 0 10px;
            font-weight: bold;
        }
        button {
            background-color: #4CAF50;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }
        button:hover {
            background-color: #45a049;
        }
        .message {
            padding: 10px;
            margin: 10px 0;
            border-radius: 4px;
        }
        .success {
            background-color: #dff0d8;
            color: #3c763d;
            border: 1px solid #d6e9c6;
        }
        .error {
            background-color: #f2dede;
            color: #a94442;
            border: 1px solid #ebccd1;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>File Upload to JSON</h1>
        
        <?php if (isset($successMsg)): ?>
            <div class="message success"><?php echo htmlspecialchars($successMsg); ?></div>
        <?php elseif (isset($errorMsg)): ?>
            <div class="message error"><?php echo htmlspecialchars($errorMsg); ?></div>
        <?php endif; ?>
        
        <form action="" method="post" enctype="multipart/form-data" class="upload-form">
            <div class="form-group">
                <label for="fileToUpload">Select file to upload:</label>
                <input type="file" name="fileToUpload" id="fileToUpload" required>
            </div>
            
            <div class="form-group">
                <label for="jsonFilename">JSON filename (optional):</label>
                <input type="text" name="jsonFilename" id="jsonFilename" placeholder="Leave blank for automatic">
            </div>
            
            <fieldset class="metadata-group">
                <legend>Metadata (optional)</legend>
                <div class="form-group">
                    <label for="file_url">File URL:</label>
                    <input type="url" name="file_url" id="file_url">
                </div>
                <div class="form-group">
                    <label for="username">Username:</label>
                    <input type="text" name="username" id="username">
                </div>
                <div class="form-group">
                    <label for="PIX">PIX:</label>
                    <input type="text" name="PIX" id="PIX">
                </div>
                <div class="form-group">
                    <label for="BTC">BTC:</label>
                    <input type="text" name="BTC" id="BTC">
                </div>
                <div class="form-group">
                    <label for="other_url">Other URL:</label>
                    <input type="url" name="other_url" id="other_url">
                </div>
            </fieldset>
            
            <button type="submit">Upload File</button>
        </form>
    </div>
</body>
</html>