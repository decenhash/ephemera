<?php
function getFileHash($filepath) {
    return hash_file('sha256', $filepath);
}

function formatSizeUnits($bytes) {
    if ($bytes >= 1073741824) {
        return number_format($bytes / 1073741824, 2) . ' GB';
    } elseif ($bytes >= 1048576) {
        return number_format($bytes / 1048576, 2) . ' MB';
    } elseif ($bytes >= 1024) {
        return number_format($bytes / 1024, 2) . ' KB';
    } elseif ($bytes > 1) {
        return $bytes . ' bytes';
    } elseif ($bytes == 1) {
        return $bytes . ' byte';
    } else {
        return '0 bytes';
    }
}

function processUploadsFolder($uploadsDir = 'uploads') {
    if (!is_dir($uploadsDir)) {
        return ['error' => 'Uploads directory does not exist'];
    }

    // Create data_search_json directory if it doesn't exist
    $jsonDir = 'data_search_json';
    if (!is_dir($jsonDir)) {
        if (!mkdir($jsonDir, 0755, true)) {
            return ['error' => 'Failed to create JSON directory'];
        }
    }

    $files = scandir($uploadsDir);
    $fileData = [];

    foreach ($files as $file) {
        if ($file === '.' || $file === '..') continue;

        $filePath = $uploadsDir . DIRECTORY_SEPARATOR . $file;
        if (!is_file($filePath)) continue;

        $fileExtension = strtolower(pathinfo($filePath, PATHINFO_EXTENSION));
        if (empty($fileExtension)) continue;

        $fileSize = filesize($filePath);
        $modifiedTime = filemtime($filePath);

        $fileData[$fileExtension][] = [
            'filename' => $file,
            'file_hash' => getFileHash($filePath),
            'file_extension' => $fileExtension,
            'date' => date('Y-m-d H:i:s', $modifiedTime),
            'file_size' => formatSizeUnits($fileSize)
        ];
    }

    foreach ($fileData as $extension => $entries) {
        $chunks = array_chunk($entries, 20);
        
        foreach ($chunks as $index => $chunk) {
            $jsonData = json_encode($chunk, JSON_PRETTY_PRINT);
            $jsonSize = strlen($jsonData);
            
            $baseFilename = $extension . '.json';
            if ($index > 0 || $jsonSize > 20480) { // 20KB = 20480 bytes
                $baseFilename = $extension . '_' . $index . '.json';
            }
            
            $outputPath = $jsonDir . DIRECTORY_SEPARATOR . $baseFilename;
            file_put_contents($outputPath, $jsonData);
        }
    }

    return ['success' => 'Files processed successfully', 'json_location' => $jsonDir];
}

// Execute the function
$result = processUploadsFolder();
print_r($result);
?>