<?php
// Define functions first
function getFileHash($filepath) {
    return hash_file('sha256', $filepath);
}

function formatSizeUnits($bytes) {
    if ($bytes >= 1073741824) {
        return number_format($bytes / 1073741824, 2) . ' GB';
    } elseif ($bytes >= 1048576) {
        return number_format($bytes / 1048576, 2) . ' MB';
    } elseif ($bytes >= 1024) {
        return number_format($bytes / 1024, 2) . ' KB';
    } elseif ($bytes > 1) {
        return $bytes . ' bytes';
    } elseif ($bytes == 1) {
        return $bytes . ' byte';
    } else {
        return '0 bytes';
    }
}

function processUploadsFolder($uploadsDir, $metadata) {
    if (!is_dir($uploadsDir)) {
        return ['error' => 'Uploads directory does not exist'];
    }

    $jsonDir = 'data_search_json';
    if (!is_dir($jsonDir)) {
        if (!mkdir($jsonDir, 0755, true)) {
            return ['error' => 'Failed to create JSON directory'];
        }
    }

    $files = scandir($uploadsDir);
    $fileData = [];

    foreach ($files as $file) {
        if ($file === '.' || $file === '..') continue;

        $filePath = $uploadsDir . DIRECTORY_SEPARATOR . $file;
        if (!is_file($filePath)) continue;

        $fileExtension = strtolower(pathinfo($filePath, PATHINFO_EXTENSION));
        if (empty($fileExtension)) continue;

        $fileSize = filesize($filePath);
        $modifiedTime = filemtime($filePath);

        $fileEntry = [
            'filename' => $file,
            'file_hash' => getFileHash($filePath),
            'file_extension' => $fileExtension,
            'date' => date('Y-m-d H:i:s', $modifiedTime),
            'file_size' => formatSizeUnits($fileSize)
        ];
        
        if (!empty($metadata)) {
            $fileEntry['_metadata'] = $metadata;
        }

        $fileData[$fileExtension][] = $fileEntry;
    }

    foreach ($fileData as $extension => $entries) {
        $chunks = array_chunk($entries, 20);
        
        foreach ($chunks as $index => $chunk) {
            $jsonData = json_encode($chunk, JSON_PRETTY_PRINT);
            $jsonSize = strlen($jsonData);
            
            $baseFilename = $extension . '.json';
            if ($index > 0 || $jsonSize > 20480) {
                $baseFilename = $extension . '_' . $index . '.json';
            }
            
            $outputPath = $jsonDir . DIRECTORY_SEPARATOR . $baseFilename;
            file_put_contents($outputPath, $jsonData);
        }
    }

    return ['success' => 'Files processed successfully', 'json_location' => $jsonDir];
}

// Handle form submission
$result = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $metadata = [
        'file_url' => $_POST['file_url'] ?? '',
        'username' => $_POST['username'] ?? '',
        'PIX' => $_POST['pix'] ?? '',
        'BTC' => $_POST['btc'] ?? '',
        'other_url' => $_POST['other_url'] ?? ''
    ];
    
    // Remove empty fields
    $metadata = array_filter($metadata);
    
    $result = processUploadsFolder('uploads', $metadata);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>File Metadata Processor</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            color: #333;
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            background-color: #f5f5f5;
        }
        
        h1 {
            color: #2c3e50;
            text-align: center;
            margin-bottom: 30px;
        }
        
        .form-container {
            background-color: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #2c3e50;
        }
        
        input[type="text"] {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 16px;
            box-sizing: border-box;
        }
        
        input[type="text"]:focus {
            border-color: #3498db;
            outline: none;
            box-shadow: 0 0 0 2px rgba(52, 152, 219, 0.2);
        }
        
        .submit-btn {
            background-color: #3498db;
            color: white;
            border: none;
            padding: 12px 20px;
            font-size: 16px;
            border-radius: 4px;
            cursor: pointer;
            width: 100%;
            transition: background-color 0.3s;
        }
        
        .submit-btn:hover {
            background-color: #2980b9;
        }
        
        .result {
            margin-top: 30px;
            padding: 20px;
            border-radius: 8px;
            background-color: <?php echo isset($result['error']) ? '#f8d7da' : '#d4edda'; ?>;
            color: <?php echo isset($result['error']) ? '#721c24' : '#155724'; ?>;
            display: <?php echo $result ? 'block' : 'none'; ?>;
        }
        
        .field-note {
            font-size: 12px;
            color: #7f8c8d;
            margin-top: 5px;
        }
        
        .required:after {
            content: " *";
            color: #e74c3c;
        }
    </style>
</head>
<body>
    <h1>File Metadata Processor</h1>
    
    <div class="form-container">
        <form method="POST">
            <div class="form-group">
                <label for="file_url" class="required">File URL</label>
                <input type="text" id="file_url" name="file_url" required placeholder="https://example.com/files/">
                <p class="field-note">The base URL where files will be accessible</p>
            </div>
            
            <div class="form-group">
                <label for="username" class="required">Username</label>
                <input type="text" id="username" name="username" required placeholder="Your username">
            </div>
            
            <div class="form-group">
                <label for="pix" class="required">PIX Key</label>
                <input type="text" id="pix" name="pix" required placeholder="Your PIX payment information">
            </div>
            
            <div class="form-group">
                <label for="btc">BTC Address (optional)</label>
                <input type="text" id="btc" name="btc" placeholder="Your Bitcoin address">
                <p class="field-note">Leave blank if you don't accept Bitcoin</p>
            </div>
            
            <div class="form-group">
                <label for="other_url">Other URL (optional)</label>
                <input type="text" id="other_url" name="other_url" placeholder="https://yourwebsite.com">
                <p class="field-note">Any additional URL you want to include</p>
            </div>
            
            <button type="submit" class="submit-btn">Process Files</button>
        </form>
    </div>
    
    <?php if ($result): ?>
        <div class="result">
            <?php if (isset($result['error'])): ?>
                <strong>Error:</strong> <?php echo htmlspecialchars($result['error']); ?>
            <?php else: ?>
                <strong>Success!</strong> <?php echo htmlspecialchars($result['success']); ?><br>
                JSON files saved in: <?php echo htmlspecialchars($result['json_location']); ?>
            <?php endif; ?>
        </div>
    <?php endif; ?>
</body>
</html>