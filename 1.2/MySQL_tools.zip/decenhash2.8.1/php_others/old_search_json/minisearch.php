﻿<?php
// Database configuration
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "decenhash";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}

// Initialize variables
$searchTerm = "";
$extensionFilter = "all";
$results = [];
$totalResults = 0;
$currentPage = 1;
$resultsPerPage = 10;
$totalPages = 1;

// Get current page from URL
if (isset($_GET['page']) && is_numeric($_GET['page'])) {
    $currentPage = (int)$_GET['page'];
}

// Process search if form was submitted
if ($_SERVER["REQUEST_METHOD"] == "GET" && (isset($_GET['search']) || isset($_GET['extension']))) {
    $searchTerm = isset($_GET['search']) ? trim($_GET['search']) : "";
    $extensionFilter = isset($_GET['extension']) ? $_GET['extension'] : "all";
    
    // Build SQL query
    $sql = "SELECT * FROM works WHERE 1=1";
    $countSql = "SELECT COUNT(*) as total FROM works WHERE 1=1";
    $params = [];
    $types = "";
    
    // Add extension filter if not "all"
    if ($extensionFilter != "all") {
        $sql .= " AND file_extension = ?";
        $countSql .= " AND file_extension = ?";
        $params[] = $extensionFilter;
        $types .= "s";
    }
    
    // Add search term if not empty
    if (!empty($searchTerm)) {
        $sql .= " AND (filename LIKE ? OR pix_key LIKE ? OR file_extension LIKE ?)";
        $countSql .= " AND (filename LIKE ? OR pix_key LIKE ? OR file_extension LIKE ?)";
        $searchParam = "%" . $searchTerm . "%";
        $params[] = $searchParam;
        $params[] = $searchParam;
        $params[] = $searchParam;
        $types .= "sss";
    }
    
    // Get total results count for pagination
    $stmt = $conn->prepare($countSql);
    if ($params) {
        $stmt->bind_param($types, ...$params);
    }
    $stmt->execute();
    $result = $stmt->get_result();
    $totalResults = $result->fetch_assoc()['total'];
    $stmt->close();
    
    // Calculate pagination
    $totalPages = ceil($totalResults / $resultsPerPage);
    $offset = ($currentPage - 1) * $resultsPerPage;
    
    // Add sorting by points descending
    $sql .= " ORDER BY points DESC";
    
    // Add pagination
    $sql .= " LIMIT ? OFFSET ?";
    $params[] = $resultsPerPage;
    $params[] = $offset;
    $types .= "ii";
    
    // Prepare and execute statement
    $stmt = $conn->prepare($sql);
    if ($params) {
        $stmt->bind_param($types, ...$params);
    }
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $results = $result->fetch_all(MYSQLI_ASSOC);
    }
    
    $stmt->close();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pesquisa</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
            background-color: #f5f5f5;
        }
        .container {
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        h1 {
            color: #333;
            text-align: center;
        }
        .search-container {
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
        }
        .search-input {
            flex: 1;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 16px;
        }
        .search-button {
            padding: 10px 20px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }
        .search-button:hover {
            background-color: #45a049;
        }
        .filter-buttons {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            margin-bottom: 20px;
        }
        .filter-button {
            padding: 8px 15px;
            background-color: #e7e7e7;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
        }
        .filter-button:hover, .filter-button.active {
            background-color: #4CAF50;
            color: white;
        }
        .results-container {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 20px;
        }
        .file-card {
            border: 1px solid #ddd;
            border-radius: 8px;
            padding: 15px;
            background-color: white;
            transition: transform 0.2s;
            cursor: pointer;
        }
        .file-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        .file-icon {
            font-size: 40px;
            text-align: center;
            margin-bottom: 10px;
        }
        .file-name {
            font-weight: bold;
            margin-bottom: 5px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        .file-details {
            color: #666;
            font-size: 14px;
            margin-bottom: 5px;
        }
        .file-pix {
            color: #333;
            font-weight: bold;
            margin-top: 10px;
        }
        .no-results {
            text-align: center;
            color: #666;
            padding: 20px;
            grid-column: 1 / -1;
        }
        .file-preview {
            width: 100%;
            height: 120px;
            object-fit: cover;
            border-radius: 4px;
            margin-bottom: 10px;
            background-color: #f0f0f0;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #999;
            font-size: 14px;
        }
        .file-preview img {
            max-width: 100%;
            max-height: 100%;
        }
        .pagination {
            display: flex;
            justify-content: center;
            margin-top: 30px;
            gap: 5px;
        }
        .pagination a, .pagination span {
            padding: 8px 15px;
            border: 1px solid #ddd;
            text-decoration: none;
            color: #333;
            border-radius: 4px;
        }
        .pagination a:hover {
            background-color: #f0f0f0;
        }
        .pagination .current {
            background-color: #4CAF50;
            color: white;
            border-color: #4CAF50;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Pesquisa</h1>
        
        <form method="GET" action="">
            <input type="hidden" name="page" value="1">
            <div class="search-container">
                <input type="text" name="search" class="search-input" placeholder="Digite para buscar por nome, chave pix ou extensão..." 
                       value="<?php echo htmlspecialchars($searchTerm); ?>">
                <button type="submit" class="search-button">Buscar</button>
            </div>
            
            <div class="filter-buttons">
                <button type="submit" name="extension" value="all" class="filter-button <?php echo $extensionFilter == 'all' ? 'active' : ''; ?>">Todos</button>
                <button type="submit" name="extension" value="jpg" class="filter-button <?php echo $extensionFilter == 'jpg' ? 'active' : ''; ?>">JPG</button>
                <button type="submit" name="extension" value="mp4" class="filter-button <?php echo $extensionFilter == 'mp4' ? 'active' : ''; ?>">MP4</button>
                <button type="submit" name="extension" value="mp3" class="filter-button <?php echo $extensionFilter == 'mp3' ? 'active' : ''; ?>">MP3</button>
                <button type="submit" name="extension" value="pdf" class="filter-button <?php echo $extensionFilter == 'pdf' ? 'active' : ''; ?>">PDF</button>
                <button type="submit" name="extension" value="doc" class="filter-button <?php echo $extensionFilter == 'doc' ? 'active' : ''; ?>">DOC</button>
                <button type="submit" name="extension" value="docx" class="filter-button <?php echo $extensionFilter == 'docx' ? 'active' : ''; ?>">DOCX</button>
                <button type="submit" name="extension" value="zip" class="filter-button <?php echo $extensionFilter == 'zip' ? 'active' : ''; ?>">ZIP</button>
                <button type="submit" name="extension" value="url" class="filter-button <?php echo $extensionFilter == 'url' ? 'active' : ''; ?>">URL</button>
            </div>
        </form>
        
        <div class="results-container" id="resultsContainer">
            <?php if ($_SERVER["REQUEST_METHOD"] == "GET" && (isset($_GET['search']) || isset($_GET['extension']))) : ?>
                <?php if (empty($results)) : ?>
                    <div class="no-results">Nenhum arquivo encontrado</div>
                <?php else : ?>
                    <?php foreach ($results as $file) : ?>
                        <div class="file-card" onclick="<?php echo $file['file_extension'] === 'url' ? 'window.open(\'' . htmlspecialchars($file['filename']) . '\', \'_blank\')' : 'window.open(\'uploads/' . $file['file_hash'] . '.' . $file['file_extension'] . '\', \'_blank\')'; ?>">
                            <div class="file-preview">
                                <?php echo getFilePreview($file); ?>
                            </div>
                            <div class="file-icon"><?php echo getFileIcon($file['file_extension']); ?></div>
                            <div class="file-name" title="<?php echo htmlspecialchars($file['filename']); ?>">
                                <?php echo htmlspecialchars($file['filename']); ?>
                            </div>
                            <div class="file-details">
                                <div>Tipo: <?php echo strtoupper($file['file_extension']); ?></div>
                                <div>Tamanho: <?php echo $file['file_size']; ?></div>
                                <div>Data: <?php echo date('d/m/Y', strtotime($file['date'])); ?></div>
                            </div>
                            <div class="file-pix">Chave Pix: <?php echo htmlspecialchars($file['pix_key']); ?></div>
                            <div class="file-details">Pontos: <?php echo $file['points']; ?></div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            <?php else : ?>
                <div class="no-results">Use os filtros acima para buscar arquivos</div>
            <?php endif; ?>
        </div>

        <?php if ($totalPages > 1) : ?>
            <div class="pagination">
                <?php if ($currentPage > 1) : ?>
                    <a href="?<?php echo buildQueryString($currentPage - 1, $searchTerm, $extensionFilter); ?>">&laquo; Anterior</a>
                <?php endif; ?>
                
                <?php for ($i = 1; $i <= $totalPages; $i++) : ?>
                    <?php if ($i == $currentPage) : ?>
                        <span class="current"><?php echo $i; ?></span>
                    <?php else : ?>
                        <a href="?<?php echo buildQueryString($i, $searchTerm, $extensionFilter); ?>"><?php echo $i; ?></a>
                    <?php endif; ?>
                <?php endfor; ?>
                
                <?php if ($currentPage < $totalPages) : ?>
                    <a href="?<?php echo buildQueryString($currentPage + 1, $searchTerm, $extensionFilter); ?>">Próxima &raquo;</a>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>

<?php
// Helper function to get appropriate icon for file type
function getFileIcon($extension) {
    $icons = [
        'jpg' => '🖼️',
        'jpeg' => '🖼️',
        'png' => '🖼️',
        'gif' => '🖼️',
        'mp4' => '🎬',
        'mov' => '🎬',
        'avi' => '🎬',
        'mp3' => '🎵',
        'wav' => '🎵',
        'pdf' => '📄',
        'doc' => '📝',
        'docx' => '📝',
        'xls' => '📊',
        'xlsx' => '📊',
        'zip' => '🗜️',
        'rar' => '🗜️',
        'url' => '🌐'
    ];
    
    return $icons[strtolower($extension)] ?? '📁';
}

// Helper function to get preview for image files
function getFilePreview($file) {
    $imageExtensions = ['jpg', 'jpeg', 'png', 'gif'];
    if (in_array(strtolower($file['file_extension']), $imageExtensions)) {
        return '<img src="uploads/' . $file['file_hash'] . '.' . $file['file_extension'] . '" alt="' . htmlspecialchars($file['filename']) . '">';
    }
    
    $videoExtensions = ['mp4', 'mov', 'avi'];
    if (in_array(strtolower($file['file_extension']), $videoExtensions)) {
        return '🎬 Vídeo';
    }
    
    $audioExtensions = ['mp3', 'wav'];
    if (in_array(strtolower($file['file_extension']), $audioExtensions)) {
        return '🎵 Áudio';
    }
    
    if (strtolower($file['file_extension']) === 'url') {
        return '🌐 Link';
    }
    
    return getFileIcon($file['file_extension']) . ' ' . strtoupper($file['file_extension']);
}

// Helper function to build pagination query string
function buildQueryString($page, $searchTerm, $extensionFilter) {
    $params = [];
    if (!empty($searchTerm)) {
        $params[] = 'search=' . urlencode($searchTerm);
    }
    if ($extensionFilter != 'all') {
        $params[] = 'extension=' . urlencode($extensionFilter);
    }
    $params[] = 'page=' . $page;
    return implode('&', $params);
}
?>