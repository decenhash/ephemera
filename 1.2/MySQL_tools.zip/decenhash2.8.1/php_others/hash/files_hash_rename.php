<?php
// Directory where the files are located
$directory = 'files/';

// Check if the directory exists
if (!is_dir($directory)) {
    die("Directory '{$directory}' does not exist.");
}

// Get all files in the directory (excluding . and ..)
$files = array_diff(scandir($directory), array('.', '..'));

// Process each file
foreach ($files as $filename) {
    $filepath = $directory . $filename;
    
    // Skip directories (only process files)
    if (is_dir($filepath)) {
        continue;
    }
    
    // Calculate SHA256 hash of the file contents
    $filehash = hash_file('sha256', $filepath);
    
    // Get the original file extension
    $extension = pathinfo($filename, PATHINFO_EXTENSION);
    
    // Create new filename (hash + original extension)
    $newFilename = $filehash . ($extension ? '.' . $extension : '');
    $newFilepath = $directory . $newFilename;
    
    // Skip if the file is already named correctly
    if ($filename === $newFilename) {
        echo "Skipping: {$filename} (already correctly named)\n";
        continue;
    }
    
    // Check if a file with the new name already exists
    if (file_exists($newFilepath)) {
        echo "Warning: {$newFilename} already exists. Skipping {$filename}\n";
        continue;
    }
    
    // Rename the file
    if (rename($filepath, $newFilepath)) {
        echo "Renamed: {$filename} => {$newFilename}\n";
    } else {
        echo "Error: Failed to rename {$filename}\n";
    }
}

echo "File renaming process completed.\n";
?>