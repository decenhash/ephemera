<?php
// Set the directory to the root directory
$directory = '.';
$files = [];

// Scan the directory and get the list of files
if (is_dir($directory)) {
    $files = scandir($directory);
}

// Filter out the current and parent directory entries
$files = array_diff($files, ['.', '..']);

// Start building the HTML content
$htmlContent = '<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>File List</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            padding: 20px;
        }
        h1 {
            text-align: center;
        }
        ul {
            list-style-type: none;
            padding: 0;
        }
        li {
            margin: 10px 0;
        }
        a {
            text-decoration: none;
            color: #333;
        }
        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <h1>List of Files</h1>
    <ul>';

// Loop through the files and create list items with links
foreach ($files as $file) {
    $htmlContent .= '<li><a href="' . htmlspecialchars($file) . '" target="_blank">' . htmlspecialchars($file) . '</a></li>';
}

$htmlContent .= '
    </ul>
</body>
</html>';

// Save the content to index.html
file_put_contents('index.html', $htmlContent);

echo 'index.html has been created with the list of files.';
?>
