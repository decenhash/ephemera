import java.io.File;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ServerFileProcessor {
    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        try {
            // Get the list of files from the servers directory
            List<String> serversList = listFilesAndGetContents("servers");
            System.out.println("Found " + serversList.size() + " server files in directory.");
            
            while (true) {
                // Get user input
                System.out.print("Enter filename with extension (or press Enter to exit): ");
                String userInput = scanner.nextLine();
                
                // Exit condition: user presses Enter without input
                if (userInput.trim().isEmpty()) {
                    System.out.println("Exiting program. Goodbye!");
                    break;
                }
                
                // Split the input by '.'
                String[] inputParts = userInput.split("\\.");
                if (inputParts.length < 2) {
                    System.out.println("Invalid input. Please provide a filename with extension (e.g., example.txt)");
                    continue;
                }
                
                String firstPart = inputParts[0];
                boolean fileFound = false;
                
                // Process each server in the list
                for (String serverContent : serversList) {
                    // Each line in the file content is treated as a server address
                    for (String serverAddress : serverContent.split("\n")) {
                        serverAddress = serverAddress.trim();
                        if (serverAddress.isEmpty()) continue;
                        
                        // Create the URL structure
                        String urlString = serverAddress + "/data/" + firstPart + "/" + userInput;
                        System.out.println("Trying to connect to: " + urlString);
                        
                        // Try to connect to the URL
                        if (checkUrlExists(urlString)) {
                            fileFound = true;
                            System.out.println("? Connection successful!");
                            
                            // Download the file and calculate its SHA-256 hash
                            String fileHash = calculateSHA256(urlString);
                            
                            // Check if the hash equals the first part of the filename
                            if (fileHash.equals(firstPart)) {
                                System.out.println("? Hash verification successful!");
                                System.out.println("  SHA-256: " + fileHash);
                            } else {
                                System.out.println("? Hash verification failed!");
                                System.out.println("  Expected: " + firstPart);
                                System.out.println("  Actual: " + fileHash);
                            }
                        } else {
                            System.out.println("? Connection failed!");
                        }
                    }
                }
                
                if (!fileFound) {
                    System.out.println("\nFile not found on any server.");
                }
                
                System.out.println(); // Empty line for better readability
            }
            
        } catch (IOException | NoSuchAlgorithmException e) {
            System.err.println("Error: " + e.getMessage());
            e.printStackTrace();
        } finally {
            scanner.close();
        }
    }
    
    /**
     * Lists all files in the given directory and returns their contents as a list of strings
     */
    private static List<String> listFilesAndGetContents(String directoryPath) throws IOException {
        List<String> contents = new ArrayList<>();
        File directory = new File(directoryPath);
        
        if (!directory.exists() || !directory.isDirectory()) {
            System.err.println("Directory '" + directoryPath + "' does not exist or is not a directory");
            return contents;
        }
        
        File[] files = directory.listFiles();
        if (files != null) {
            for (File file : files) {
                if (file.isFile()) {
                    String content = new String(Files.readAllBytes(Paths.get(file.getPath())));
                    contents.add(content);
                    System.out.println("Loaded server file: " + file.getName());
                }
            }
        }
        
        return contents;
    }
    
    /**
     * Checks if a URL exists by establishing a connection
     */
    private static boolean checkUrlExists(String urlString) {
        try {
            URL url = new URL(urlString);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("HEAD");
            connection.setConnectTimeout(5000);
            connection.setReadTimeout(5000);
            int responseCode = connection.getResponseCode();
            return (responseCode == HttpURLConnection.HTTP_OK);
        } catch (IOException e) {
            return false;
        }
    }
    
    /**
     * Calculates the SHA-256 hash of a file downloaded from a URL
     */
    private static String calculateSHA256(String urlString) throws IOException, NoSuchAlgorithmException {
        URL url = new URL(urlString);
        byte[] fileBytes = url.openStream().readAllBytes();
        
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        byte[] hashBytes = digest.digest(fileBytes);
        
        // Convert bytes to hex string
        StringBuilder hexString = new StringBuilder();
        for (byte b : hashBytes) {
            String hex = Integer.toHexString(0xff & b);
            if (hex.length() == 1) hexString.append('0');
            hexString.append(hex);
        }
        
        return hexString.toString();
    }
}