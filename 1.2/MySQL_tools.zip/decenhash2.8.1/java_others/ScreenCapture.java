import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.ImageIO;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import javax.imageio.IIOImage;
import javax.imageio.ImageWriteParam;
import javax.imageio.ImageWriter;
import javax.imageio.stream.FileImageOutputStream;

public class ScreenCapture {
    // Date formatter for filename
    private static final SimpleDateFormat FORMATTER = new SimpleDateFormat("yyyyMMdd_HHmmss");
    // Output directory
    private static final String OUTPUT_DIR = "screenshots";
    // Screenshot interval in milliseconds
    private static final int INTERVAL = 10000;
    
    public void captureScreen() throws Exception {
        // Create output directory if it doesn't exist
        File outputDir = new File(OUTPUT_DIR);
        if (!outputDir.exists()) {
            outputDir.mkdirs();
        }
        
        // Get current time for filename
        Calendar now = Calendar.getInstance();
        String timestamp = FORMATTER.format(now.getTime());
        
        // Capture screen
        Robot robot = new Robot();
        BufferedImage screenShot = robot.createScreenCapture(
            new Rectangle(Toolkit.getDefaultToolkit().getScreenSize())
        );
        
        // Create output file
        File outputFile = new File(outputDir, timestamp + ".png");
        
        // Save as high-quality PNG (PNG is lossless so we don't need to set compression)
        ImageIO.write(screenShot, "PNG", outputFile);
        
        System.out.println("Screenshot saved: " + outputFile.getAbsolutePath());
    }
    
    public static void main(String[] args) {
        ScreenCapture screenCapture = new ScreenCapture();
        
        System.out.println("Starting screen capture program...");
        System.out.println("Saving screenshots to: " + new File(OUTPUT_DIR).getAbsolutePath());
        System.out.println("Interval: " + (INTERVAL / 1000) + " seconds");
        
        try {
            while (true) {
                screenCapture.captureScreen();
                Thread.sleep(INTERVAL);
            }
        } catch (Exception e) {
            System.err.println("Error capturing screen: " + e.getMessage());
            e.printStackTrace();
        }
    }
}