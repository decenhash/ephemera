import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import javax.imageio.ImageIO;

public class ImageSquareShuffler {
    private static final int SQUARE_SIZE = 20;
    private static final String INPUT_DIR = "img_square";

    public static void main(String[] args) {
        File directory = new File(INPUT_DIR);
        
        if (!directory.exists() || !directory.isDirectory()) {
            System.err.println("Directory '" + INPUT_DIR + "' does not exist or is not a directory");
            return;
        }

        File[] imageFiles = directory.listFiles((dir, name) -> {
            String lowercaseName = name.toLowerCase();
            return lowercaseName.endsWith(".jpg") || lowercaseName.endsWith(".jpeg") || 
                   lowercaseName.endsWith(".png") || lowercaseName.endsWith(".bmp") || 
                   lowercaseName.endsWith(".gif");
        });

        if (imageFiles == null || imageFiles.length == 0) {
            System.out.println("No image files found in directory: " + INPUT_DIR);
            return;
        }

        System.out.println("Found " + imageFiles.length + " image(s) to process");

        for (File imageFile : imageFiles) {
            try {
                processImage(imageFile);
                System.out.println("Successfully processed: " + imageFile.getName());
            } catch (IOException e) {
                System.err.println("Error processing image " + imageFile.getName() + ": " + e.getMessage());
            }
        }
        
        System.out.println("All images have been processed");
    }

    private static void processImage(File inputFile) throws IOException {
        // Read the original image
        BufferedImage originalImage = ImageIO.read(inputFile);
        
        // Calculate grid dimensions
        int rows = originalImage.getHeight() / SQUARE_SIZE;
        int cols = originalImage.getWidth() / SQUARE_SIZE;
        
        // Adjust if the image dimensions are not multiples of SQUARE_SIZE
        int adjustedHeight = rows * SQUARE_SIZE;
        int adjustedWidth = cols * SQUARE_SIZE;
        
        // Create a list to store all squares
        List<ImageSquare> squares = new ArrayList<>();
        
        // Extract squares from the original image
        for (int y = 0; y < rows; y++) {
            for (int x = 0; x < cols; x++) {
                int posX = x * SQUARE_SIZE;
                int posY = y * SQUARE_SIZE;
                
                // Extract the square from the original image
                BufferedImage squareImage = originalImage.getSubimage(posX, posY, SQUARE_SIZE, SQUARE_SIZE);
                squares.add(new ImageSquare(squareImage, posX, posY));
            }
        }
        
        // Shuffle the squares
        Collections.shuffle(squares);
        
        // Create a new image with the same dimensions
        BufferedImage shuffledImage = new BufferedImage(adjustedWidth, adjustedHeight, originalImage.getType());
        Graphics2D g2d = shuffledImage.createGraphics();
        
        // Redraw the squares in the shuffled order
        int index = 0;
        for (int y = 0; y < rows; y++) {
            for (int x = 0; x < cols; x++) {
                int posX = x * SQUARE_SIZE;
                int posY = y * SQUARE_SIZE;
                
                ImageSquare square = squares.get(index++);
                g2d.drawImage(square.getImage(), posX, posY, null);
            }
        }
        
        g2d.dispose();
        
        // Generate the output filename
        String originalName = inputFile.getName();
        String baseName = originalName.substring(0, originalName.lastIndexOf('.'));
        String extension = originalName.substring(originalName.lastIndexOf('.'));
        String outputName = baseName + "_shuffled" + extension;
        
        // Save the shuffled image
        File outputFile = new File(INPUT_DIR, outputName);
        String formatName = extension.substring(1); // Remove the dot
        ImageIO.write(shuffledImage, formatName, outputFile);
    }
    
    // Helper class to store image square and its original position
    private static class ImageSquare {
        private final BufferedImage image;
        private final int originalX;
        private final int originalY;
        
        public ImageSquare(BufferedImage image, int originalX, int originalY) {
            this.image = image;
            this.originalX = originalX;
            this.originalY = originalY;
        }
        
        public BufferedImage getImage() {
            return image;
        }
        
        public int getOriginalX() {
            return originalX;
        }
        
        public int getOriginalY() {
            return originalY;
        }
    }
}