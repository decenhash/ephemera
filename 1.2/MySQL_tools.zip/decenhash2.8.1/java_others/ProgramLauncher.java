import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

public class ProgramLauncher extends JFrame {
    
    // Define the background color as a constant
    private static final Color BACKGROUND_COLOR = new Color(30, 144, 255); // Dodger Blue

    public ProgramLauncher() {
        // Set up the main window
        setTitle("DecenHash Launcher");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        
        // Use a modern look and feel
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Create main container with BorderLayout
        JPanel container = new JPanel(new BorderLayout());
        container.setBackground(BACKGROUND_COLOR);
        
        // Add header with "DecenHash" in big white font
        JLabel header = new JLabel("DecenHash", SwingConstants.CENTER);
        header.setFont(new Font("Segoe UI", Font.BOLD, 48));
        header.setForeground(Color.WHITE);
        header.setBorder(BorderFactory.createEmptyBorder(20, 0, 30, 0));
        container.add(header, BorderLayout.NORTH);
        
        // Create the button panel
        JPanel buttonPanel = new JPanel();
        buttonPanel.setBackground(BACKGROUND_COLOR);
        buttonPanel.setLayout(new GridLayout(6, 1, 10, 10)); // 6 rows, 1 column
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(0, 20, 0, 20));

        // Create and add buttons
        String[] programs = {"server.java", "hello.java", "calculator.java", 
                            "database.java", "Core.java", "ScreenCapture.java"};
        
        for (String program : programs) {
            JButton button = createModernButton(program);
            button.addActionListener(new LaunchProgramAction(program));
            buttonPanel.add(button);
        }

        container.add(buttonPanel, BorderLayout.CENTER);
        
        // Add footer with "all rights reserved"
        JLabel footer = new JLabel("all rights reserved", SwingConstants.CENTER);
        footer.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        footer.setForeground(Color.WHITE);
        footer.setBorder(BorderFactory.createEmptyBorder(20, 0, 10, 0));
        container.add(footer, BorderLayout.SOUTH);

        // Add the container to the frame
        add(container);
    }

    private JButton createModernButton(String text) {
        JButton button = new JButton("Launch " + text);
        button.setFont(new Font("Segoe UI", Font.BOLD, 16));
        button.setForeground(BACKGROUND_COLOR); // Text color matches window background
        button.setBackground(Color.WHITE); // White button background
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        // Hover effect
        button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(new Color(240, 240, 240)); // Light gray on hover
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(Color.WHITE); // Back to white
            }
        });
        
        return button;
    }

    private class LaunchProgramAction implements ActionListener {
        private String programName;
        
        public LaunchProgramAction(String programName) {
            this.programName = programName;
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                // Launch the Java program using Runtime
                String command = "java " + programName.replace(".java", "");
                Process process = Runtime.getRuntime().exec(command);
                
                // For demonstration, we'll just show a message
                JOptionPane.showMessageDialog(ProgramLauncher.this,
                        "Launching: " + programName,
                        "Program Launcher",
                        JOptionPane.INFORMATION_MESSAGE);
                
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(ProgramLauncher.this,
                        "Error launching " + programName + ": " + ex.getMessage(),
                        "Error",
                        JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            ProgramLauncher launcher = new ProgramLauncher();
            launcher.setVisible(true);
        });
    }
}