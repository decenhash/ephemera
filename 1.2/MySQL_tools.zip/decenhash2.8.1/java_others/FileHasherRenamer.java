import java.io.*;
import java.nio.file.*;
import java.security.*;
import java.util.*;

public class FileHasherRenamer {
    
    public static void main(String[] args) {
        String rootFolder = "data";
        File dataFolder = new File(rootFolder);
        
        if (!dataFolder.exists() || !dataFolder.isDirectory()) {
            System.err.println("The 'data' folder does not exist or is not a directory.");
            return;
        }
        
        try {
            List<File> allFiles = listAllFiles(dataFolder);
            System.out.println("Found " + allFiles.size() + " files to process:");
            
            for (File file : allFiles) {
                String originalPath = file.getAbsolutePath();
                String hash = calculateSHA256(file);
                String extension = getFileExtension(file.getName());
                String newName = hash + (extension.isEmpty() ? "" : "." + extension);
                
                Path source = file.toPath();
                Path target = source.resolveSibling(newName);
                
                System.out.println("Renaming: " + originalPath + " to " + target);
                
                try {
                    Files.move(source, target, StandardCopyOption.REPLACE_EXISTING);
                } catch (IOException e) {
                    System.err.println("Error renaming file: " + originalPath);
                    e.printStackTrace();
                }
            }
            
            System.out.println("File renaming completed.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    private static List<File> listAllFiles(File directory) {
        List<File> fileList = new ArrayList<>();
        if (directory == null || !directory.exists()) {
            return fileList;
        }
        
        File[] files = directory.listFiles();
        if (files != null) {
            for (File file : files) {
                if (file.isDirectory()) {
                    fileList.addAll(listAllFiles(file));
                } else {
                    fileList.add(file);
                }
            }
        }
        return fileList;
    }
    
    private static String calculateSHA256(File file) throws NoSuchAlgorithmException, IOException {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        try (InputStream is = new FileInputStream(file)) {
            byte[] buffer = new byte[8192];
            int read;
            while ((read = is.read(buffer)) > 0) {
                digest.update(buffer, 0, read);
            }
        }
        byte[] hashBytes = digest.digest();
        
        // Convert byte array to hex string
        StringBuilder hexString = new StringBuilder();
        for (byte b : hashBytes) {
            String hex = Integer.toHexString(0xff & b);
            if (hex.length() == 1) {
                hexString.append('0');
            }
            hexString.append(hex);
        }
        
        return hexString.toString();
    }
    
    private static String getFileExtension(String filename) {
        int dotIndex = filename.lastIndexOf('.');
        if (dotIndex > 0 && dotIndex < filename.length() - 1) {
            return filename.substring(dotIndex + 1);
        }
        return "";
    }
}