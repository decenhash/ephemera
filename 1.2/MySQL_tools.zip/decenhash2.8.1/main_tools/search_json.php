﻿<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>JSON File Search</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            color: #333;
            margin: 0;
            padding: 20px;
        }

        .container {
            max-width: 800px;
            margin: auto;
            background: #fff;
            padding: 20px 30px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h1 {
            color: #444;
            text-align: center;
        }

        form {
            text-align: center;
            margin-bottom: 20px;
        }

        input[type="text"] {
            padding: 10px;
            width: 70%;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 16px;
        }

        input[type="submit"] {
            padding: 10px 20px;
            background-color: #5cb85c;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }

        input[type="submit"]:hover {
            background-color: #4cae4c;
        }

        ul {
            list-style: none;
            padding: 0;
        }

        li {
            padding: 10px;
            border-bottom: 1px solid #eee;
        }

        li:last-child {
            border-bottom: none;
        }

        a {
            text-decoration: none;
            color: #007bff;
            font-size: 18px;
        }

        a:hover {
            text-decoration: underline;
        }

        .no-results {
            text-align: center;
            color: #777;
        }

        .dir-info {
            text-align: center;
            font-style: italic;
            color: #999;
            margin-bottom: 15px;
        }
    </style>
</head>
<body>

<div class="container">
    <h1>🔍 JSON File Search</h1>
    <p class="dir-info">Searching for JSON files in the 'JSON' directory.</p>
    <form method="GET" action="">
        <input type="text" name="search" placeholder="Enter keyword to search..." value="<?php echo htmlspecialchars($_GET['search'] ?? ''); ?>">
        <input type="submit" value="Search">
    </form>

    <hr>

    <?php
    $directory = 'JSON';
    $results = [];

    // Ensure the JSON directory exists
    if (!is_dir($directory)) {
        echo "<p>Error: The 'JSON' directory does not exist.</p>";
    } else {
        // Check if a search query was provided
        $searchQuery = $_GET['search'] ?? '';

        // Get all files from the 'JSON' directory
        $files = glob($directory . '/*.json');

        if (!empty($files)) {
            echo "<ul>";
            foreach ($files as $file) {
                // Read the file content
                $content = file_get_contents($file);

                // If no search query, or the content matches the query, add to results
                if ($searchQuery === '' || stripos($content, $searchQuery) !== false) {
                    $fileName = basename($file);
                    echo "<li><a href='{$file}'>{$fileName}</a></li>";
                    $results[] = $fileName;
                }
            }
            echo "</ul>";
        }

        // Show a message if no files matched the search
        if (empty($results) && !empty($searchQuery)) {
            echo "<p class='no-results'>No files found matching '<strong>" . htmlspecialchars($searchQuery) . "</strong>'.</p>";
        } elseif (empty($files)) {
            echo "<p class='no-results'>The 'JSON' directory is empty or contains no JSON files.</p>";
        }
    }
    ?>
</div>

</body>
</html>