<?php session_start(); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Upload</title>
 
    <style>
        body {
            font-family: 'Inter', sans-serif;
            padding: 5px 0px 5px 50px;
        }

    </style>
</head>
<body>

<h1>Decenhash</h1>
<hr>
<div>
<a href="upload.php"">Simple upload</a><br>
<a href="index_search.html">JSON </a><br>
<a href="index_simple.php">HTML </a><br>
<a href="php_others/upload/index.php">MySQL</a>/ <a href="db.php">Graph</a><br>
<a href="metadata.php">Add metadata</a><br>
<a href="server.php">Add server information</a><br>
</div>
<br>
<i>Notice: Create the database (DB) "decenhash" to use the MySQL scripts.</i>
</body>
</html>
