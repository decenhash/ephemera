<?php
// --- PHP Backend Logic ---

// This block handles the AJAX request from the JavaScript form.
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Set the content type to JSON for the response.
    header('Content-Type: application/json');

    // Get the raw POST data sent from the fetch request.
    $input = json_decode(file_get_contents('php://input'), true);

    // Basic validation to ensure data and filename are present.
    if (!isset($input['filename']) || !isset($input['data']) || empty($input['filename'])) {
        echo json_encode(['status' => 'error', 'message' => 'Invalid data received.']);
        exit;
    }

    $filename = $input['filename'];
    $data = $input['data'];
    $jsonDir = 'JSON';

    // Sanitize filename to be safe, although JS validation should handle it.
    // This allows only letters, numbers, and underscores.
    if (preg_match('/[^A-Za-z0-9_]/', $filename)) {
        echo json_encode(['status' => 'error', 'message' => 'Invalid filename characters. Only letters, numbers, and underscores are allowed.']);
        exit;
    }

    // Create the 'JSON' directory if it doesn't exist.
    if (!is_dir($jsonDir)) {
        if (!mkdir($jsonDir, 0755, true)) {
            echo json_encode(['status' => 'error', 'message' => 'Failed to create JSON directory.']);
            exit;
        }
    }

    $filePath = $jsonDir . '/' . $filename . '.json';

    // Check if the file already exists.
    if (file_exists($filePath)) {
        echo json_encode(['status' => 'error', 'message' => 'File "' . htmlspecialchars($filename) . '.json" already exists.']);
    } else {
        // Save the data to the file with pretty printing for readability.
        if (file_put_contents($filePath, json_encode($data, JSON_PRETTY_PRINT))) {
            echo json_encode(['status' => 'success', 'message' => 'File saved successfully as "' . htmlspecialchars($filename) . '.json".']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Failed to save the file.']);
        }
    }

    // Stop script execution to prevent the HTML below from being sent with the AJAX response.
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dynamic JSON Creator</title>
    <!-- --- CSS Styling --- -->
    <style>
        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
            background-color: #f0f2f5;
            color: #1c1e21;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin: 0;
            padding: 20px;
            box-sizing: border-box;
        }

        .container {
            background-color: #ffffff;
            padding: 2rem;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 600px;
        }

        h1 {
            text-align: center;
            color: #333;
            margin-bottom: 1.5rem;
        }

        .field-group {
            display: flex;
            align-items: center;
            margin-bottom: 1rem;
            gap: 10px;
        }

        .field-name {
            font-weight: 500;
            padding: 8px 12px;
            border: 1px solid #ddd;
            border-radius: 6px;
            min-width: 80px;
            text-align: center;
            cursor: text;
            background-color: #f7f7f7;
            transition: background-color 0.2s, border-color 0.2s;
        }

        .field-name:focus {
            outline: none;
            border-color: #007bff;
            background-color: #fff;
        }

        .field-value {
            flex-grow: 1;
            padding: 8px 12px;
            border: 1px solid #ddd;
            border-radius: 6px;
            font-size: 1rem;
            transition: border-color 0.2s;
        }

        .field-value:focus {
            outline: none;
            border-color: #007bff;
        }

        .delete-btn {
            background-color: #ff4d4d;
            color: white;
            border: none;
            width: 32px;
            height: 32px;
            border-radius: 50%;
            font-weight: bold;
            font-size: 1rem;
            cursor: pointer;
            display: flex;
            justify-content: center;
            align-items: center;
            transition: background-color 0.2s;
        }

        .delete-btn:hover {
            background-color: #e60000;
        }

        .controls, .save-options {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            margin-top: 1.5rem;
            align-items: center;
        }

        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 6px;
            font-size: 1rem;
            font-weight: 500;
            cursor: pointer;
            transition: background-color 0.2s, box-shadow 0.2s;
        }

        .btn-primary {
            background-color: #007bff;
            color: white;
            flex-grow: 1;
        }

        .btn-primary:hover {
            background-color: #0056b3;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }

        .btn-secondary {
            background-color: #6c757d;
            color: white;
        }

        .btn-secondary:hover {
            background-color: #5a6268;
        }
        
        #filenameInput {
            flex-grow: 1;
            padding: 8px 12px;
            border: 1px solid #ddd;
            border-radius: 6px;
        }

        #message {
            margin-top: 1.5rem;
            padding: 12px;
            border-radius: 6px;
            text-align: center;
            font-weight: 500;
            display: none; /* Hidden by default */
        }

        .message-success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .message-error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
    </style>
</head>
<body>

    <div class="container">
        <h1>Dynamic JSON Creator</h1>
        <form id="jsonForm">
            <div id="fieldsContainer">
                <!-- Initial fields will be added here by JavaScript -->
            </div>
            <div class="controls">
                <button type="button" id="addFieldBtn" class="btn btn-secondary">Add New Field</button>
                <button type="submit" class="btn btn-primary">Save JSON File</button>
            </div>
            <div class="save-options">
                <input type="text" id="filenameInput" placeholder="Enter filename (e.g., my_data)" required>
                <label>
                    <input type="checkbox" id="useHashCheck"> Use SHA256 Hash
                </label>
            </div>
        </form>
        <div id="message"></div>
    </div>

    <!-- --- JavaScript Logic --- -->
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const fieldsContainer = document.getElementById('fieldsContainer');
            const addFieldBtn = document.getElementById('addFieldBtn');
            const jsonForm = document.getElementById('jsonForm');
            const filenameInput = document.getElementById('filenameInput');
            const useHashCheck = document.getElementById('useHashCheck');
            const messageDiv = document.getElementById('message');

            const initialFields = ['title', 'description', 'url', 'btc', 'user'];

            // Function to create a new field group
            const createField = (name = 'new_field', value = '') => {
                const fieldGroup = document.createElement('div');
                fieldGroup.className = 'field-group';

                const fieldName = document.createElement('span');
                fieldName.className = 'field-name';
                fieldName.setAttribute('contenteditable', 'true');
                fieldName.textContent = name;

                const fieldValue = document.createElement('input');
                fieldValue.className = 'field-value';
                fieldValue.type = 'text';
                fieldValue.value = value;
                fieldValue.placeholder = 'Enter value...';

                const deleteBtn = document.createElement('button');
                deleteBtn.className = 'delete-btn';
                deleteBtn.type = 'button';
                deleteBtn.textContent = '�';
                deleteBtn.title = 'Delete field';

                deleteBtn.addEventListener('click', () => {
                    fieldGroup.remove();
                });

                fieldGroup.append(fieldName, fieldValue, deleteBtn);
                fieldsContainer.appendChild(fieldGroup);
            };

            // Create the initial fields on page load
            initialFields.forEach(fieldName => createField(fieldName));

            // Event listener for the "Add Field" button
            addFieldBtn.addEventListener('click', () => createField());

            // Disable/enable filename input based on checkbox
            useHashCheck.addEventListener('change', () => {
                filenameInput.disabled = useHashCheck.checked;
                if (useHashCheck.checked) {
                    filenameInput.value = '';
                    filenameInput.required = false;
                } else {
                    filenameInput.required = true;
                }
            });

            // Handle form submission
            jsonForm.addEventListener('submit', async (e) => {
                e.preventDefault();
                messageDiv.style.display = 'none';
                messageDiv.className = '';

                const data = {};
                const fields = fieldsContainer.querySelectorAll('.field-group');
                let hasError = false;

                fields.forEach(field => {
                    const key = field.querySelector('.field-name').textContent.trim();
                    const value = field.querySelector('.field-value').value;
                    if (key) {
                        data[key] = value;
                    } else {
                        showMessage('error', 'Field names cannot be empty.');
                        hasError = true;
                    }
                });

                if (hasError) return;

                let filename = '';

                if (useHashCheck.checked) {
                    // Calculate SHA256 hash
                    const jsonString = JSON.stringify(data);
                    const encoder = new TextEncoder();
                    const dataBuffer = encoder.encode(jsonString);
                    const hashBuffer = await crypto.subtle.digest('SHA-256', dataBuffer);
                    const hashArray = Array.from(new Uint8Array(hashBuffer));
                    filename = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
                } else {
                    // Use user-provided filename
                    filename = filenameInput.value.trim();
                    if (!/^[a-zA-Z0-9_]+$/.test(filename)) {
                        showMessage('error', 'Invalid filename. Use only letters, numbers, and underscores.');
                        return;
                    }
                }

                if (!filename) {
                    showMessage('error', 'Filename is required.');
                    return;
                }
                
                // Send data to the PHP backend
                try {
                    const response = await fetch('<?php echo basename($_SERVER["PHP_SELF"]); ?>', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify({ filename, data })
                    });

                    if (!response.ok) {
                        throw new Error(`HTTP error! status: ${response.status}`);
                    }

                    const result = await response.json();
                    showMessage(result.status, result.message);

                } catch (error) {
                    console.error('Error:', error);
                    showMessage('error', 'An unexpected error occurred.');
                }
            });
            
            // Helper function to display status messages
            function showMessage(type, text) {
                messageDiv.textContent = text;
                messageDiv.className = type === 'success' ? 'message-success' : 'message-error';
                messageDiv.style.display = 'block';
            }
        });
    </script>

</body>
</html>
