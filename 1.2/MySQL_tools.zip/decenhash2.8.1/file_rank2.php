<?php
$host = 'localhost';
$dbname = 'decenhash';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Function to get top depositors for a specific filehash
function getTopDepositorsByHash($pdo, $filehash, $limit = 100) {
    $query = "
        SELECT 
            u.username,
            u.id,
            SUM(h.deposit) as total_deposit,
            COUNT(h.id) as transaction_count
        FROM hashstock h
        JOIN users u ON h.user_id = u.id
        WHERE h.filehash = :filehash
        GROUP BY u.id, u.username
        ORDER BY total_deposit DESC
        LIMIT :limit
    ";
    
    $stmt = $pdo->prepare($query);
    $stmt->bindValue(':filehash', $filehash, PDO::PARAM_STR);
    $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
    $stmt->execute();
    
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Function to get total deposits for a specific filehash
function getTotalDepositsByHash($pdo, $filehash) {
    $query = "
        SELECT COALESCE(SUM(deposit), 0) as total_deposits
        FROM hashstock
        WHERE filehash = :filehash
    ";
    
    $stmt = $pdo->prepare($query);
    $stmt->bindValue(':filehash', $filehash, PDO::PARAM_STR);
    $stmt->execute();
    
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    return $result['total_deposits'];
}

// Function to check if hash exists
function hashExists($pdo, $filehash) {
    $query = "SELECT COUNT(*) as count FROM hashstock WHERE filehash = :filehash";
    $stmt = $pdo->prepare($query);
    $stmt->bindValue(':filehash', $filehash, PDO::PARAM_STR);
    $stmt->execute();
    
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    return $result['count'] > 0;
}

// Process form submission
$results = [];
$totalDeposits = 0;
$error = '';
$filehash = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $filehash = trim($_POST['filehash']);
    
    if (empty($filehash)) {
        $error = 'Please enter a file hash';
    } elseif (!hashExists($pdo, $filehash)) {
        $error = 'No transactions found for this file hash';
    } else {
        $results = getTopDepositorsByHash($pdo, $filehash);
        $totalDeposits = getTotalDepositsByHash($pdo, $filehash);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hash Deposit Analysis</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
            background-color: #f5f5f5;
        }
        .container {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        h1 {
            color: #333;
            text-align: center;
            margin-bottom: 30px;
        }
        .form-group {
            margin-bottom: 20px;
        }
        input[type="text"] {
            width: 100%;
            padding: 12px;
            border: 2px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
            box-sizing: border-box;
        }
        button {
            background: #007bff;
            color: white;
            padding: 12px 24px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }
        button:hover {
            background: #0056b3;
        }
        .error {
            color: #dc3545;
            background: #f8d7da;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 20px;
        }
        .results {
            margin-top: 30px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #f8f9fa;
            font-weight: bold;
        }
        tr:hover {
            background-color: #f8f9fa;
        }
        .percentage {
            font-weight: bold;
            color: #28a745;
        }
        .total-info {
            background: #e9ecef;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Hash Deposit Analysis</h1>
        
        <form method="POST">
            <div class="form-group">
                <input type="text" name="filehash" placeholder="Enter file hash" value="<?= htmlspecialchars($filehash) ?>" required>
            </div>
            <button type="submit">Analyze Hash</button>
        </form>

        <?php if ($error): ?>
            <div class="error"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <?php if (!empty($results)): ?>
            <div class="results">
                <div class="total-info">
                    <strong>Total deposits for hash "<?= htmlspecialchars($filehash) ?>":</strong> 
                    $<?= number_format($totalDeposits, 2) ?>
                </div>

                <h2>Top Depositors (Max 100)</h2>
                <table>
                    <thead>
                        <tr>
                            <th>Rank</th>
                            <th>Username</th>
                            <th>User ID</th>
                            <th>Total Deposit</th>
                            <th>Percentage</th>
                            <th>Transactions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($results as $index => $row): ?>
                            <?php 
                            $percentage = $totalDeposits > 0 ? ($row['total_deposit'] / $totalDeposits) * 100 : 0;
                            ?>
                            <tr>
                                <td><?= $index + 1 ?></td>
                                <td><?= htmlspecialchars($row['username']) ?></td>
                                <td><?= $row['id'] ?></td>
                                <td>$<?= number_format($row['total_deposit'], 2) ?></td>
                                <td class="percentage"><?= number_format($percentage, 2) ?>%</td>
                                <td><?= $row['transaction_count'] ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>