<?php
/*
 * -------------------------------------------------------------------------
 * Database Connection Configuration
 * -------------------------------------------------------------------------
 *
 * Please update these settings with your actual MySQL database credentials.
 * This file is included by other PHP scripts to establish a database
 * connection, so you only need to change the details here.
 *
 */

// Database host (e.g., "localhost" or "127.0.0.1")
define('DB_SERVER', 'localhost');

// Your database username
define('DB_USERNAME', 'root');

// Your database password
define('DB_PASSWORD', '');

// The name of the database you want to use
define('DB_NAME', 'decenhash');

/*
 * -------------------------------------------------------------------------
 * Establish Database Connection
 * -------------------------------------------------------------------------
 *
 * The following code attempts to connect to the MySQL database using the
 * credentials defined above. It uses the MySQLi extension.
 * If the connection fails, it will terminate the script and display an
 * error message.
 *
 */
$mysqli = new mysqli(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);

// Check for connection errors
if ($mysqli->connect_errno) {
    // Using die() will exit the script and display the error.
    // In a production environment, you might want to handle this more gracefully.
    die("ERROR: Could not connect to the database. " . $mysqli->connect_error);
}
?>
