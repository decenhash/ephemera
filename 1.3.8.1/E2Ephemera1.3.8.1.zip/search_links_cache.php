﻿<?php
// Minimalist Search Tool with Caching
$serversFile = 'servers.txt';
$cacheDir = 'cache/';
$cacheTime = 3600; // Cache duration in seconds (1 hour)
$query = isset($_GET['q']) ? trim($_GET['q']) : '';
$results = [];

// Create cache directory if it doesn't exist
if (!is_dir($cacheDir)) { mkdir($cacheDir, 0777, true); }

if ($query && file_exists($serversFile)) {
    $servers = file($serversFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

    foreach ($servers as $server) {
        $server = rtrim($server, '/');
        $cacheFile = $cacheDir . md5($server) . '.txt';
        $content = [];

        // Check if cache exists and is fresh
        if (file_exists($cacheFile) && (time() - filemtime($cacheFile) < $cacheTime)) {
            $content = file($cacheFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        } else {
            // Fetch fresh data
            $remoteFileUrl = $server . '/files.txt';
            $remoteData = @file_get_contents($remoteFileUrl);
            if ($remoteData !== false) {
                file_put_contents($cacheFile, $remoteData);
                $content = explode("\n", str_replace("\r", "", $remoteData));
            }
        }
        
        // Search through the content (cached or fresh)
        foreach ($content as $line) {
            $line = trim($line);
            if ($line && stripos($line, $query) !== false) {
                $link = (filter_var($line, FILTER_VALIDATE_URL)) 
                        ? $line 
                        : $server . '/files/' . ltrim($line, '/');
                
                $results[] = ['text' => $line, 'url' => $link, 'source' => $server];
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>File Search Pro</title>
    <style>
        body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; line-height: 1.6; max-width: 600px; margin: 40px auto; padding: 20px; color: #333; background: #f9f9f9; }
        .search-container { display: flex; gap: 10px; margin-bottom: 30px; }
        input[type="text"] { flex: 1; padding: 12px; border: 1px solid #ccc; border-radius: 6px; font-size: 16px; }
        button { padding: 12px 24px; background: #007bff; color: white; border: none; border-radius: 6px; cursor: pointer; font-weight: bold; }
        button:hover { background: #0056b3; }
        .result-item { background: white; padding: 15px; margin-bottom: 12px; border-radius: 8px; border: 1px solid #eee; box-shadow: 0 2px 4px rgba(0,0,0,0.05); }
        .result-item a { color: #007bff; text-decoration: none; font-weight: 600; font-size: 1.1em; display: block; margin-bottom: 4px; }
        .result-item small { color: #888; }
        .no-results { text-align: center; color: #999; margin-top: 40px; }
    </style>
</head>
<body>

    <form method="GET" class="search-container">
        <input type="text" name="q" placeholder="Type to search..." value="<?= htmlspecialchars($query) ?>" required autofocus>
        <button type="submit">Search</button>
    </form>

    <?php if ($query): ?>
        <div id="results">
            <?php if (!empty($results)): ?>
                <?php foreach ($results as $res): ?>
                    <div class="result-item">
                        <a href="<?= htmlspecialchars($res['url']) ?>" target="_blank"><?= htmlspecialchars($res['text']) ?></a>
                        <small>📍 Source: <?= htmlspecialchars($res['source']) ?></small>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p class="no-results">No matches found for "<strong><?= htmlspecialchars($query) ?></strong>".</p>
            <?php endif; ?>
        </div>
    <?php endif; ?>

</body>
</html>