import javax.swing.*;
import javax.swing.text.DefaultCaret;
import java.awt.*;
import java.io.*;
import java.net.*;
import java.nio.file.*;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.*;

public class MediaCrawler extends JFrame {

    // --- Configuration Constants from Source [cite: 2, 3, 4, 5] ---
    private static final String DOWNLOAD_DIR = "files";
    private static final String LOG_DIR = "log";
    private static final Set<String> MEDIA_EXTENSIONS = new HashSet<>(Arrays.asList(
            "jpg", "jpeg", "png", "gif", "bmp", "webp", "mp4"
    ));
    private static final String USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/120.0.0.0 Safari/537.36";

    // --- GUI Components ---
    private JTextField urlField;
    private JTextField sigField;
    private JSpinner depthSpinner;
    private JCheckBox infiniteDepthBox;
    private JTextArea logArea;
    private JButton startButton;

    // --- State ---
    private volatile boolean isRunning = false;
    // Thread-safe set for visited URLs [cite: 3]
    private final Set<String> visitedUrls = ConcurrentHashMap.newKeySet();

    public MediaCrawler() {
        setTitle("Media Crawler GUI");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(700, 500);
        setLocationRelativeTo(null);
        initComponents();
    }

    private void initComponents() {
        JPanel inputPanel = new JPanel(new GridBagLayout());
        inputPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(5, 5, 5, 5);

        // Row 1: URL
        gbc.gridx = 0; gbc.gridy = 0;
        inputPanel.add(new JLabel("Starting URL:"), gbc);
        gbc.gridx = 1; gbc.weightx = 1.0;
        urlField = new JTextField("https://");
        inputPanel.add(urlField, gbc);

        // Row 2: Signature
        gbc.gridx = 0; gbc.gridy = 1; gbc.weightx = 0;
        inputPanel.add(new JLabel("Log Signature:"), gbc);
        gbc.gridx = 1; gbc.weightx = 1.0;
        sigField = new JTextField("User1");
        inputPanel.add(sigField, gbc);

        // Row 3: Depth Controls
        gbc.gridx = 0; gbc.gridy = 2; gbc.weightx = 0;
        inputPanel.add(new JLabel("Max Depth:"), gbc);
        
        JPanel depthPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        depthSpinner = new JSpinner(new SpinnerNumberModel(2, 0, 100, 1));
        infiniteDepthBox = new JCheckBox("Infinite");
        
        // Disable spinner if infinite is checked
        infiniteDepthBox.addActionListener(e -> depthSpinner.setEnabled(!infiniteDepthBox.isSelected()));

        depthPanel.add(depthSpinner);
        depthPanel.add(Box.createHorizontalStrut(10));
        depthPanel.add(infiniteDepthBox);
        
        gbc.gridx = 1; gbc.weightx = 1.0;
        inputPanel.add(depthPanel, gbc);

        // Row 4: Button
        gbc.gridx = 0; gbc.gridy = 3; gbc.gridwidth = 2;
        startButton = new JButton("Start Crawling");
        startButton.addActionListener(e -> startProcess());
        inputPanel.add(startButton, gbc);

        // Log Area
        logArea = new JTextArea();
        logArea.setEditable(false);
        logArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
        JScrollPane scrollPane = new JScrollPane(logArea);
        // Auto-scroll logic
        DefaultCaret caret = (DefaultCaret) logArea.getCaret();
        caret.setUpdatePolicy(DefaultCaret.ALWAYS_UPDATE);

        add(inputPanel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
    }

    private void log(String message) {
        SwingUtilities.invokeLater(() -> logArea.append(message + "\n"));
    }

    private void startProcess() {
        if (isRunning) return;

        String startUrl = urlField.getText().trim();
        String signature = sigField.getText().trim();
        boolean infinite = infiniteDepthBox.isSelected();
        int maxDepth = (Integer) depthSpinner.getValue();

        if (startUrl.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter a URL.");
            return;
        }

        isRunning = true;
        startButton.setEnabled(false);
        visitedUrls.clear();
        logArea.setText("");
        log("Initializing crawler...");

        // Run crawler in background thread to avoid freezing GUI
        new Thread(() -> {
            try {
                // Create directories [cite: 8, 9]
                Files.createDirectories(Paths.get(DOWNLOAD_DIR));
                Files.createDirectories(Paths.get(LOG_DIR));

                crawlBFS(startUrl, maxDepth, infinite, signature);

                log("--- Process Complete ---");
            } catch (Exception e) {
                log("Error: " + e.getMessage());
                e.printStackTrace();
            } finally {
                isRunning = false;
                SwingUtilities.invokeLater(() -> startButton.setEnabled(true));
            }
        }).start();
    }

    /**
     * Breadth-First Search (BFS) implementation using a Queue.
     * This processes all links at Depth 0, then all at Depth 1, etc.
     */
    private void crawlBFS(String startUrl, int maxDepth, boolean infinite, String signature) {
        // Queue stores pairs of (URL, CurrentDepth)
        Queue<UrlNode> queue = new LinkedList<>();
        queue.add(new UrlNode(startUrl, 0));
        visitedUrls.add(startUrl);

        while (!queue.isEmpty()) {
            UrlNode current = queue.poll();
            String urlString = current.url;
            int depth = current.depth;

            // Check if we exceeded depth (unless infinite)
            if (!infinite && depth > maxDepth) {
                continue;
            }

            log("[" + depth + "] Exploring: " + urlString);
            
            String extension = getFileExtension(urlString);

            // Logic adapted from original crawl method [cite: 13, 14]
            if (MEDIA_EXTENSIONS.contains(extension)) {
                downloadAndLog(urlString, extension, signature);
            } else if (isPotentiallyWebPage(urlString)) {
                // Only parse for more links if we aren't at the max depth limit already
                // (Or if we are infinite)
                if (infinite || depth < maxDepth) {
                    processWebPage(urlString, depth, queue, signature);
                }
            }
        }
    }

    // Adapted from [cite: 15-20] to support Queue/BFS
    private void processWebPage(String urlString, int currentDepth, Queue<UrlNode> queue, String signature) {
        try {
            HttpURLConnection connection = (HttpURLConnection) new URL(urlString).openConnection();
            connection.setRequestProperty("User-Agent", USER_AGENT); // [cite: 16]
            connection.setConnectTimeout(5000);

            String contentType = connection.getContentType();
            if (contentType == null || !contentType.contains("text/html")) return;

            try (BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()))) {
                String line;
                // Regex from source [cite: 17]
                Pattern pattern = Pattern.compile("(href|src)=\"([^\"]*)\"", Pattern.CASE_INSENSITIVE);

                while ((line = reader.readLine()) != null) {
                    Matcher matcher = pattern.matcher(line);
                    while (matcher.find()) {
                        String foundUrl = matcher.group(2); // [cite: 18]
                        String absoluteUrl = resolveRelative(urlString, foundUrl);

                        if (absoluteUrl != null && !visitedUrls.contains(absoluteUrl)) {
                            visitedUrls.add(absoluteUrl);
                            // Add to queue for next level processing
                            queue.add(new UrlNode(absoluteUrl, currentDepth + 1));
                        }
                    }
                }
            }
        } catch (Exception e) {
            log("Skipping " + urlString + " (" + e.getMessage() + ")"); // [cite: 20]
        }
    }

    // Logic preserved from [cite: 20-27]
    private void downloadAndLog(String urlString, String extension, String signature) {
        String hash = generateHash(urlString);
        String fileName = hash + "." + extension; // [cite: 21]
        Path targetPath = Paths.get(DOWNLOAD_DIR, fileName);

        if (Files.exists(targetPath)) { // [cite: 22]
            log("   [!] Exists: " + fileName);
            return;
        }

        try {
            HttpURLConnection connection = (HttpURLConnection) new URL(urlString).openConnection();
            connection.setRequestProperty("User-Agent", USER_AGENT); // [cite: 24]
            
            try (InputStream in = connection.getInputStream()) {
                Files.copy(in, targetPath, StandardCopyOption.REPLACE_EXISTING);
                log("   [+] Downloaded: " + fileName); // [cite: 25]
                writeLog(hash, urlString, signature);
            }
        } catch (IOException e) {
            log("   [-] Error downloading " + urlString); // [cite: 26]
        }
    }

    // Logic preserved from [cite: 27-31]
    private void writeLog(String hash, String url, String signature) {
        File logFile = new File(LOG_DIR, hash + ".txt");
        String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));

        try (PrintWriter writer = new PrintWriter(new FileWriter(logFile))) {
            writer.println("URL: " + url);
            writer.println("Date Accessed: " + timestamp); // [cite: 29]
            writer.println("Signature: " + signature);
            writer.println("File Hash: " + hash);
        } catch (IOException e) {
            System.err.println("Failed to write log");
        }
    }

    // Logic preserved from [cite: 31-34]
    private static String resolveRelative(String base, String relative) {
        try {
            if (relative.startsWith("mailto:") || relative.startsWith("javascript:") || relative.startsWith("#")) {
                return null;
            }
            URL baseUrl = new URL(base);
            URL resolvedUrl = new URL(baseUrl, relative); // [cite: 33]
            return resolvedUrl.toString();
        } catch (MalformedURLException e) {
            return null;
        }
    }

    // Logic preserved from [cite: 34-37]
    private static String getFileExtension(String urlString) {
        try {
            String path = new URL(urlString).getPath();
            int lastDot = path.lastIndexOf('.'); // [cite: 35]
            if (lastDot > 0) {
                return path.substring(lastDot + 1).toLowerCase();
            }
        } catch (MalformedURLException e) { /* Ignore */ }
        return "";
    }

    // Logic preserved from [cite: 37-40]
    private static boolean isPotentiallyWebPage(String urlString) {
        String ext = getFileExtension(urlString);
        if (!ext.isEmpty() && ext.length() >= 3 && ext.length() <= 4) {
            return Arrays.asList("html", "htm", "php", "asp", "jsp").contains(ext);
        }
        return ext.isEmpty();
    }

    // Logic preserved from [cite: 40-44]
    private static String generateHash(String input) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(input.getBytes()); // [cite: 41]
            StringBuilder hexString = new StringBuilder();
            for (byte b : hash) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) hexString.append('0'); // [cite: 42]
                hexString.append(hex);
            }
            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            return String.valueOf(input.hashCode());
        }
    }

    // Helper class to store state in the BFS Queue
    private static class UrlNode {
        String url;
        int depth;

        UrlNode(String url, int depth) {
            this.url = url;
            this.depth = depth;
        }
    }

    public static void main(String[] args) {
        // Safe swing initialization
        SwingUtilities.invokeLater(() -> {
            new MediaCrawler().setVisible(true);
        });
    }
}