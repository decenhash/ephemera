<?php
// Minimalist Search & List Tool
$serversFile = 'servers.txt';
$query = isset($_GET['q']) ? trim($_GET['q']) : '';
$results = [];

if ($query && file_exists($serversFile)) {
    $servers = file($serversFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

    foreach ($servers as $server) {
        $server = rtrim($server, '/');
        $remoteFileUrl = $server . '/files.txt';

        // Fetch remote file content
        $content = @file($remoteFileUrl, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        
        if ($content) {
            foreach ($content as $line) {
                // Check if the line matches the user input (case-insensitive)
                if (stripos($line, $query) !== false) {
                    // Logic for Link Generation
                    if (filter_var($line, FILTER_VALIDATE_URL)) {
                        $link = $line;
                    } else {
                        // Path: server + /files/ + filename
                        $link = $server . '/files/' . ltrim($line, '/');
                    }
                    
                    $results[] = [
                        'text' => $line,
                        'url' => $link,
                        'source' => $server
                    ];
                }
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>File Search</title>
    <style>
        body { font-family: -apple-system, sans-serif; line-height: 1.6; max-width: 600px; margin: 40px auto; padding: 20px; color: #333; }
        input[type="text"] { width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 4px; box-sizing: border-box; }
        .result-item { margin-top: 20px; padding-bottom: 10px; border-bottom: 1px solid #eee; }
        .result-item a { color: #007bff; text-decoration: none; font-weight: bold; }
        .result-item small { color: #888; display: block; }
        .no-results { color: #999; margin-top: 20px; }
    </style>
</head>
<body>

    <form method="GET">
        <input type="text" name="q" placeholder="Search for files..." value="<?= htmlspecialchars($query) ?>" autofocus>
         <button type="submit">Search</button>
    </form>

    <?php if ($query): ?>
        <?php if (!empty($results)): ?>
            <?php foreach ($results as $res): ?>
                <div class="result-item">
                    <a href="<?= htmlspecialchars($res['url']) ?>" target="_blank">
                        <?= htmlspecialchars($res['text']) ?>
                    </a>
                    <small>Source: <?= htmlspecialchars($res['source']) ?></small>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <p class="no-results">No matches found for "<?= htmlspecialchars($query) ?>".</p>
        <?php endif; ?>
    <?php endif; ?>

</body>
</html>