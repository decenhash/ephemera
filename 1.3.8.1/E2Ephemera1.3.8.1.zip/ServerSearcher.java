import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;
import java.net.http.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

public class ServerSearcher extends JFrame {
    private JTextField queryField = new JTextField(20);
    private JCheckBox recursiveBox = new JCheckBox("Recursive Search", false);
    private JButton searchButton = new JButton("Search");
    private DefaultListModel<SearchResult> listModel = new DefaultListModel<>();
    private JList<SearchResult> resultList = new JList<>(listModel);
    private JLabel statusLabel = new JLabel("Ready");
    
    private final HttpClient httpClient = HttpClient.newBuilder()
            .followRedirects(HttpClient.Redirect.ALWAYS)
            .connectTimeout(java.time.Duration.ofSeconds(5))
            .build();
    
    private ExecutorService executor;
    private AtomicInteger totalResults = new AtomicInteger(0);
    private Set<String> visitedUrls = ConcurrentHashMap.newKeySet();
    private long startTime;

    public ServerSearcher() {
        setTitle("Server File Explorer");
        setSize(700, 500);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));

        // UI Panel
        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        topPanel.add(new JLabel("Query:"));
        topPanel.add(queryField);
        topPanel.add(recursiveBox);
        topPanel.add(searchButton);

        add(topPanel, BorderLayout.NORTH);
        add(new JScrollPane(resultList), BorderLayout.CENTER);
        add(statusLabel, BorderLayout.SOUTH);

        // Click to open URL
        resultList.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) {
                    SearchResult selected = resultList.getSelectedValue();
                    if (selected != null) openWebpage(selected.url);
                }
            }
        });

        searchButton.addActionListener(e -> startSearch());
    }

    private void startSearch() {
        String query = queryField.getText().trim();
        if (query.isEmpty()) return;

        // Reset state
        listModel.clear();
        totalResults.set(0);
        visitedUrls.clear();
        startTime = System.currentTimeMillis();
        searchButton.setEnabled(false);
        statusLabel.setText("Searching...");

        executor = Executors.newFixedThreadPool(10);
        
        CompletableFuture.runAsync(() -> {
            try (BufferedReader br = new BufferedReader(new FileReader("servers.txt"))) {
                String line;
                while ((line = br.readLine()) != null) {
                    String serverUrl = line.trim();
                    if (serverUrl.isEmpty()) continue;
                    
                    // Logic: If ends in .txt, use it. Otherwise, use /files.txt
                    String target = serverUrl.toLowerCase().endsWith(".txt") ? 
                                    serverUrl : serverUrl.replaceAll("/$", "") + "/files.txt";
                    
                    processUrl(target, serverUrl.replaceAll("/$", ""), query);
                }
            } catch (IOException ex) {
                updateStatus("Error reading servers.txt");
            }
        }).thenRun(() -> {
            // Wait for tasks or 1 minute timeout
            executor.shutdown();
            try { executor.awaitTermination(60, TimeUnit.SECONDS); } catch (InterruptedException ignored) {}
            updateStatus("Search finished. Results: " + totalResults.get());
            SwingUtilities.invokeLater(() -> searchButton.setEnabled(true));
        });
    }

    private void processUrl(String url, String baseServer, String query) {
        if (totalResults.get() >= 1000 || visitedUrls.contains(url) || 
            (System.currentTimeMillis() - startTime) > 60000) return;

        visitedUrls.add(url);
        
        executor.submit(() -> {
            try {
                HttpRequest request = HttpRequest.newBuilder().uri(URI.create(url)).build();
                HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
                
                if (response.statusCode() == 200) {
                    String[] lines = response.body().split("\\R");
                    for (String line : lines) {
                        if (totalResults.get() >= 1000) break;
                        line = line.trim();
                        if (line.isEmpty()) continue;

                        // Match search query
                        if (line.toLowerCase().contains(query.toLowerCase())) {
                            String link = isValidUrl(line) ? line : baseServer + "/files/" + line.replaceAll("^/", "");
                            addResult(new SearchResult(line, link));
                        }

                        // Recursive Logic
                        if (recursiveBox.isSelected() && isValidUrl(line) && line.toLowerCase().endsWith(".txt")) {
                            processUrl(line, baseServer, query);
                        }
                    }
                }
            } catch (Exception ignored) {}
        });
    }

    private void addResult(SearchResult res) {
        if (totalResults.incrementAndGet() <= 1000) {
            SwingUtilities.invokeLater(() -> listModel.addElement(res));
        }
    }

    private void updateStatus(String msg) {
        SwingUtilities.invokeLater(() -> statusLabel.setText(msg));
    }

    private boolean isValidUrl(String s) {
        try { new URL(s); return true; } catch (Exception e) { return false; }
    }

    private void openWebpage(String url) {
        try { Desktop.getDesktop().browse(new URI(url)); } catch (Exception ignored) {}
    }

    static class SearchResult {
        String text, url;
        SearchResult(String text, String url) { this.text = text; this.url = url; }
        @Override public String toString() { return text + " (" + url + ")"; }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new ServerSearcher().setVisible(true));
    }
}