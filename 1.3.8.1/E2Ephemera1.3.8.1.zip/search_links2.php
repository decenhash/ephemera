<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['search'])) {
    $search = trim($_POST['search']);
    $results = [];
    
    if (file_exists('servers.txt')) {
        $servers = file('servers.txt', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        
        foreach ($servers as $server) {
            $server = rtrim($server, '/');
            $filesUrl = $server . '/files.txt';
            
            $content = @file_get_contents($filesUrl);
            if ($content !== false) {
                $lines = explode("\n", $content);
                foreach ($lines as $line) {
                    $line = trim($line);
                    if (!empty($line) && stripos($line, $search) !== false) {
                        if (filter_var($line, FILTER_VALIDATE_URL)) {
                            $results[] = ['url' => $line, 'server' => $server];
                        } else {
                            $results[] = ['url' => $server . '/files/' . $line, 'server' => $server, 'filename' => $line];
                        }
                    }
                }
            }
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Server Files Search</title>
    <style>
        body { font-family: monospace; margin: 20px; max-width: 800px; }
        input, button { padding: 8px; margin: 5px 0; }
        .result { margin: 10px 0; padding: 10px; border: 1px solid #ccc; }
        .server { color: #666; font-size: 0.9em; }
    </style>
</head>
<body>
    <h1>Search Files from Servers</h1>
    <form method="post">
        <input type="text" name="search" placeholder="Enter search term..." 
               value="<?= isset($_POST['search']) ? htmlspecialchars($_POST['search']) : '' ?>" 
               required>
        <button type="submit">Search</button>
    </form>
    
    <?php if (isset($results)): ?>
        <hr>
        <h3>Results (<?= count($results) ?> found):</h3>
        
        <?php if (empty($results)): ?>
            <p>No matches found.</p>
        <?php else: ?>
            <?php foreach ($results as $result): ?>
                <div class="result">
                    <a href="<?= htmlspecialchars($result['url']) ?>" target="_blank">
                        <?= htmlspecialchars(basename($result['url'])) ?>
                    </a>
                    <div class="server">From: <?= htmlspecialchars($result['server']) ?></div>
                    <?php if (isset($result['filename'])): ?>
                        <div class="server">File: <?= htmlspecialchars($result['filename']) ?></div>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    <?php endif; ?>
</body>
</html>