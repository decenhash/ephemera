EPHEMERA v1.0.5 - by Decenhash
------------------------------

A simple and robust solution for creating static and distributed websites

Replication - Downloads all links from a page. Only works with the 'json', 'json_search', 'files' and 'others' directories. 
Make sure the directory is at the root or top, for example "http://example.com/json/test.json".

FileDownloader.java - If the server has a list of files in a text file where each line stores
a directory and the file name, for example, "json/test.json"

@decenhash
t.me/decenhash
decenhash.netlify.app
decenhash@gmail.com

---------------------

All rights reserved